import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search, Filter, SlidersHorizontal } from "lucide-react";
import { trpc } from "@/lib/trpc";
import TourCard from "@/components/TourCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { TOUR_CATEGORIES } from "@/lib/constants";

export default function Tours() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");
  const [search, setSearch] = useState(params.get("search") || "");
  const [category, setCategory] = useState(params.get("category") || "");
  const [searchInput, setSearchInput] = useState(params.get("search") || "");

  const { data: tours = [], isLoading } = trpc.tours.list.useQuery({
    published: true,
    category: category || undefined,
    search: search || undefined,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(searchInput);
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Page Header */}
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Explore Kenya
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Tours & Safaris</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Discover our handpicked collection of premium Kenya tours — from pristine beaches to wild safaris.
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-white border-b border-gray-100 shadow-sm">
        <div className="container py-4">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex gap-2 flex-1 max-w-md">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search tours..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="pl-9 rounded-xl"
                />
              </div>
              <Button type="submit" size="sm" className="rounded-xl"
                style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}>
                Search
              </Button>
            </form>

            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-1 flex-1">
              <button
                onClick={() => setCategory("")}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                  !category ? "text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
                style={!category ? { background: "oklch(0.45 0.14 240)", color: "white" } : {}}
              >
                All Tours
              </button>
              {TOUR_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                    category === cat.id ? "text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                  style={category === cat.id ? { background: "oklch(0.45 0.14 240)", color: "white" } : {}}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tours Grid */}
      <div className="container py-12">
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-2xl aspect-[3/4] animate-pulse" />
            ))}
          </div>
        ) : tours.length > 0 ? (
          <>
            <p className="text-gray-500 text-sm mb-6">{tours.length} tour{tours.length !== 1 ? "s" : ""} found</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {tours.map((tour) => (
                <TourCard key={tour.id} tour={tour} />
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="font-display text-xl font-bold text-gray-900 mb-2">No tours found</h3>
            <p className="text-gray-500 mb-6">Try adjusting your search or browse all categories.</p>
            <Button onClick={() => { setSearch(""); setSearchInput(""); setCategory(""); }}
              className="rounded-xl" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
