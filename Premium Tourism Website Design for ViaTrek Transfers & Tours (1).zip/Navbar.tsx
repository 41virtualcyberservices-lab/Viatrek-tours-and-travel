import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Phone, ChevronDown } from "lucide-react";
import { NAV_LINKS, CONTACT_PHONE, WHATSAPP_URL } from "@/lib/constants";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  const { data: logoSetting } = trpc.settings.get.useQuery("logo");
  const { data: siteNameSetting } = trpc.settings.get.useQuery("site_name");

  const siteName = siteNameSetting || "ViaTrek Tours";
  const logoUrl = logoSetting || null;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const isHome = location === "/";
  const isTransparent = isHome && !scrolled;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isTransparent
          ? "bg-transparent"
          : "bg-white/95 backdrop-blur-md shadow-md"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 flex-shrink-0">
            {logoUrl ? (
              <img src={logoUrl} alt={siteName} className="h-10 w-auto object-contain" />
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-ocean-gradient flex items-center justify-center">
                  <span className="text-white font-bold text-sm font-display">VT</span>
                </div>
                <span
                  className={`font-display font-bold text-xl transition-colors duration-300 ${
                    isTransparent ? "text-white" : "text-ocean"
                  }`}
                  style={{ color: isTransparent ? "white" : "oklch(0.32 0.12 240)" }}
                >
                  {siteName}
                </span>
              </div>
            )}
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  location === link.href
                    ? isTransparent
                      ? "text-white bg-white/20"
                      : "text-ocean bg-blue-50"
                    : isTransparent
                    ? "text-white/90 hover:text-white hover:bg-white/15"
                    : "text-gray-700 hover:text-ocean hover:bg-blue-50"
                }`}
                style={
                  location === link.href && !isTransparent
                    ? { color: "oklch(0.32 0.12 240)" }
                    : {}
                }
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={`tel:${CONTACT_PHONE}`}
              className={`flex items-center gap-2 text-sm font-medium transition-colors duration-200 ${
                isTransparent ? "text-white/90 hover:text-white" : "text-gray-600 hover:text-ocean"
              }`}
            >
              <Phone className="w-4 h-4" />
              {CONTACT_PHONE}
            </a>
            <Link href="/tours">
              <Button
                size="sm"
                className="bg-gold-gradient text-white border-0 hover:opacity-90 btn-scale font-semibold"
                style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))" }}
              >
                Book Now
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`lg:hidden p-2 rounded-lg transition-colors duration-200 ${
              isTransparent ? "text-white hover:bg-white/15" : "text-gray-700 hover:bg-gray-100"
            }`}
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="bg-white border-t border-gray-100 shadow-lg">
          <div className="container py-4 flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  location === link.href
                    ? "bg-blue-50 font-semibold"
                    : "text-gray-700 hover:bg-gray-50"
                }`}
                style={location === link.href ? { color: "oklch(0.32 0.12 240)" } : {}}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3 mt-2 border-t border-gray-100 flex flex-col gap-2">
              <a
                href={`tel:${CONTACT_PHONE}`}
                className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600"
              >
                <Phone className="w-4 h-4" />
                {CONTACT_PHONE}
              </a>
              <Link href="/tours">
                <Button
                  className="w-full font-semibold"
                  style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}
                >
                  Book Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
