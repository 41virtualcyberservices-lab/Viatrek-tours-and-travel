import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { storagePut } from "./storage";
import * as db from "./db";
import { nanoid } from "nanoid";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

// ============================================================
// TOURS ROUTER
// ============================================================
const toursRouter = router({
  list: publicProcedure
    .input(z.object({
      featured: z.boolean().optional(),
      category: z.string().optional(),
      search: z.string().optional(),
      published: z.boolean().optional(),
    }).optional())
    .query(({ input }) => db.getTours({ published: true, ...input })),

  adminList: adminProcedure
    .input(z.object({ category: z.string().optional(), search: z.string().optional() }).optional())
    .query(({ input }) => db.getTours(input)),

  bySlug: publicProcedure
    .input(z.string())
    .query(async ({ input }) => {
      const tour = await db.getTourBySlug(input);
      if (!tour) throw new TRPCError({ code: "NOT_FOUND" });
      return tour;
    }),

  create: adminProcedure
    .input(z.object({
      title: z.string().min(1),
      slug: z.string().min(1),
      category: z.enum(["beach", "safari", "cultural", "city", "family", "honeymoon", "corporate", "adventure", "group", "custom"]),
      shortDescription: z.string().optional(),
      description: z.string().optional(),
      duration: z.string().optional(),
      availability: z.string().optional(),
      price: z.string().optional(),
      priceUnit: z.string().optional(),
      maxGroupSize: z.number().optional(),
      difficulty: z.enum(["easy", "moderate", "challenging"]).optional(),
      coverImage: z.string().optional(),
      gallery: z.array(z.string()).optional(),
      highlights: z.array(z.string()).optional(),
      included: z.array(z.string()).optional(),
      excluded: z.array(z.string()).optional(),
      itinerary: z.array(z.object({ day: z.number(), title: z.string(), description: z.string() })).optional(),
      featured: z.boolean().optional(),
      published: z.boolean().optional(),
      metaTitle: z.string().optional(),
      metaDescription: z.string().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createTour(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateTour(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteTour(input)),
});

// ============================================================
// DESTINATIONS ROUTER
// ============================================================
const destinationsRouter = router({
  list: publicProcedure
    .input(z.object({ featured: z.boolean().optional() }).optional())
    .query(({ input }) => db.getDestinations({ published: true, ...input })),

  adminList: adminProcedure.query(() => db.getDestinations()),

  bySlug: publicProcedure
    .input(z.string())
    .query(async ({ input }) => {
      const dest = await db.getDestinationBySlug(input);
      if (!dest) throw new TRPCError({ code: "NOT_FOUND" });
      return dest;
    }),

  create: adminProcedure
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
      region: z.string().optional(),
      shortDescription: z.string().optional(),
      description: z.string().optional(),
      coverImage: z.string().optional(),
      gallery: z.array(z.string()).optional(),
      highlights: z.array(z.string()).optional(),
      bestTimeToVisit: z.string().optional(),
      climate: z.string().optional(),
      featured: z.boolean().optional(),
      published: z.boolean().optional(),
      metaTitle: z.string().optional(),
      metaDescription: z.string().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createDestination(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateDestination(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteDestination(input)),
});

// ============================================================
// TRANSFERS ROUTER
// ============================================================
const transfersRouter = router({
  list: publicProcedure.query(() => db.getTransfers(true)),
  adminList: adminProcedure.query(() => db.getTransfers()),

  bySlug: publicProcedure
    .input(z.string())
    .query(async ({ input }) => {
      const t = await db.getTransferBySlug(input);
      if (!t) throw new TRPCError({ code: "NOT_FOUND" });
      return t;
    }),

  create: adminProcedure
    .input(z.object({
      title: z.string().min(1),
      slug: z.string().min(1),
      type: z.enum(["airport", "hotel", "corporate", "vip", "group"]),
      shortDescription: z.string().optional(),
      description: z.string().optional(),
      coverImage: z.string().optional(),
      price: z.string().optional(),
      priceUnit: z.string().optional(),
      features: z.array(z.string()).optional(),
      published: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createTransfer(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateTransfer(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteTransfer(input)),
});

// ============================================================
// BOOKINGS ROUTER
// ============================================================
const bookingsRouter = router({
  create: publicProcedure
    .input(z.object({
      tourId: z.number().optional(),
      tourTitle: z.string().optional(),
      transferId: z.number().optional(),
      transferTitle: z.string().optional(),
      bookingType: z.enum(["tour", "transfer", "custom"]).optional(),
      firstName: z.string().min(1),
      lastName: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      travelDate: z.string().optional(),
      travelers: z.number().min(1).optional(),
      specialRequests: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const bookingRef = `VT-${nanoid(8).toUpperCase()}`;
      await db.createBooking({ ...input, bookingRef } as any);

      // Notify owner
      await notifyOwner({
        title: `New Booking: ${bookingRef}`,
        content: `New booking from ${input.firstName} ${input.lastName} (${input.email}) for ${input.tourTitle || input.transferTitle || "Custom"}. Travel date: ${input.travelDate || "TBD"}. Travelers: ${input.travelers || 1}.`,
      });

      return { bookingRef };
    }),

  list: adminProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(({ input }) => db.getBookings(input?.status)),

  updateStatus: adminProcedure
    .input(z.object({ id: z.number(), status: z.string(), adminNotes: z.string().optional() }))
    .mutation(({ input }) => db.updateBookingStatus(input.id, input.status, input.adminNotes)),

  stats: adminProcedure.query(() => db.getBookingStats()),
});

// ============================================================
// BLOG ROUTER
// ============================================================
const blogRouter = router({
  list: publicProcedure
    .input(z.object({ featured: z.boolean().optional(), category: z.string().optional() }).optional())
    .query(({ input }) => db.getBlogPosts({ published: true, ...input })),

  adminList: adminProcedure
    .input(z.object({ published: z.boolean().optional() }).optional())
    .query(({ input }) => db.getBlogPosts(input)),

  bySlug: publicProcedure
    .input(z.string())
    .query(async ({ input }) => {
      const post = await db.getBlogPostBySlug(input);
      if (!post) throw new TRPCError({ code: "NOT_FOUND" });
      await db.incrementBlogViews(post.id);
      return post;
    }),

  create: adminProcedure
    .input(z.object({
      title: z.string().min(1),
      slug: z.string().min(1),
      excerpt: z.string().optional(),
      content: z.string().optional(),
      coverImage: z.string().optional(),
      category: z.string().optional(),
      tags: z.array(z.string()).optional(),
      author: z.string().optional(),
      published: z.boolean().optional(),
      featured: z.boolean().optional(),
      metaTitle: z.string().optional(),
      metaDescription: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const data = { ...input, publishedAt: input.published ? new Date() : null };
      return db.createBlogPost(data as any);
    }),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateBlogPost(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteBlogPost(input)),
});

// ============================================================
// REVIEWS ROUTER
// ============================================================
const reviewsRouter = router({
  list: publicProcedure
    .input(z.object({ featured: z.boolean().optional() }).optional())
    .query(({ input }) => db.getReviews({ status: "approved", ...input })),

  adminList: adminProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(({ input }) => db.getReviews(input)),

  submit: publicProcedure
    .input(z.object({
      tourId: z.number().optional(),
      tourTitle: z.string().optional(),
      reviewerName: z.string().min(1),
      reviewerEmail: z.string().email().optional(),
      reviewerCountry: z.string().optional(),
      rating: z.number().min(1).max(5),
      title: z.string().optional(),
      content: z.string().min(10),
    }))
    .mutation(async ({ input }) => {
      await db.createReview(input as any);
      await notifyOwner({
        title: "New Review Submitted",
        content: `${input.reviewerName} submitted a ${input.rating}-star review. Awaiting moderation.`,
      });
      return { success: true };
    }),

  updateStatus: adminProcedure
    .input(z.object({ id: z.number(), status: z.string(), featured: z.boolean().optional() }))
    .mutation(({ input }) => db.updateReviewStatus(input.id, input.status, input.featured)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteReview(input)),
});

// ============================================================
// GALLERY ROUTER
// ============================================================
const galleryRouter = router({
  list: publicProcedure
    .input(z.object({ category: z.string().optional(), type: z.string().optional() }).optional())
    .query(({ input }) => db.getGalleryItems({ published: true, ...input })),

  adminList: adminProcedure.query(() => db.getGalleryItems()),

  create: adminProcedure
    .input(z.object({
      title: z.string().optional(),
      description: z.string().optional(),
      url: z.string().min(1),
      thumbnailUrl: z.string().optional(),
      type: z.enum(["photo", "video"]).optional(),
      category: z.string().optional(),
      tags: z.array(z.string()).optional(),
      featured: z.boolean().optional(),
      published: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createGalleryItem(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateGalleryItem(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteGalleryItem(input)),
});

// ============================================================
// CHATBOT ROUTER
// ============================================================
const chatbotRouter = router({
  faqs: publicProcedure.query(() => db.getChatbotFaqs(true)),
  adminFaqs: adminProcedure.query(() => db.getChatbotFaqs()),

  chat: publicProcedure
    .input(z.object({
      message: z.string().min(1),
      history: z.array(z.object({ role: z.string(), content: z.string() })).optional(),
      leadInfo: z.object({ name: z.string().optional(), email: z.string().optional(), phone: z.string().optional() }).optional(),
    }))
    .mutation(async ({ input }) => {
      const faqs = await db.getChatbotFaqs(true);
      const faqContext = faqs.map(f => `Q: ${f.question}\nA: ${f.answer}`).join("\n\n");

      const systemPrompt = `You are a helpful travel assistant for ViaTrek Tours, a premium travel and tours company based in Coastal Kenya. 
You help customers discover tours, plan trips, and make bookings.

Company Info:
- Name: ViaTrek Tours
- Location: Coastal Kenya (Mombasa, Diani, Watamu, Malindi)
- Phone/WhatsApp: +254701475532
- Email: viatrektours@gmail.com
- Services: Beach tours, Safari, Cultural tours, City tours, Family tours, Honeymoon packages, Corporate tours, Adventure, Group tours, Custom tours
- Transfers: Airport, Hotel, Corporate, VIP, Group transfers
- Destinations: Mombasa, Diani, Watamu, Malindi, Tsavo, Amboseli, Maasai Mara, Naivasha, Nakuru, Nairobi

FAQ Knowledge Base:
${faqContext}

Guidelines:
- Be warm, professional, and enthusiastic about Kenya travel
- Recommend specific tours and destinations based on customer interests
- Encourage bookings and provide the WhatsApp number for quick inquiries
- If you don't know something specific, direct them to contact us
- Keep responses concise and helpful (2-3 paragraphs max)
- Always end with a call to action`;

      const messages = [
        { role: "system" as const, content: systemPrompt },
        ...(input.history || []).map(h => ({ role: h.role as "user" | "assistant", content: h.content })),
        { role: "user" as const, content: input.message },
      ];

      const response = await invokeLLM({ messages });
      const reply = response.choices[0]?.message?.content || "I'm here to help! Please contact us at +254701475532 for assistance.";

      return { reply };
    }),

  saveLead: publicProcedure
    .input(z.object({
      name: z.string().optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      interest: z.string().optional(),
      conversation: z.array(z.object({ role: z.string(), content: z.string() })).optional(),
    }))
    .mutation(async ({ input }) => {
      await db.createChatbotLead(input as any);
      if (input.email || input.phone) {
        await notifyOwner({
          title: "New Chatbot Lead",
          content: `Lead from chatbot: ${input.name || "Unknown"} | ${input.email || ""} | ${input.phone || ""} | Interest: ${input.interest || "General inquiry"}`,
        });
      }
      return { success: true };
    }),

  createFaq: adminProcedure
    .input(z.object({
      question: z.string().min(1),
      answer: z.string().min(1),
      category: z.string().optional(),
      keywords: z.array(z.string()).optional(),
      active: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createChatbotFaq(input as any)),

  updateFaq: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateChatbotFaq(input.id, input.data)),

  deleteFaq: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteChatbotFaq(input)),

  leads: adminProcedure.query(() => db.getChatbotLeads()),
});

// ============================================================
// NEWSLETTER ROUTER
// ============================================================
const newsletterRouter = router({
  subscribe: publicProcedure
    .input(z.object({ email: z.string().email(), name: z.string().optional() }))
    .mutation(async ({ input }) => {
      await db.subscribeNewsletter(input.email, input.name);
      return { success: true };
    }),

  list: adminProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(({ input }) => db.getNewsletterSubscribers(input?.status)),
});

// ============================================================
// CONTACT ROUTER
// ============================================================
const contactRouter = router({
  submit: publicProcedure
    .input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      subject: z.string().optional(),
      message: z.string().min(10),
    }))
    .mutation(async ({ input }) => {
      await db.createContactMessage(input as any);
      await notifyOwner({
        title: `Contact Form: ${input.subject || "New Message"}`,
        content: `From: ${input.name} (${input.email})\nPhone: ${input.phone || "N/A"}\n\n${input.message}`,
      });
      return { success: true };
    }),

  list: adminProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(({ input }) => db.getContactMessages(input?.status)),

  updateStatus: adminProcedure
    .input(z.object({ id: z.number(), status: z.string() }))
    .mutation(({ input }) => db.updateContactMessageStatus(input.id, input.status)),
});

// ============================================================
// TESTIMONIALS ROUTER
// ============================================================
const testimonialsRouter = router({
  list: publicProcedure
    .input(z.object({ featured: z.boolean().optional() }).optional())
    .query(({ input }) => db.getTestimonials({ active: true, ...input })),

  adminList: adminProcedure.query(() => db.getTestimonials()),

  create: adminProcedure
    .input(z.object({
      name: z.string().min(1),
      role: z.string().optional(),
      country: z.string().optional(),
      avatar: z.string().optional(),
      content: z.string().min(1),
      rating: z.number().min(1).max(5).optional(),
      featured: z.boolean().optional(),
      active: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createTestimonial(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateTestimonial(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteTestimonial(input)),
});

// ============================================================
// SPECIAL OFFERS ROUTER
// ============================================================
const specialOffersRouter = router({
  list: publicProcedure.query(() => db.getSpecialOffers(true)),
  adminList: adminProcedure.query(() => db.getSpecialOffers()),

  create: adminProcedure
    .input(z.object({
      title: z.string().min(1),
      description: z.string().optional(),
      discount: z.string().optional(),
      coverImage: z.string().optional(),
      tourId: z.number().optional(),
      validUntil: z.string().optional(),
      badge: z.string().optional(),
      active: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createSpecialOffer(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateSpecialOffer(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteSpecialOffer(input)),
});

// ============================================================
// TEAM ROUTER
// ============================================================
const teamRouter = router({
  list: publicProcedure.query(() => db.getTeamMembers(true)),
  adminList: adminProcedure.query(() => db.getTeamMembers()),

  create: adminProcedure
    .input(z.object({
      name: z.string().min(1),
      role: z.string().optional(),
      bio: z.string().optional(),
      avatar: z.string().optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      socialLinks: z.array(z.object({ platform: z.string(), url: z.string() })).optional(),
      active: z.boolean().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createTeamMember(input as any)),

  update: adminProcedure
    .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
    .mutation(({ input }) => db.updateTeamMember(input.id, input.data)),

  delete: adminProcedure
    .input(z.number())
    .mutation(({ input }) => db.deleteTeamMember(input)),
});

// ============================================================
// SETTINGS ROUTER
// ============================================================
const settingsRouter = router({
  get: publicProcedure
    .input(z.string())
    .query(({ input }) => db.getSetting(input)),

  getAll: publicProcedure.query(() => db.getAllSettings()),

  getByGroup: publicProcedure
    .input(z.string())
    .query(({ input }) => db.getSettingsByGroup(input)),

  upsert: adminProcedure
    .input(z.object({
      key: z.string(),
      value: z.string(),
      label: z.string().optional(),
      group: z.string().optional(),
      type: z.string().optional(),
    }))
    .mutation(({ input }) => db.upsertSetting(input.key, input.value, input.label, input.group, input.type)),

  upsertMany: adminProcedure
    .input(z.array(z.object({
      key: z.string(),
      value: z.string(),
      label: z.string().optional(),
      group: z.string().optional(),
      type: z.string().optional(),
    })))
    .mutation(async ({ input }) => {
      for (const item of input) {
        await db.upsertSetting(item.key, item.value, item.label, item.group, item.type);
      }
      return { success: true };
    }),
});

// ============================================================
// SEO ROUTER
// ============================================================
const seoRouter = router({
  getPage: publicProcedure
    .input(z.string())
    .query(({ input }) => db.getPageSeo(input)),

  getAll: adminProcedure.query(() => db.getAllPageSeo()),

  upsert: adminProcedure
    .input(z.object({
      page: z.string(),
      title: z.string().optional(),
      description: z.string().optional(),
      ogTitle: z.string().optional(),
      ogDescription: z.string().optional(),
      ogImage: z.string().optional(),
      keywords: z.string().optional(),
    }))
    .mutation(({ input }) => db.upsertPageSeo(input.page, input)),
});

// ============================================================
// FILE UPLOAD ROUTER
// ============================================================
const uploadRouter = router({
  getUploadUrl: adminProcedure
    .input(z.object({
      filename: z.string(),
      contentType: z.string(),
      data: z.string(), // base64
    }))
    .mutation(async ({ input }) => {
      const buffer = Buffer.from(input.data, "base64");
      const key = `uploads/${Date.now()}-${input.filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { url } = await storagePut(key, buffer, input.contentType);
      return { url, key };
    }),
});

// ============================================================
// ANALYTICS ROUTER
// ============================================================
const analyticsRouter = router({
  overview: adminProcedure.query(async () => {
    const [bookingStats, subscribers, messages, reviews] = await Promise.all([
      db.getBookingStats(),
      db.getNewsletterSubscribers("active"),
      db.getContactMessages("new"),
      db.getReviews({ status: "pending" }),
    ]);
    return {
      bookings: bookingStats,
      activeSubscribers: subscribers.length,
      newMessages: messages.length,
      pendingReviews: reviews.length,
    };
  }),
});

// ============================================================
// APP ROUTER
// ============================================================
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  tours: toursRouter,
  destinations: destinationsRouter,
  transfers: transfersRouter,
  bookings: bookingsRouter,
  blog: blogRouter,
  reviews: reviewsRouter,
  gallery: galleryRouter,
  chatbot: chatbotRouter,
  newsletter: newsletterRouter,
  contact: contactRouter,
  testimonials: testimonialsRouter,
  specialOffers: specialOffersRouter,
  team: teamRouter,
  settings: settingsRouter,
  seo: seoRouter,
  upload: uploadRouter,
  analytics: analyticsRouter,
});

export type AppRouter = typeof appRouter;
