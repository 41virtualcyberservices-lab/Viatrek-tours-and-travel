export const SITE_NAME = "ViaTrek Tours";
export const SITE_TAGLINE = "Discover Kenya. Experience Adventure. Travel With Confidence.";
export const CONTACT_EMAIL = "viatrektours@gmail.com";
export const CONTACT_PHONE = "+254701475532";
export const WHATSAPP_NUMBER = "254701475532";
export const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}`;

export const TOUR_CATEGORIES = [
  { id: "beach", label: "Beach Tours", icon: "🏖️", color: "from-cyan-400 to-blue-500" },
  { id: "safari", label: "Safari", icon: "🦁", color: "from-amber-400 to-orange-500" },
  { id: "cultural", label: "Cultural Tours", icon: "🏛️", color: "from-purple-400 to-indigo-500" },
  { id: "city", label: "City Tours", icon: "🏙️", color: "from-slate-400 to-gray-600" },
  { id: "family", label: "Family Tours", icon: "👨‍👩‍👧‍👦", color: "from-green-400 to-emerald-500" },
  { id: "honeymoon", label: "Honeymoon", icon: "💑", color: "from-pink-400 to-rose-500" },
  { id: "corporate", label: "Corporate", icon: "💼", color: "from-blue-400 to-indigo-500" },
  { id: "adventure", label: "Adventure", icon: "🧗", color: "from-orange-400 to-red-500" },
  { id: "group", label: "Group Tours", icon: "👥", color: "from-teal-400 to-cyan-500" },
  { id: "custom", label: "Custom Tours", icon: "✨", color: "from-violet-400 to-purple-500" },
] as const;

export const DESTINATIONS = [
  { name: "Mombasa", slug: "mombasa", region: "Coast", tagline: "The White & Blue City" },
  { name: "Diani", slug: "diani", region: "Coast", tagline: "Kenya's Paradise Beach" },
  { name: "Watamu", slug: "watamu", region: "Coast", tagline: "Marine Park Wonder" },
  { name: "Malindi", slug: "malindi", region: "Coast", tagline: "Historic Coastal Town" },
  { name: "Tsavo", slug: "tsavo", region: "South Kenya", tagline: "Land of Red Elephants" },
  { name: "Amboseli", slug: "amboseli", region: "South Kenya", tagline: "Kilimanjaro's Shadow" },
  { name: "Maasai Mara", slug: "maasai-mara", region: "Rift Valley", tagline: "Great Migration" },
  { name: "Naivasha", slug: "naivasha", region: "Rift Valley", tagline: "Lake & Flamingos" },
  { name: "Nakuru", slug: "nakuru", region: "Rift Valley", tagline: "Flamingo Lake" },
  { name: "Nairobi", slug: "nairobi", region: "Central", tagline: "The Safari Capital" },
];

export const TRANSFER_TYPES = [
  { id: "airport", label: "Airport Transfers", icon: "✈️", description: "Reliable airport pickups and drop-offs" },
  { id: "hotel", label: "Hotel Transfers", icon: "🏨", description: "Comfortable hotel-to-hotel transfers" },
  { id: "corporate", label: "Corporate Transfers", icon: "💼", description: "Professional business travel solutions" },
  { id: "vip", label: "VIP Transfers", icon: "⭐", description: "Luxury vehicles for premium experiences" },
  { id: "group", label: "Group Transfers", icon: "🚌", description: "Spacious coaches for large groups" },
];

export const SOCIAL_LINKS = {
  facebook: "https://facebook.com/viatrektours",
  twitter: "https://twitter.com/viatrektours",
  instagram: "https://instagram.com/viatrektours",
  whatsapp: WHATSAPP_URL,
};

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Tours & Safaris", href: "/tours" },
  { label: "Destinations", href: "/destinations" },
  { label: "Transfers", href: "/transfers" },
  { label: "Gallery", href: "/gallery" },
  { label: "Blog", href: "/blog" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];
