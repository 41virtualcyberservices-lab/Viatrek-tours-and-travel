import { useState, useEffect, useCallback } from "react";
import { Link, useLocation } from "wouter";
import { Search, ChevronLeft, ChevronRight, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SITE_TAGLINE, TOUR_CATEGORIES } from "@/lib/constants";
import { trpc } from "@/lib/trpc";

// Default hero slides with high-quality Unsplash images
const DEFAULT_SLIDES = [
  {
    url: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=1920&q=80",
    title: "Discover Kenya",
    subtitle: "Maasai Mara & Beyond",
  },
  {
    url: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=1920&q=80",
    title: "Coastal Paradise",
    subtitle: "Diani Beach & Mombasa",
  },
  {
    url: "https://images.unsplash.com/photo-1589825743636-e1a9b1e2d0a3?w=1920&q=80",
    title: "Safari Adventure",
    subtitle: "Tsavo & Amboseli",
  },
  {
    url: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=1920&q=80",
    title: "Cultural Journeys",
    subtitle: "Authentic Kenya Experiences",
  },
];

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [, setLocation] = useLocation();

  const { data: heroImagesData } = trpc.settings.get.useQuery("hero_images");

  const slides = (() => {
    if (heroImagesData) {
      try {
        const parsed = JSON.parse(heroImagesData);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((url: string, i: number) => ({
            url,
            title: DEFAULT_SLIDES[i % DEFAULT_SLIDES.length]?.title || "Discover Kenya",
            subtitle: DEFAULT_SLIDES[i % DEFAULT_SLIDES.length]?.subtitle || "",
          }));
        }
      } catch {}
    }
    return DEFAULT_SLIDES;
  })();

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  }, [slides.length]);

  useEffect(() => {
    const timer = setInterval(nextSlide, 5500);
    return () => clearInterval(timer);
  }, [nextSlide]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/tours?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <section className="relative h-screen min-h-[600px] max-h-[900px] overflow-hidden">
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <img
            src={slide.url}
            alt={slide.title}
            className="w-full h-full object-cover"
            loading={index === 0 ? "eager" : "lazy"}
          />
        </div>
      ))}

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-hero-gradient" />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center px-4">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold mb-6 animate-fade-in-down"
            style={{ background: "oklch(0.72 0.14 195 / 0.25)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.4)" }}>
            <MapPin className="w-3 h-3" />
            Coastal Kenya's Premier Tour Operator
          </div>

          {/* Main Headline */}
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6 animate-fade-in-up">
            {SITE_TAGLINE.split(". ").map((part, i) => (
              <span key={i} className={`block ${i === 1 ? "text-gradient-gold" : ""}`}
                style={i === 1 ? { background: "linear-gradient(135deg, oklch(0.78 0.16 75), oklch(0.92 0.12 75))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" } : {}}>
                {part}.
              </span>
            ))}
          </h1>

          {/* Subtitle */}
          <p className="text-white/80 text-lg md:text-xl mb-8 animate-fade-in delay-200">
            Premium tours, transfers & safaris across Kenya's most breathtaking destinations
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-10 animate-fade-in delay-300">
            <Link href="/tours">
              <Button
                size="lg"
                className="px-8 py-3 text-base font-semibold rounded-xl btn-scale border-0"
                style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}
              >
                Book Now
              </Button>
            </Link>
            <Link href="/tours">
              <Button
                size="lg"
                variant="outline"
                className="px-8 py-3 text-base font-semibold rounded-xl btn-scale border-2 border-white/60 text-white hover:bg-white/15 bg-transparent"
              >
                Explore Tours
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                size="lg"
                variant="outline"
                className="px-8 py-3 text-base font-semibold rounded-xl btn-scale border-2 text-white hover:bg-white/15 bg-transparent"
                style={{ borderColor: "oklch(0.72 0.14 195 / 0.7)" }}
              >
                Contact Us
              </Button>
            </Link>
          </div>

          {/* Search Bar */}
          <form
            onSubmit={handleSearch}
            className="flex items-center gap-2 max-w-xl mx-auto bg-white/15 backdrop-blur-md rounded-2xl p-2 border border-white/30 animate-fade-in delay-400"
          >
            <Search className="w-5 h-5 text-white/70 ml-2 flex-shrink-0" />
            <Input
              type="text"
              placeholder="Search tours, destinations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border-0 bg-transparent text-white placeholder:text-white/60 focus-visible:ring-0 focus-visible:ring-offset-0 text-sm"
            />
            <Button
              type="submit"
              size="sm"
              className="rounded-xl font-semibold flex-shrink-0"
              style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}
            >
              Search
            </Button>
          </form>
        </div>
      </div>

      {/* Slide Navigation */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
        style={{ background: "oklch(0 0 0 / 0.3)", backdropFilter: "blur(8px)", color: "white" }}
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
        style={{ background: "oklch(0 0 0 / 0.3)", backdropFilter: "blur(8px)", color: "white" }}
        aria-label="Next slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Slide Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`transition-all duration-300 rounded-full ${
              index === currentSlide ? "w-8 h-2.5" : "w-2.5 h-2.5"
            }`}
            style={{
              background: index === currentSlide
                ? "oklch(0.78 0.16 75)"
                : "oklch(1 0 0 / 0.5)",
            }}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 right-8 hidden md:flex flex-col items-center gap-1 text-white/50 text-xs">
        <span className="rotate-90 text-[10px] tracking-widest uppercase">Scroll</span>
        <div className="w-px h-8 bg-white/30" />
      </div>
    </section>
  );
}
