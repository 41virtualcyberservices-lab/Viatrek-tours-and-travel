import { Link } from "wouter";
import { CheckCircle, MessageCircle, ArrowRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { TRANSFER_TYPES, WHATSAPP_URL } from "@/lib/constants";

const TRANSFER_IMAGES: Record<string, string> = {
  airport: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=600&q=80",
  hotel: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80",
  corporate: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80",
  vip: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600&q=80",
  group: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&q=80",
};

export default function Transfers() {
  const { data: dbTransfers = [] } = trpc.transfers.list.useQuery();

  const transfers = dbTransfers.length > 0
    ? dbTransfers.map(t => ({
        id: t.id,
        type: t.type,
        title: t.title,
        description: t.shortDescription || t.description || "",
        features: Array.isArray(t.features) ? t.features as string[] : [],
        price: t.price,
        priceUnit: t.priceUnit,
        image: t.coverImage || TRANSFER_IMAGES[t.type],
      }))
    : TRANSFER_TYPES.map(t => ({
        id: 0,
        type: t.id,
        title: t.label,
        description: t.description,
        features: ["Professional drivers", "24/7 availability", "Air-conditioned vehicles", "Meet & greet service"],
        price: null,
        priceUnit: "per trip",
        image: TRANSFER_IMAGES[t.id],
      }));

  return (
    <div className="min-h-screen pt-20">
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Transportation
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Transfer Services</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Reliable, comfortable, and professional transfer services across Kenya.
          </p>
        </div>
      </div>

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {transfers.map((transfer, i) => (
            <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
              <div className="aspect-[16/9] overflow-hidden relative">
                <img src={transfer.image} alt={transfer.title} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="text-2xl">{TRANSFER_TYPES.find(t => t.id === transfer.type)?.icon || "🚗"}</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl font-bold text-gray-900 mb-2">{transfer.title}</h3>
                <p className="text-gray-500 text-sm mb-4">{transfer.description}</p>
                {transfer.features.length > 0 && (
                  <ul className="space-y-1.5 mb-5">
                    {transfer.features.slice(0, 4).map((f, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 flex-shrink-0" style={{ color: "oklch(0.72 0.14 195)" }} />
                        {f}
                      </li>
                    ))}
                  </ul>
                )}
                <div className="flex items-center justify-between">
                  {transfer.price ? (
                    <div>
                      <span className="text-xs text-gray-400">From</span>
                      <p className="font-bold text-lg" style={{ color: "oklch(0.32 0.12 240)" }}>
                        ${Number(transfer.price).toLocaleString()} <span className="text-xs font-normal text-gray-400">{transfer.priceUnit}</span>
                      </p>
                    </div>
                  ) : (
                    <span className="text-sm text-gray-500">Contact for pricing</span>
                  )}
                  <a href={`${WHATSAPP_URL}?text=Hi, I need a ${transfer.title}`} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" className="rounded-xl font-semibold" style={{ background: "#25D366", color: "white" }}>
                      <MessageCircle className="w-3.5 h-3.5 mr-1" /> Book
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center p-10 rounded-2xl text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
          <h2 className="font-display text-2xl font-bold mb-3">Need a Custom Transfer?</h2>
          <p className="text-white/75 mb-6">Contact us for group bookings, VIP services, or any special requirements.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/contact">
              <Button className="rounded-xl font-semibold" style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}>
                Get a Quote
              </Button>
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="rounded-xl font-semibold border-white/40 text-white hover:bg-white/15 bg-transparent">
                <MessageCircle className="w-4 h-4 mr-2" /> WhatsApp Us
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
