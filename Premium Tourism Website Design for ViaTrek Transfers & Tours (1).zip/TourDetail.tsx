import { useState } from "react";
import { useRoute, Link } from "wouter";
import { Clock, Users, MapPin, Star, CheckCircle, XCircle, Calendar, Share2, Facebook, Twitter, MessageCircle, ArrowLeft, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { WHATSAPP_URL } from "@/lib/constants";

export default function TourDetail() {
  const [, params] = useRoute("/tours/:slug");
  const slug = params?.slug || "";
  const [activeImage, setActiveImage] = useState(0);
  const [showBooking, setShowBooking] = useState(false);
  const [bookingForm, setBookingForm] = useState({
    firstName: "", lastName: "", email: "", phone: "",
    travelDate: "", travelers: 1, specialRequests: "",
  });

  const { data: tour, isLoading } = trpc.tours.bySlug.useQuery(slug, { enabled: !!slug });
  const createBooking = trpc.bookings.create.useMutation({
    onSuccess: (data) => {
      toast.success(`Booking submitted! Reference: ${data.bookingRef}`);
      setShowBooking(false);
    },
    onError: () => toast.error("Booking failed. Please try again."),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-t-transparent" style={{ borderColor: "oklch(0.45 0.14 240)", borderTopColor: "transparent" }} />
      </div>
    );
  }

  if (!tour) {
    return (
      <div className="min-h-screen pt-20 flex flex-col items-center justify-center gap-4">
        <div className="text-6xl">😕</div>
        <h2 className="font-display text-2xl font-bold text-gray-900">Tour not found</h2>
        <Link href="/tours"><Button className="rounded-xl" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>Browse All Tours</Button></Link>
      </div>
    );
  }

  const gallery = Array.isArray(tour.gallery) ? tour.gallery as string[] : [];
  const highlights = Array.isArray(tour.highlights) ? tour.highlights as string[] : [];
  const included = Array.isArray(tour.included) ? tour.included as string[] : [];
  const excluded = Array.isArray(tour.excluded) ? tour.excluded as string[] : [];
  const itinerary = Array.isArray(tour.itinerary) ? tour.itinerary as Array<{ day: number; title: string; description: string }> : [];
  const allImages = [tour.coverImage, ...gallery].filter(Boolean) as string[];

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const shareText = `Check out ${tour.title} on ViaTrek Tours!`;

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createBooking.mutate({
      tourId: tour.id,
      tourTitle: tour.title,
      bookingType: "tour",
      ...bookingForm,
    });
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="container py-4">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Link href="/" className="hover:text-ocean transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link href="/tours" className="hover:text-ocean transition-colors">Tours</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-gray-900 font-medium">{tour.title}</span>
        </div>
      </div>

      <div className="container pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left: Main Content */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <div className="rounded-2xl overflow-hidden mb-6">
              <div className="aspect-[16/9] relative">
                {allImages.length > 0 ? (
                  <img
                    src={allImages[activeImage]}
                    alt={tour.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                    <span className="text-gray-400">No image available</span>
                  </div>
                )}
              </div>
              {allImages.length > 1 && (
                <div className="flex gap-2 mt-2 overflow-x-auto pb-1">
                  {allImages.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveImage(i)}
                      className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                        i === activeImage ? "border-ocean scale-105" : "border-transparent opacity-70 hover:opacity-100"
                      }`}
                      style={i === activeImage ? { borderColor: "oklch(0.45 0.14 240)" } : {}}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Tour Header */}
            <div className="mb-6">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <span className="inline-block px-2.5 py-1 text-xs font-semibold rounded-full mb-2 bg-blue-100 capitalize"
                    style={{ color: "oklch(0.45 0.14 240)" }}>
                    {tour.category} Tour
                  </span>
                  <h1 className="font-display text-3xl md:text-4xl font-bold text-gray-900">{tour.title}</h1>
                </div>
                {tour.price && (
                  <div className="text-right flex-shrink-0">
                    <span className="text-xs text-gray-400">From</span>
                    <p className="font-bold text-2xl" style={{ color: "oklch(0.32 0.12 240)" }}>
                      ${Number(tour.price).toLocaleString()}
                    </p>
                    <span className="text-xs text-gray-400">{tour.priceUnit}</span>
                  </div>
                )}
              </div>

              {/* Meta */}
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                {tour.duration && (
                  <span className="flex items-center gap-1.5"><Clock className="w-4 h-4 text-turquoise" style={{ color: "oklch(0.72 0.14 195)" }} />{tour.duration}</span>
                )}
                {tour.maxGroupSize && (
                  <span className="flex items-center gap-1.5"><Users className="w-4 h-4" style={{ color: "oklch(0.72 0.14 195)" }} />Max {tour.maxGroupSize} people</span>
                )}
                {tour.availability && (
                  <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" style={{ color: "oklch(0.72 0.14 195)" }} />{tour.availability}</span>
                )}
                {tour.difficulty && (
                  <span className="flex items-center gap-1.5 capitalize">
                    <span className={`w-2 h-2 rounded-full ${tour.difficulty === "easy" ? "bg-green-400" : tour.difficulty === "moderate" ? "bg-yellow-400" : "bg-red-400"}`} />
                    {tour.difficulty} difficulty
                  </span>
                )}
              </div>

              {/* Social Share */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-400 flex items-center gap-1"><Share2 className="w-3 h-3" />Share:</span>
                <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs" style={{ background: "#1877F2" }}>
                  <Facebook className="w-3.5 h-3.5" />
                </a>
                <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs" style={{ background: "#1DA1F2" }}>
                  <Twitter className="w-3.5 h-3.5" />
                </a>
                <a href={`https://wa.me/?text=${encodeURIComponent(shareText + " " + shareUrl)}`} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs" style={{ background: "#25D366" }}>
                  <MessageCircle className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Description */}
            {tour.description && (
              <div className="mb-8">
                <h2 className="font-display text-xl font-bold text-gray-900 mb-3">About This Tour</h2>
                <p className="text-gray-600 leading-relaxed whitespace-pre-line">{tour.description}</p>
              </div>
            )}

            {/* Highlights */}
            {highlights.length > 0 && (
              <div className="mb-8">
                <h2 className="font-display text-xl font-bold text-gray-900 mb-3">Tour Highlights</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "oklch(0.55 0.16 195)" }} />
                      {h}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Included / Excluded */}
            {(included.length > 0 || excluded.length > 0) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                {included.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />What's Included
                    </h3>
                    <ul className="space-y-2">
                      {included.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {excluded.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-400" />Not Included
                    </h3>
                    <ul className="space-y-2">
                      {excluded.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-300 mt-1.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Itinerary */}
            {itinerary.length > 0 && (
              <div className="mb-8">
                <h2 className="font-display text-xl font-bold text-gray-900 mb-4">Itinerary</h2>
                <div className="space-y-4">
                  {itinerary.map((day) => (
                    <div key={day.day} className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold"
                        style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
                        {day.day}
                      </div>
                      <div className="flex-1 pb-4 border-b border-gray-100 last:border-0">
                        <h4 className="font-semibold text-gray-900 mb-1">Day {day.day}: {day.title}</h4>
                        <p className="text-gray-600 text-sm leading-relaxed">{day.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
                <div className="p-6" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
                  <h3 className="font-display text-xl font-bold text-white mb-1">Book This Tour</h3>
                  {tour.price && (
                    <p className="text-white/80 text-sm">From <span className="text-xl font-bold text-white">${Number(tour.price).toLocaleString()}</span> {tour.priceUnit}</p>
                  )}
                </div>

                {!showBooking ? (
                  <div className="p-6 space-y-3">
                    <Button
                      className="w-full rounded-xl font-semibold py-3"
                      style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}
                      onClick={() => setShowBooking(true)}
                    >
                      Book Now
                    </Button>
                    <a href={`${WHATSAPP_URL}?text=Hi, I'm interested in the ${tour.title} tour`} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" className="w-full rounded-xl font-semibold" style={{ borderColor: "#25D366", color: "#25D366" }}>
                        <MessageCircle className="w-4 h-4 mr-2" />
                        WhatsApp Inquiry
                      </Button>
                    </a>

                    {/* Quick Info */}
                    <div className="pt-4 border-t border-gray-100 space-y-3">
                      {tour.duration && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500 flex items-center gap-1.5"><Clock className="w-4 h-4" />Duration</span>
                          <span className="font-medium text-gray-900">{tour.duration}</span>
                        </div>
                      )}
                      {tour.maxGroupSize && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500 flex items-center gap-1.5"><Users className="w-4 h-4" />Group Size</span>
                          <span className="font-medium text-gray-900">Max {tour.maxGroupSize}</span>
                        </div>
                      )}
                      {tour.availability && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500 flex items-center gap-1.5"><Calendar className="w-4 h-4" />Availability</span>
                          <span className="font-medium text-gray-900">{tour.availability}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleBookingSubmit} className="p-6 space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-medium text-gray-700 mb-1 block">First Name *</label>
                        <Input required value={bookingForm.firstName} onChange={(e) => setBookingForm(p => ({ ...p, firstName: e.target.value }))} className="rounded-lg text-sm" />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-gray-700 mb-1 block">Last Name *</label>
                        <Input required value={bookingForm.lastName} onChange={(e) => setBookingForm(p => ({ ...p, lastName: e.target.value }))} className="rounded-lg text-sm" />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-700 mb-1 block">Email *</label>
                      <Input type="email" required value={bookingForm.email} onChange={(e) => setBookingForm(p => ({ ...p, email: e.target.value }))} className="rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-700 mb-1 block">Phone / WhatsApp</label>
                      <Input value={bookingForm.phone} onChange={(e) => setBookingForm(p => ({ ...p, phone: e.target.value }))} className="rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-700 mb-1 block">Travel Date</label>
                      <Input type="date" value={bookingForm.travelDate} onChange={(e) => setBookingForm(p => ({ ...p, travelDate: e.target.value }))} className="rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-700 mb-1 block">Number of Travelers</label>
                      <Input type="number" min={1} value={bookingForm.travelers} onChange={(e) => setBookingForm(p => ({ ...p, travelers: parseInt(e.target.value) || 1 }))} className="rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-gray-700 mb-1 block">Special Requests</label>
                      <Textarea value={bookingForm.specialRequests} onChange={(e) => setBookingForm(p => ({ ...p, specialRequests: e.target.value }))} className="rounded-lg text-sm" rows={3} />
                    </div>
                    <Button type="submit" disabled={createBooking.isPending} className="w-full rounded-xl font-semibold"
                      style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}>
                      {createBooking.isPending ? "Submitting..." : "Submit Booking"}
                    </Button>
                    <button type="button" onClick={() => setShowBooking(false)} className="w-full text-xs text-gray-400 hover:text-gray-600 transition-colors">
                      Cancel
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
