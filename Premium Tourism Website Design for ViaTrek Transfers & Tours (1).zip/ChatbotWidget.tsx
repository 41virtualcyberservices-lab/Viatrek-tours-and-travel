import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, User, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! 👋 Welcome to ViaTrek Tours! I'm your travel assistant. How can I help you plan your Kenya adventure today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [leadForm, setLeadForm] = useState<{ name: string; email: string; phone: string } | null>(null);
  const [leadData, setLeadData] = useState({ name: "", email: "", phone: "" });
  const [showLeadForm, setShowLeadForm] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chat = trpc.chatbot.chat.useMutation({
    onSuccess: (data) => {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: typeof data.reply === "string" ? data.reply : String(data.reply),
        timestamp: new Date(),
      }]);
      // Show lead form after 3 messages
      if (messages.length >= 3 && !leadForm) {
        setTimeout(() => setShowLeadForm(true), 1500);
      }
    },
    onError: () => {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble connecting right now. Please WhatsApp us directly at +254701475532 for immediate assistance!",
        timestamp: new Date(),
      }]);
    },
  });

  const submitLead = trpc.chatbot.saveLead.useMutation({
    onSuccess: () => {
      setShowLeadForm(false);
      setLeadForm(leadData);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: `Thank you, ${leadData.name}! Our team will reach out to you shortly. In the meantime, feel free to ask me anything about our tours!`,
        timestamp: new Date(),
      }]);
      toast.success("We'll be in touch soon!");
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, showLeadForm]);

  const sendMessage = () => {
    if (!input.trim() || chat.isPending) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg, timestamp: new Date() }]);
    chat.mutate({
      message: userMsg,
      history: messages.slice(-6).map(m => ({ role: m.role, content: m.content })),
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const quickReplies = [
    "What tours do you offer?",
    "Beach packages in Diani",
    "Safari to Maasai Mara",
    "Airport transfers",
    "Prices & availability",
  ];

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setOpen(prev => !prev)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-2xl flex items-center justify-center text-white transition-all duration-300 hover:scale-110 active:scale-95"
        style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}
        aria-label="Open chat"
      >
        {open ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
        {!open && messages.length > 1 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
            {Math.min(messages.length - 1, 9)}
          </span>
        )}
      </button>

      {/* Chat Window */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden"
          style={{ maxHeight: "500px", animation: "slideUp 0.2s cubic-bezier(0.23,1,0.32,1)" }}>
          {/* Header */}
          <div className="p-4 text-white flex items-center gap-3 flex-shrink-0"
            style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold text-sm">ViaTrek Assistant</p>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs text-white/80">Online · Typically replies instantly</span>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
                <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                  msg.role === "assistant"
                    ? "text-white"
                    : "bg-gray-200"
                }`}
                  style={msg.role === "assistant" ? { background: "oklch(0.55 0.16 195)" } : {}}>
                  {msg.role === "assistant" ? <Bot className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5 text-gray-600" />}
                </div>
                <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                  msg.role === "user"
                    ? "text-white rounded-tr-sm"
                    : "bg-gray-100 text-gray-800 rounded-tl-sm"
                }`}
                  style={msg.role === "user" ? { background: "oklch(0.45 0.14 240)" } : {}}>
                  {msg.content}
                </div>
              </div>
            ))}

            {chat.isPending && (
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-white flex-shrink-0"
                  style={{ background: "oklch(0.55 0.16 195)" }}>
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-3 py-2">
                  <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                </div>
              </div>
            )}

            {/* Lead Capture Form */}
            {showLeadForm && !leadForm && (
              <div className="bg-blue-50 rounded-xl p-3 border border-blue-200">
                <p className="text-xs font-semibold text-blue-800 mb-2">Get a personalized quote!</p>
                <div className="space-y-2">
                  <Input value={leadData.name} onChange={e => setLeadData(p => ({ ...p, name: e.target.value }))}
                    className="h-8 text-xs rounded-lg" placeholder="Your name" />
                  <Input value={leadData.email} onChange={e => setLeadData(p => ({ ...p, email: e.target.value }))}
                    className="h-8 text-xs rounded-lg" placeholder="Email address" type="email" />
                  <Input value={leadData.phone} onChange={e => setLeadData(p => ({ ...p, phone: e.target.value }))}
                    className="h-8 text-xs rounded-lg" placeholder="Phone / WhatsApp" />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => submitLead.mutate({ ...leadData, interest: messages[messages.length - 1]?.content })}
                      disabled={submitLead.isPending || !leadData.name}
                      className="flex-1 h-7 text-xs rounded-lg text-white" style={{ background: "oklch(0.45 0.14 240)" }}>
                      {submitLead.isPending ? "Sending..." : "Get Quote"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setShowLeadForm(false)} className="h-7 text-xs rounded-lg">Skip</Button>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Replies */}
          {messages.length <= 1 && (
            <div className="px-3 pb-2 flex gap-1.5 flex-wrap flex-shrink-0">
              {quickReplies.map(q => (
                <button key={q} onClick={() => { setInput(q); }}
                  className="text-xs px-2.5 py-1 rounded-full border border-gray-200 text-gray-600 hover:border-ocean hover:text-ocean transition-colors bg-white">
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="p-3 border-t border-gray-100 flex gap-2 flex-shrink-0">
            <Input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about tours, prices..."
              className="flex-1 rounded-xl text-sm h-9"
              disabled={chat.isPending}
            />
            <Button
              onClick={sendMessage}
              disabled={!input.trim() || chat.isPending}
              size="sm"
              className="rounded-xl h-9 w-9 p-0 text-white flex-shrink-0"
              style={{ background: "oklch(0.45 0.14 240)" }}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </>
  );
}
