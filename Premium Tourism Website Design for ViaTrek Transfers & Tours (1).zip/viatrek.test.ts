import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock context helpers ───────────────────────────────────────────────────

function makePublicCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function makeAdminCtx(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@viatrek.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

// ─── Auth tests ──────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user for authenticated users", async () => {
    const caller = appRouter.createCaller(makeAdminCtx());
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.role).toBe("admin");
  });
});

// ─── Tours tests ─────────────────────────────────────────────────────────────

describe("tours.list", () => {
  it("returns an array (public procedure)", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.tours.list({});
    expect(Array.isArray(result)).toBe(true);
  });

  it("filters by category", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.tours.list({ category: "beach" });
    expect(Array.isArray(result)).toBe(true);
    result.forEach(t => expect(t.category).toBe("beach"));
  });

  it("filters by featured", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.tours.list({ featured: true });
    expect(Array.isArray(result)).toBe(true);
    result.forEach(t => expect(t.featured).toBe(true));
  });
});

describe("tours.getBySlug", () => {
  it("returns null for non-existent slug", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    let result: unknown = null;
    try { result = await caller.tours.bySlug("non-existent-slug-xyz"); } catch { result = null; }
    expect(result).toBeNull();
  });
});

// ─── Destinations tests ───────────────────────────────────────────────────────

describe("destinations.list", () => {
  it("returns an array", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.destinations.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});

// ─── Gallery tests ────────────────────────────────────────────────────────────

describe("gallery.list", () => {
  it("returns an array of gallery items", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.gallery.list({});
    expect(Array.isArray(result)).toBe(true);
  });

  it("filters by type photo", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.gallery.list({ type: "photo" });
    expect(Array.isArray(result)).toBe(true);
    result.forEach(item => expect(item.type).toBe("photo"));
  });
});

// ─── Blog tests ───────────────────────────────────────────────────────────────

describe("blog.list", () => {
  it("returns an array of blog posts", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.blog.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("blog.getBySlug", () => {
  it("returns null for non-existent slug", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    let result: unknown = null;
    try { result = await caller.blog.bySlug("non-existent-xyz"); } catch { result = null; }
    expect(result).toBeNull();
  });
});

// ─── Chatbot tests ────────────────────────────────────────────────────────────

describe("chatbot.faqs", () => {
  it("returns an array of FAQs", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.chatbot.faqs();
    expect(Array.isArray(result)).toBe(true);
  });
});

// ─── Newsletter tests ─────────────────────────────────────────────────────────

describe("newsletter.subscribe", () => {
  it("rejects invalid email", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    await expect(caller.newsletter.subscribe({ email: "not-an-email" }))
      .rejects.toThrow();
  });
});

// ─── Settings tests ───────────────────────────────────────────────────────────

describe("settings.getAll", () => {
  it("returns an array of settings", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    const result = await caller.settings.getAll();
    expect(Array.isArray(result)).toBe(true);
  });
});

// ─── Bookings admin guard ─────────────────────────────────────────────────────

describe("bookings.list (admin guard)", () => {
  it("throws UNAUTHORIZED for non-admin users", async () => {
    const userCtx: TrpcContext = {
      ...makePublicCtx(),
      user: {
        id: 2,
        openId: "regular-user",
        email: "user@example.com",
        name: "Regular User",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
    };
    const caller = appRouter.createCaller(userCtx);
    await expect(caller.bookings.list({})).rejects.toThrow();
  });
});

// ─── Contact form tests ───────────────────────────────────────────────────────

describe("contact.submit", () => {
  it("rejects empty name", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    await expect(
      caller.contact.submit({ name: "", email: "test@test.com", message: "Hello" })
    ).rejects.toThrow();
  });

  it("rejects invalid email", async () => {
    const caller = appRouter.createCaller(makePublicCtx());
    await expect(
      caller.contact.submit({ name: "Test", email: "bad-email", message: "Hello" })
    ).rejects.toThrow();
  });
});
