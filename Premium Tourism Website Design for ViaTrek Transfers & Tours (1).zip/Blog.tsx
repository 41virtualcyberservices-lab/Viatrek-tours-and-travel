import { useState } from "react";
import { Link } from "wouter";
import { Calendar, User, Eye, Tag, ArrowRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

const PLACEHOLDER_POSTS = [
  { id: 1, title: "Top 10 Things to Do in Diani Beach", slug: "top-10-diani-beach", excerpt: "Diani Beach is one of Kenya's most stunning coastal destinations. Here's your ultimate guide to making the most of your visit.", coverImage: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80", category: "Travel Guide", author: "ViaTrek Team", views: 1240, createdAt: new Date("2024-01-15") },
  { id: 2, title: "Ultimate Guide to Maasai Mara Safari", slug: "maasai-mara-safari-guide", excerpt: "Planning your first Maasai Mara safari? This comprehensive guide covers everything from the best time to visit to what to pack.", coverImage: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&q=80", category: "Safari Tips", author: "ViaTrek Team", views: 2100, createdAt: new Date("2024-02-10") },
  { id: 3, title: "Mombasa Old Town: A Cultural Journey", slug: "mombasa-old-town-guide", excerpt: "Step back in time as you explore the winding streets of Mombasa's Old Town, a UNESCO World Heritage Site.", coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80", category: "Cultural", author: "ViaTrek Team", views: 890, createdAt: new Date("2024-03-05") },
  { id: 4, title: "Kenya's Best Honeymoon Destinations", slug: "kenya-honeymoon-destinations", excerpt: "From private beach resorts to romantic bush lodges, Kenya offers some of the world's most magical honeymoon experiences.", coverImage: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&q=80", category: "Honeymoon", author: "ViaTrek Team", views: 1560, createdAt: new Date("2024-03-20") },
  { id: 5, title: "Packing Guide for Kenya Safari", slug: "kenya-safari-packing-guide", excerpt: "What to pack for your Kenya safari? Our expert guide covers everything from clothing to camera gear.", coverImage: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&q=80", category: "Travel Tips", author: "ViaTrek Team", views: 3200, createdAt: new Date("2024-04-01") },
  { id: 6, title: "Family Safari in Amboseli: What to Expect", slug: "family-safari-amboseli", excerpt: "Amboseli National Park is one of Kenya's best family safari destinations. Here's what you need to know.", coverImage: "https://images.unsplash.com/photo-1589825743636-e1a9b1e2d0a3?w=600&q=80", category: "Family Travel", author: "ViaTrek Team", views: 780, createdAt: new Date("2024-04-15") },
];

export default function Blog() {
  const [activeCategory, setActiveCategory] = useState("");
  const { data: posts = [] } = trpc.blog.list.useQuery({ category: activeCategory || undefined });

  const displayPosts = posts.length > 0 ? posts : PLACEHOLDER_POSTS;
  const categories = ["", "Travel Guide", "Safari Tips", "Cultural", "Travel Tips", "Family Travel", "Honeymoon"];

  return (
    <div className="min-h-screen pt-20">
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Travel Inspiration
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Travel Blog</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Expert travel guides, tips, and stories from Kenya's most incredible destinations.
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="sticky top-16 z-30 bg-white border-b border-gray-100 shadow-sm">
        <div className="container py-4">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${activeCategory === cat ? "text-white" : "bg-gray-100 text-gray-600"}`}
                style={activeCategory === cat ? { background: "oklch(0.45 0.14 240)" } : {}}>
                {cat || "All Posts"}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayPosts.map((post: any) => (
            <Link key={post.id} href={`/blog/${post.slug}`} className="group block">
              <article className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
                <div className="aspect-[16/10] overflow-hidden relative">
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  {post.category && (
                    <div className="absolute top-3 left-3">
                      <span className="px-2.5 py-1 text-xs font-semibold rounded-full text-white"
                        style={{ background: "oklch(0.45 0.14 240 / 0.85)" }}>
                        {post.category}
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-display font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-ocean transition-colors"
                    style={{ fontFamily: "var(--font-display)" }}>
                    {post.title}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4 line-clamp-2">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <User className="w-3.5 h-3.5" />{post.author || "ViaTrek Team"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(post.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </span>
                    </div>
                    {post.views > 0 && (
                      <span className="flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" />{post.views.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              </article>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
