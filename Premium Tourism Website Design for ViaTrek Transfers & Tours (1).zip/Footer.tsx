import { Link } from "wouter";
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, MessageCircle, Send } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { SITE_NAME, CONTACT_EMAIL, CONTACT_PHONE, WHATSAPP_URL, SOCIAL_LINKS } from "@/lib/constants";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Footer() {
  const [email, setEmail] = useState("");
  const subscribe = trpc.newsletter.subscribe.useMutation({
    onSuccess: () => {
      toast.success("You've subscribed to our newsletter!");
      setEmail("");
    },
    onError: () => toast.error("Subscription failed. Please try again."),
  });

  return (
    <footer className="bg-ocean-dark text-white" style={{ background: "oklch(0.18 0.08 240)" }}>
      {/* Newsletter Banner */}
      <div className="bg-turquoise-gradient py-10" style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-display text-2xl font-bold text-white mb-1">Stay Updated on Kenya Travel</h3>
              <p className="text-white/80 text-sm">Get exclusive deals, travel tips, and destination guides.</p>
            </div>
            <form
              className="flex gap-2 w-full md:w-auto"
              onSubmit={(e) => {
                e.preventDefault();
                if (email) subscribe.mutate({ email });
              }}
            >
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 min-w-64 focus:bg-white/30"
                required
              />
              <Button
                type="submit"
                disabled={subscribe.isPending}
                className="bg-white text-ocean font-semibold hover:bg-white/90 flex-shrink-0"
                style={{ color: "oklch(0.32 0.12 240)" }}
              >
                <Send className="w-4 h-4 mr-1" />
                Subscribe
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-14">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl bg-turquoise-gradient flex items-center justify-center" style={{ background: "linear-gradient(135deg, oklch(0.72 0.14 195), oklch(0.55 0.16 195))" }}>
                  <span className="text-white font-bold text-sm font-display">VT</span>
                </div>
                <span className="font-display font-bold text-xl text-white">{SITE_NAME}</span>
              </div>
              <p className="text-white/70 text-sm leading-relaxed mb-5">
                Your trusted partner for premium travel experiences across Kenya. Coastal adventures, safari thrills, and cultural journeys await.
              </p>
              <div className="flex gap-3">
                {[
                  { href: SOCIAL_LINKS.facebook, icon: Facebook, label: "Facebook" },
                  { href: SOCIAL_LINKS.twitter, icon: Twitter, label: "Twitter" },
                  { href: SOCIAL_LINKS.instagram, icon: Instagram, label: "Instagram" },
                  { href: WHATSAPP_URL, icon: MessageCircle, label: "WhatsApp" },
                ].map(({ href, icon: Icon, label }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    className="w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-200 hover:scale-110"
                    style={{ background: "oklch(0.28 0.06 240)" }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "oklch(0.55 0.16 195)")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "oklch(0.28 0.06 240)")}
                  >
                    <Icon className="w-4 h-4 text-white" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-display font-semibold text-white mb-4 text-lg">Quick Links</h4>
              <ul className="space-y-2">
                {[
                  { label: "Home", href: "/" },
                  { label: "Tours & Safaris", href: "/tours" },
                  { label: "Destinations", href: "/destinations" },
                  { label: "Transfers", href: "/transfers" },
                  { label: "Gallery", href: "/gallery" },
                  { label: "Blog", href: "/blog" },
                  { label: "About Us", href: "/about" },
                  { label: "Contact", href: "/contact" },
                ].map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-white/70 hover:text-white text-sm transition-colors duration-200 flex items-center gap-1"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-turquoise flex-shrink-0" style={{ background: "oklch(0.72 0.14 195)" }} />
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Tour Categories */}
            <div>
              <h4 className="font-display font-semibold text-white mb-4 text-lg">Our Tours</h4>
              <ul className="space-y-2">
                {[
                  "Beach Tours", "Safari Tours", "Cultural Tours", "City Tours",
                  "Family Tours", "Honeymoon Packages", "Corporate Tours", "Adventure Tours",
                ].map((cat) => (
                  <li key={cat}>
                    <Link
                      href={`/tours?category=${cat.toLowerCase().split(" ")[0]}`}
                      className="text-white/70 hover:text-white text-sm transition-colors duration-200 flex items-center gap-1"
                    >
                      <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "oklch(0.78 0.16 75)" }} />
                      {cat}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="font-display font-semibold text-white mb-4 text-lg">Contact Us</h4>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: "oklch(0.72 0.14 195)" }} />
                  <span className="text-white/70 text-sm">Mombasa, Coastal Kenya<br />Serving all of Kenya</span>
                </li>
                <li>
                  <a href={`tel:${CONTACT_PHONE}`} className="flex items-center gap-3 text-white/70 hover:text-white text-sm transition-colors duration-200">
                    <Phone className="w-5 h-5 flex-shrink-0" style={{ color: "oklch(0.72 0.14 195)" }} />
                    {CONTACT_PHONE}
                  </a>
                </li>
                <li>
                  <a href={`mailto:${CONTACT_EMAIL}`} className="flex items-center gap-3 text-white/70 hover:text-white text-sm transition-colors duration-200">
                    <Mail className="w-5 h-5 flex-shrink-0" style={{ color: "oklch(0.72 0.14 195)" }} />
                    {CONTACT_EMAIL}
                  </a>
                </li>
                <li>
                  <a
                    href={WHATSAPP_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:opacity-90"
                    style={{ background: "#25D366", color: "white" }}
                  >
                    <MessageCircle className="w-4 h-4" />
                    Chat on WhatsApp
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t py-5" style={{ borderColor: "oklch(0.28 0.06 240)" }}>
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-white/50">
          <p>© {new Date().getFullYear()} {SITE_NAME}. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-white/80 transition-colors duration-200">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-white/80 transition-colors duration-200">Terms of Service</Link>
            <Link href="/sitemap.xml" className="hover:text-white/80 transition-colors duration-200">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
