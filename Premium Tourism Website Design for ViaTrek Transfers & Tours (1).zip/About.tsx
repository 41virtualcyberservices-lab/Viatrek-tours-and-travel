import { Link } from "wouter";
import { Target, Eye, Heart, Award, Users, Globe, Shield } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

const VALUES = [
  { icon: Heart, title: "Passion", desc: "We are passionate about Kenya and share that enthusiasm with every traveler." },
  { icon: Shield, title: "Integrity", desc: "Transparent pricing, honest advice, and reliable service — always." },
  { icon: Globe, title: "Sustainability", desc: "We promote responsible tourism that benefits local communities and wildlife." },
  { icon: Award, title: "Excellence", desc: "We hold ourselves to the highest standards in every aspect of your journey." },
];

export default function About() {
  const { data: teamMembers = [] } = trpc.team.list.useQuery();

  const PLACEHOLDER_TEAM = [
    { id: 1, name: "David Mwangi", role: "Founder & CEO", bio: "With over 15 years in Kenya tourism, David founded ViaTrek with a vision to share Kenya's beauty with the world.", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80" },
    { id: 2, name: "Grace Akinyi", role: "Head of Operations", bio: "Grace ensures every tour runs smoothly, coordinating with our network of guides, hotels, and partners.", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80" },
    { id: 3, name: "Samuel Odhiambo", role: "Lead Safari Guide", bio: "Samuel is a certified wildlife expert with deep knowledge of Kenya's national parks and ecosystems.", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80" },
    { id: 4, name: "Fatuma Hassan", role: "Customer Experience", bio: "Fatuma is dedicated to ensuring every client has a seamless and memorable experience from inquiry to return.", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80" },
  ];

  const team = teamMembers.length > 0 ? teamMembers : PLACEHOLDER_TEAM;

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">About ViaTrek Tours</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Your trusted partner for premium Kenya travel experiences since 2014.
          </p>
        </div>
      </div>

      {/* Story */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-4"
                style={{ background: "oklch(0.72 0.14 195 / 0.12)", color: "oklch(0.45 0.14 240)" }}>
                Our Story
              </span>
              <h2 className="font-display text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Born from a Love of Kenya
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  ViaTrek Tours was founded in Mombasa with a simple but powerful vision: to share the extraordinary beauty and diversity of Kenya with travelers from around the world. What started as a small coastal tour operation has grown into one of Kenya's most trusted travel companies.
                </p>
                <p>
                  Our team of passionate Kenyan travel experts brings together decades of combined experience in tourism, wildlife conservation, and hospitality. We believe that travel, done right, can transform lives — both for our guests and for the local communities we serve.
                </p>
                <p>
                  From the pristine beaches of Diani to the vast plains of the Maasai Mara, from the cultural richness of Mombasa's Old Town to the snow-capped peaks of Mount Kenya — we are your gateway to it all.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=500&q=80" alt="Safari" className="rounded-2xl object-cover aspect-square" />
              <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&q=80" alt="Beach" className="rounded-2xl object-cover aspect-square mt-8" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20" style={{ background: "oklch(0.96 0.03 85)" }}>
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                style={{ background: "oklch(0.45 0.14 240 / 0.1)" }}>
                <Target className="w-6 h-6" style={{ color: "oklch(0.45 0.14 240)" }} />
              </div>
              <h3 className="font-display text-xl font-bold text-gray-900 mb-3">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide exceptional, sustainable travel experiences that connect visitors with Kenya's natural wonders, rich cultures, and warm people — creating memories that last a lifetime.
              </p>
            </div>
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                style={{ background: "oklch(0.72 0.14 195 / 0.1)" }}>
                <Eye className="w-6 h-6" style={{ color: "oklch(0.72 0.14 195)" }} />
              </div>
              <h3 className="font-display text-xl font-bold text-gray-900 mb-3">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                To be East Africa's most trusted and innovative tour operator, setting the standard for responsible luxury travel while empowering local communities and conserving Kenya's natural heritage.
              </p>
            </div>
          </div>

          <h2 className="font-display text-3xl font-bold text-gray-900 text-center mb-10">Our Core Values</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {VALUES.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="bg-white rounded-2xl p-6 shadow-sm text-center">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
                  style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195 / 0.15), oklch(0.45 0.14 240 / 0.15))" }}>
                  <Icon className="w-6 h-6" style={{ color: "oklch(0.45 0.14 240)" }} />
                </div>
                <h4 className="font-display font-bold text-gray-900 mb-2">{title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "5,000+", label: "Happy Travelers" },
              { value: "10+", label: "Years Experience" },
              { value: "50+", label: "Tour Packages" },
              { value: "4.9/5", label: "Average Rating" },
            ].map(({ value, label }) => (
              <div key={label}>
                <p className="font-display text-4xl font-bold mb-2" style={{ color: "oklch(0.78 0.16 75)" }}>{value}</p>
                <p className="text-white/70">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
              style={{ background: "oklch(0.72 0.14 195 / 0.12)", color: "oklch(0.45 0.14 240)" }}>
              Our People
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">
              Passionate Kenyan travel experts dedicated to making your journey extraordinary.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member: any) => (
              <div key={member.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 text-center">
                <div className="aspect-square overflow-hidden">
                  {member.avatar ? (
                    <img src={member.avatar} alt={member.name} className="w-full h-full object-cover" loading="lazy" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white text-4xl font-bold"
                      style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
                      {member.name.charAt(0)}
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h4 className="font-display font-bold text-gray-900 text-lg">{member.name}</h4>
                  <p className="text-sm font-medium mb-2" style={{ color: "oklch(0.72 0.14 195)" }}>{member.role}</p>
                  {member.bio && <p className="text-gray-500 text-xs leading-relaxed">{member.bio}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
