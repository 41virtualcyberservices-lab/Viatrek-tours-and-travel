import { useRoute, Link } from "wouter";
import { Calendar, User, Eye, Share2, Facebook, Twitter, MessageCircle, ArrowLeft, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

export default function BlogDetail() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug || "";

  const { data: post, isLoading } = trpc.blog.bySlug.useQuery(slug, { enabled: !!slug });

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-t-transparent" style={{ borderColor: "oklch(0.45 0.14 240)", borderTopColor: "transparent" }} />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen pt-20 flex flex-col items-center justify-center gap-4">
        <h2 className="font-display text-2xl font-bold text-gray-900">Post not found</h2>
        <Link href="/blog"><Button className="rounded-xl" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>Back to Blog</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="container py-4">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Link href="/" className="hover:text-ocean transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link href="/blog" className="hover:text-ocean transition-colors">Blog</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-gray-900 font-medium line-clamp-1">{post.title}</span>
        </div>
      </div>

      <div className="container pb-16 max-w-4xl">
        {/* Cover Image */}
        {post.coverImage && (
          <div className="rounded-2xl overflow-hidden aspect-[16/7] mb-8">
            <img src={post.coverImage} alt={post.title} className="w-full h-full object-cover" />
          </div>
        )}

        {/* Header */}
        <div className="mb-8">
          {post.category && (
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full mb-4"
              style={{ background: "oklch(0.45 0.14 240 / 0.1)", color: "oklch(0.45 0.14 240)" }}>
              {post.category}
            </span>
          )}
          <h1 className="font-display text-3xl md:text-4xl font-bold text-gray-900 mb-4">{post.title}</h1>
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
            <span className="flex items-center gap-1.5"><User className="w-4 h-4" />{post.author || "ViaTrek Team"}</span>
            <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" />
              {new Date(post.createdAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
            </span>
            {(post.views || 0) > 0 && <span className="flex items-center gap-1.5"><Eye className="w-4 h-4" />{post.views?.toLocaleString()} views</span>}
          </div>

          {/* Social Share */}
          <div className="flex items-center gap-3 pb-6 border-b border-gray-100">
            <span className="text-sm text-gray-500 flex items-center gap-1.5"><Share2 className="w-4 h-4" />Share this article:</span>
            <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-opacity hover:opacity-90" style={{ background: "#1877F2" }}>
              <Facebook className="w-3.5 h-3.5" /> Facebook
            </a>
            <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-opacity hover:opacity-90" style={{ background: "#1DA1F2" }}>
              <Twitter className="w-3.5 h-3.5" /> Twitter
            </a>
            <a href={`https://wa.me/?text=${encodeURIComponent(post.title + " " + shareUrl)}`} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-opacity hover:opacity-90" style={{ background: "#25D366" }}>
              <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
            </a>
          </div>
        </div>

        {/* Content */}
        <div className="prose max-w-none">
          {post.content ? (
            <div className="text-gray-700 leading-relaxed whitespace-pre-line">{post.content}</div>
          ) : (
            <p className="text-gray-500 italic">Content coming soon...</p>
          )}
        </div>

        {/* Tags */}
        {Array.isArray(post.tags) && (post.tags as string[]).length > 0 && (
          <div className="mt-8 pt-6 border-t border-gray-100">
            <div className="flex flex-wrap gap-2">
              {(post.tags as string[]).map((tag, i) => (
                <span key={i} className="px-3 py-1 text-xs font-medium rounded-full"
                  style={{ background: "oklch(0.96 0.03 85)", color: "oklch(0.45 0.14 240)" }}>
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Back Link */}
        <div className="mt-10">
          <Link href="/blog">
            <Button variant="outline" className="rounded-xl" style={{ borderColor: "oklch(0.72 0.14 195)", color: "oklch(0.45 0.14 240)" }}>
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
