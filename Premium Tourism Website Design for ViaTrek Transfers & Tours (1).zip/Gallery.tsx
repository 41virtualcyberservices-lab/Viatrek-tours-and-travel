import { useState } from "react";
import { X, ZoomIn, Play, ChevronLeft, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

const PLACEHOLDER_IMAGES = [
  { url: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=800&q=80", title: "Maasai Mara Safari", category: "Safari" },
  { url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80", title: "Diani Beach", category: "Beach" },
  { url: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=800&q=80", title: "Amboseli Elephants", category: "Wildlife" },
  { url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&q=80", title: "Mombasa Old Town", category: "Cultural" },
  { url: "https://images.unsplash.com/photo-1589825743636-e1a9b1e2d0a3?w=800&q=80", title: "Great Migration", category: "Safari" },
  { url: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80", title: "Watamu Marine Park", category: "Beach" },
  { url: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=800&q=80", title: "Nairobi Skyline", category: "City" },
  { url: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=800&q=80", title: "Lake Naivasha", category: "Nature" },
  { url: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=800&q=80", title: "Group Adventure", category: "Adventure" },
  { url: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&q=80", title: "Family Safari", category: "Family" },
  { url: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80", title: "Corporate Event", category: "Corporate" },
  { url: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80", title: "VIP Transfer", category: "Transfer" },
];

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeType, setActiveType] = useState("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const { data: galleryItems = [] } = trpc.gallery.list.useQuery({
    category: activeCategory !== "All" ? activeCategory : undefined,
    type: activeType !== "all" ? activeType : undefined,
  });

  const items = galleryItems.length > 0
    ? galleryItems.map(g => ({ url: g.url, title: g.title || "", category: g.category || "General", type: g.type || "photo" }))
    : PLACEHOLDER_IMAGES.map(p => ({ ...p, type: "photo" as const }));

  const categories = ["All", ...Array.from(new Set(items.map(i => i.category)))];

  const filtered = activeCategory === "All" ? items : items.filter(i => i.category === activeCategory);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);
  const prevImage = () => setLightboxIndex(prev => prev !== null ? (prev - 1 + filtered.length) % filtered.length : null);
  const nextImage = () => setLightboxIndex(prev => prev !== null ? (prev + 1) % filtered.length : null);

  return (
    <div className="min-h-screen pt-20">
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Visual Stories
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Our Gallery</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Moments captured across Kenya's most stunning landscapes and adventures.
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-white border-b border-gray-100 shadow-sm">
        <div className="container py-4">
          <div className="flex flex-wrap gap-2 items-center">
            <div className="flex gap-2 mr-4">
              {["all", "photo", "video"].map(t => (
                <button key={t} onClick={() => setActiveType(t)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 capitalize ${activeType === t ? "text-white" : "bg-gray-100 text-gray-600"}`}
                  style={activeType === t ? { background: "oklch(0.45 0.14 240)" } : {}}>
                  {t === "all" ? "All Media" : t === "photo" ? "📷 Photos" : "🎥 Videos"}
                </button>
              ))}
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {categories.map(cat => (
                <button key={cat} onClick={() => setActiveCategory(cat)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${activeCategory === cat ? "text-white" : "bg-gray-100 text-gray-600"}`}
                  style={activeCategory === cat ? { background: "oklch(0.72 0.14 195)" } : {}}>
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="container py-12">
        <div className="columns-2 md:columns-3 lg:columns-4 gap-3 space-y-3">
          {filtered.map((item, i) => (
            <div
              key={i}
              className="group relative overflow-hidden rounded-xl cursor-pointer break-inside-avoid"
              onClick={() => openLightbox(i)}
            >
              <img
                src={item.url}
                alt={item.title}
                className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center gap-2">
                  {item.type === "video" ? (
                    <Play className="w-8 h-8 text-white" />
                  ) : (
                    <ZoomIn className="w-8 h-8 text-white" />
                  )}
                  {item.title && <span className="text-white text-xs font-medium text-center px-2">{item.title}</span>}
                </div>
              </div>
              {item.type === "video" && (
                <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center">
                  <Play className="w-3 h-3 text-white" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button onClick={(e) => { e.stopPropagation(); closeLightbox(); }}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10">
            <X className="w-5 h-5" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); prevImage(); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); nextImage(); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10">
            <ChevronRight className="w-5 h-5" />
          </button>

          <div className="max-w-5xl max-h-[90vh] mx-4" onClick={e => e.stopPropagation()}>
            <img
              src={filtered[lightboxIndex]?.url}
              alt={filtered[lightboxIndex]?.title}
              className="max-w-full max-h-[85vh] object-contain rounded-xl"
            />
            {filtered[lightboxIndex]?.title && (
              <p className="text-white/70 text-sm text-center mt-3">{filtered[lightboxIndex].title}</p>
            )}
            <p className="text-white/40 text-xs text-center mt-1">{lightboxIndex + 1} / {filtered.length}</p>
          </div>
        </div>
      )}
    </div>
  );
}
