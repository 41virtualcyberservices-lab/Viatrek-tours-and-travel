import { useState } from "react";
import { Mail, Phone, MapPin, MessageCircle, Facebook, Instagram, Twitter, Send, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { MapView } from "@/components/Map";
import { CONTACT_EMAIL, CONTACT_PHONE, WHATSAPP_URL } from "@/lib/constants";

export default function Contact() {
  const [form, setForm] = useState({
    name: "", email: "", phone: "", subject: "", message: "", inquiryType: "general",
  });
  const [mapReady, setMapReady] = useState(false);

  const submitContact = trpc.contact.submit.useMutation({
    onSuccess: () => {
      toast.success("Message sent! We'll get back to you within 24 hours.");
      setForm({ name: "", email: "", phone: "", subject: "", message: "", inquiryType: "general" });
    },
    onError: () => toast.error("Failed to send message. Please try again or WhatsApp us directly."),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitContact.mutate(form);
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Get In Touch
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Contact Us</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            Ready to plan your Kenya adventure? Our team is here to help you every step of the way.
          </p>
        </div>
      </div>

      <div className="container py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Contact Info */}
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold text-gray-900 mb-6">Get In Touch</h2>
              <div className="space-y-4">
                <a href={`mailto:${CONTACT_EMAIL}`} className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 group">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "oklch(0.45 0.14 240 / 0.1)" }}>
                    <Mail className="w-5 h-5" style={{ color: "oklch(0.45 0.14 240)" }} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">Email Us</p>
                    <p className="font-semibold text-gray-900 group-hover:text-ocean transition-colors text-sm">{CONTACT_EMAIL}</p>
                  </div>
                </a>

                <a href={`tel:${CONTACT_PHONE}`} className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 group">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "oklch(0.72 0.14 195 / 0.1)" }}>
                    <Phone className="w-5 h-5" style={{ color: "oklch(0.72 0.14 195)" }} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">Call Us</p>
                    <p className="font-semibold text-gray-900 group-hover:text-turquoise transition-colors text-sm">{CONTACT_PHONE}</p>
                  </div>
                </a>

                <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                  className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 group">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "#25D36620" }}>
                    <MessageCircle className="w-5 h-5" style={{ color: "#25D366" }} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">WhatsApp</p>
                    <p className="font-semibold text-gray-900 group-hover:text-green-600 transition-colors text-sm">{CONTACT_PHONE}</p>
                  </div>
                </a>

                <div className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "oklch(0.78 0.16 75 / 0.1)" }}>
                    <MapPin className="w-5 h-5" style={{ color: "oklch(0.78 0.16 75)" }} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">Location</p>
                    <p className="font-semibold text-gray-900 text-sm">Mombasa, Kenya</p>
                    <p className="text-gray-500 text-xs">Coastal Kenya</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "oklch(0.55 0.16 195 / 0.1)" }}>
                    <Clock className="w-5 h-5" style={{ color: "oklch(0.55 0.16 195)" }} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">Business Hours</p>
                    <p className="font-semibold text-gray-900 text-sm">Mon–Sat: 8am – 6pm</p>
                    <p className="text-gray-500 text-xs">Sunday: 9am – 4pm (EAT)</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Follow Us</h3>
              <div className="flex gap-3">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-80"
                  style={{ background: "#1877F2" }}>
                  <Facebook className="w-4 h-4" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-80"
                  style={{ background: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)" }}>
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-80"
                  style={{ background: "#1DA1F2" }}>
                  <Twitter className="w-4 h-4" />
                </a>
                <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-80"
                  style={{ background: "#25D366" }}>
                  <MessageCircle className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
              <h2 className="font-display text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Full Name *</label>
                    <Input required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="rounded-xl" placeholder="Your full name" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Email Address *</label>
                    <Input type="email" required value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="rounded-xl" placeholder="your@email.com" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Phone / WhatsApp</label>
                    <Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} className="rounded-xl" placeholder="+254..." />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Inquiry Type</label>
                    <select
                      value={form.inquiryType}
                      onChange={e => setForm(p => ({ ...p, inquiryType: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ocean/30"
                    >
                      <option value="general">General Inquiry</option>
                      <option value="tour">Tour Booking</option>
                      <option value="transfer">Transfer Booking</option>
                      <option value="custom">Custom Package</option>
                      <option value="corporate">Corporate Travel</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1.5 block">Subject</label>
                  <Input value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} className="rounded-xl" placeholder="How can we help you?" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1.5 block">Message *</label>
                  <Textarea required value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} className="rounded-xl" rows={5} placeholder="Tell us about your travel plans, dates, group size, and any special requirements..." />
                </div>
                <Button type="submit" disabled={submitContact.isPending} size="lg" className="w-full rounded-xl font-semibold"
                  style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}>
                  {submitContact.isPending ? "Sending..." : <><Send className="w-4 h-4 mr-2" />Send Message</>}
                </Button>
              </form>
            </div>

            {/* Google Map */}
            <div className="mt-6 rounded-2xl overflow-hidden shadow-sm border border-gray-100" style={{ height: "300px" }}>
              <MapView
                onMapReady={(map) => {
                  setMapReady(true);
                  // Center on Mombasa, Kenya
                  const mombasa = { lat: -4.0435, lng: 39.6682 };
                  map.setCenter(mombasa);
                  map.setZoom(13);
                  new google.maps.Marker({
                    position: mombasa,
                    map,
                    title: "ViaTrek Tours - Mombasa",
                    icon: {
                      url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                    },
                  });
                  const infoWindow = new google.maps.InfoWindow({
                    content: `<div style="padding:8px;font-family:sans-serif"><strong>ViaTrek Tours</strong><br/>Mombasa, Kenya<br/><a href="tel:+254701475532" style="color:#0066cc">+254 701 475 532</a></div>`,
                  });
                  map.addListener("click", () => infoWindow.close());
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
