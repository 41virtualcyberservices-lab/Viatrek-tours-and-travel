import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Mail, Lock, ArrowLeft } from "lucide-react";

export default function AdminLogin() {
  const [, navigate] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  const loginMutation = trpc.adminAuth.login.useMutation();
  const resetMutation = trpc.adminAuth.requestPasswordReset.useMutation();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsLoading(true);
    try {
      const result = await loginMutation.mutateAsync({ email, password });
      // Store admin session in localStorage
      localStorage.setItem("adminSession", JSON.stringify({ id: result.id, email: result.email, role: result.role }));
      toast.success("Login successful!");
      window.location.href = "/admin";
    } catch (error: any) {
      toast.error(error.message || "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) {
      toast.error("Please enter your email");
      return;
    }

    setIsLoading(true);
    try {
      await resetMutation.mutateAsync({ email: resetEmail });
      toast.success("Password reset link sent to your email");
      setShowReset(false);
      setResetEmail("");
    } catch (error: any) {
      toast.error(error.message || "Reset request failed");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <Card className="w-full max-w-md bg-white shadow-2xl">
        <div className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full mb-4" style={{ background: "oklch(0.72 0.14 195)" }}>
              <span className="text-white font-bold text-lg">VT</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900">ViaTrek Admin</h1>
            <p className="text-slate-600 text-sm mt-1">Manage your tourism business</p>
          </div>

          {!showReset ? (
            <>
              {/* Login Form */}
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <Input
                      type="email"
                      placeholder="admin@viatrek.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <Input
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full mt-6"
                  style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}
                  disabled={isLoading}
                >
                  {isLoading ? "Logging in..." : "Login"}
                </Button>
              </form>

              {/* Forgot Password Link */}
              <button
                type="button"
                onClick={() => setShowReset(true)}
                className="w-full text-center text-sm text-slate-600 hover:text-slate-900 mt-4 transition"
              >
                Forgot your password?
              </button>

              {/* Register Link */}
              <div className="text-center text-sm text-slate-600 mt-6">
                Don't have an account?{" "}
                <button
                  type="button"
                  onClick={() => { window.location.href = "/admin/register"; }}
                  className="text-blue-600 hover:text-blue-700 font-medium transition"
                >
                  Register here
                </button>
              </div>
            </>
          ) : (
            <>
              {/* Password Reset Form */}
              <form onSubmit={handlePasswordReset} className="space-y-4">
                <p className="text-sm text-slate-600 mb-4">
                  Enter your email address and we'll send you a link to reset your password.
                </p>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <Input
                      type="email"
                      placeholder="admin@viatrek.com"
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      className="pl-10"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full mt-6"
                  style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}
                  disabled={isLoading}
                >
                  {isLoading ? "Sending..." : "Send Reset Link"}
                </Button>
              </form>

              {/* Back to Login */}
              <button
                type="button"
                onClick={() => {
                  setShowReset(false);
                  setResetEmail("");
                }}
                className="w-full flex items-center justify-center gap-2 text-sm text-slate-600 hover:text-slate-900 mt-4 transition"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to login
              </button>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}
