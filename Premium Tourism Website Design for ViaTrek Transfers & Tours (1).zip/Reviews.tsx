import { useState } from "react";
import { Star } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

function StarRating({ rating, interactive = false, onChange }: { rating: number; interactive?: boolean; onChange?: (r: number) => void }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <button
          key={i}
          type="button"
          disabled={!interactive}
          onClick={() => interactive && onChange?.(i)}
          onMouseEnter={() => interactive && setHover(i)}
          onMouseLeave={() => interactive && setHover(0)}
          className={interactive ? "cursor-pointer" : "cursor-default"}
        >
          <Star
            className={`w-5 h-5 transition-colors duration-100 ${i <= (hover || rating) ? "fill-current" : "fill-none"}`}
            style={{ color: "oklch(0.78 0.16 75)" }}
          />
        </button>
      ))}
    </div>
  );
}

export default function Reviews() {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ reviewerName: "", reviewerEmail: "", reviewerCountry: "", rating: 5, title: "", content: "" });

  const { data: reviews = [] } = trpc.reviews.list.useQuery({});
  const submitReview = trpc.reviews.submit.useMutation({
    onSuccess: () => {
      toast.success("Thank you! Your review has been submitted for moderation.");
      setShowForm(false);
      setForm({ reviewerName: "", reviewerEmail: "", reviewerCountry: "", rating: 5, title: "", content: "" });
    },
    onError: () => toast.error("Failed to submit review. Please try again."),
  });

  const PLACEHOLDER_REVIEWS = [
    { id: 1, reviewerName: "James & Sarah", reviewerCountry: "United Kingdom", rating: 5, title: "Unforgettable Honeymoon!", content: "ViaTrek organized our honeymoon in Kenya and it was absolutely magical. Every detail was perfect, from the beach resort in Diani to the Maasai Mara safari. The team was incredibly professional and responsive.", createdAt: new Date("2024-03-15") },
    { id: 2, reviewerName: "Michael Chen", reviewerCountry: "Singapore", rating: 5, title: "Best Safari Experience", content: "I've been on safaris in multiple African countries, but ViaTrek's Maasai Mara package was the best. Our guide was knowledgeable, the accommodation was excellent, and we witnessed the Great Migration!", createdAt: new Date("2024-02-20") },
    { id: 3, reviewerName: "Emma Williams", reviewerCountry: "Australia", rating: 5, title: "Perfect Family Vacation", content: "Traveling with three kids can be challenging, but ViaTrek made it seamless. The family safari package was perfectly tailored for children, with age-appropriate activities and comfortable lodges.", createdAt: new Date("2024-01-10") },
    { id: 4, reviewerName: "François Dubois", reviewerCountry: "France", rating: 4, title: "Excellent Cultural Tour", content: "The Mombasa cultural tour exceeded my expectations. Our guide was passionate about the history and culture of the Swahili coast. Highly recommend for anyone interested in history.", createdAt: new Date("2024-04-05") },
  ];

  const displayReviews = reviews.length > 0 ? reviews : PLACEHOLDER_REVIEWS;
  const avgRating = displayReviews.reduce((sum: number, r: any) => sum + r.rating, 0) / displayReviews.length;

  return (
    <div className="min-h-screen pt-20">
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Traveler Reviews</h1>
          <p className="text-white/75 text-lg mb-6">Real stories from real travelers who explored Kenya with us.</p>
          <div className="flex items-center justify-center gap-3">
            <StarRating rating={Math.round(avgRating)} />
            <span className="text-2xl font-bold text-white">{avgRating.toFixed(1)}</span>
            <span className="text-white/60">({displayReviews.length} reviews)</span>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="flex justify-end mb-8">
          <Button onClick={() => setShowForm(!showForm)} className="rounded-xl font-semibold"
            style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}>
            Write a Review
          </Button>
        </div>

        {showForm && (
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-10 border border-gray-100">
            <h3 className="font-display text-xl font-bold text-gray-900 mb-6">Share Your Experience</h3>
            <form onSubmit={(e) => { e.preventDefault(); submitReview.mutate(form); }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Your Name *</label>
                  <Input required value={form.reviewerName} onChange={e => setForm(p => ({ ...p, reviewerName: e.target.value }))} className="rounded-xl" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Email</label>
                  <Input type="email" value={form.reviewerEmail} onChange={e => setForm(p => ({ ...p, reviewerEmail: e.target.value }))} className="rounded-xl" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Country</label>
                  <Input value={form.reviewerCountry} onChange={e => setForm(p => ({ ...p, reviewerCountry: e.target.value }))} className="rounded-xl" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Your Rating *</label>
                <StarRating rating={form.rating} interactive onChange={r => setForm(p => ({ ...p, rating: r }))} />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Review Title</label>
                <Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} className="rounded-xl" placeholder="Summarize your experience" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Your Review *</label>
                <Textarea required value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} className="rounded-xl" rows={4} placeholder="Tell us about your experience with ViaTrek Tours..." />
              </div>
              <div className="flex gap-3">
                <Button type="submit" disabled={submitReview.isPending} className="rounded-xl font-semibold"
                  style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                  {submitReview.isPending ? "Submitting..." : "Submit Review"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
              </div>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {displayReviews.map((review: any) => (
            <div key={review.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold"
                    style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
                    {review.reviewerName.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{review.reviewerName}</p>
                    {review.reviewerCountry && <p className="text-xs text-gray-400">{review.reviewerCountry}</p>}
                  </div>
                </div>
                <StarRating rating={review.rating} />
              </div>
              {review.title && <h4 className="font-semibold text-gray-900 mb-2">{review.title}</h4>}
              <p className="text-gray-600 text-sm leading-relaxed italic">"{review.content}"</p>
              <p className="text-xs text-gray-400 mt-3">
                {new Date(review.createdAt).toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
