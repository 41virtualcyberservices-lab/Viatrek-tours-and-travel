import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Tours from "./pages/Tours";
import TourDetail from "./pages/TourDetail";
import Destinations from "./pages/Destinations";
import Transfers from "./pages/Transfers";
import Gallery from "./pages/Gallery";
import Blog from "./pages/Blog";
import BlogDetail from "./pages/BlogDetail";
import Reviews from "./pages/Reviews";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Admin from "./pages/Admin";
import AdminLogin from "./pages/AdminLogin";
import AdminRegister from "./pages/AdminRegister";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ChatbotWidget from "./components/ChatbotWidget";
import WhatsAppButton from "./components/WhatsAppButton";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
      <WhatsAppButton />
      <ChatbotWidget />
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  const isAdmin = location.startsWith("/admin");

  return (
    <Switch>
      {/* Admin - no public layout */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/register" component={AdminRegister} />
      <Route path="/admin" component={Admin} />

      {/* Public pages with layout */}
      <Route path="/">
        {() => <Layout><Home /></Layout>}
      </Route>
      <Route path="/tours">
        {() => <Layout><Tours /></Layout>}
      </Route>
      <Route path="/tours/:slug">
        {() => <Layout><TourDetail /></Layout>}
      </Route>
      <Route path="/destinations">
        {() => <Layout><Destinations /></Layout>}
      </Route>
      <Route path="/transfers">
        {() => <Layout><Transfers /></Layout>}
      </Route>
      <Route path="/gallery">
        {() => <Layout><Gallery /></Layout>}
      </Route>
      <Route path="/blog">
        {() => <Layout><Blog /></Layout>}
      </Route>
      <Route path="/blog/:slug">
        {() => <Layout><BlogDetail /></Layout>}
      </Route>
      <Route path="/reviews">
        {() => <Layout><Reviews /></Layout>}
      </Route>
      <Route path="/about">
        {() => <Layout><About /></Layout>}
      </Route>
      <Route path="/contact">
        {() => <Layout><Contact /></Layout>}
      </Route>
      <Route path="/404">
        {() => <Layout><NotFound /></Layout>}
      </Route>
      <Route>
        {() => <Layout><NotFound /></Layout>}
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
