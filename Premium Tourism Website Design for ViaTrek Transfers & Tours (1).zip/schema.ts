import {
  boolean,
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
} from "drizzle-orm/mysql-core";

// ============================================================
// USERS (auth)
// ============================================================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================
// TOURS
// ============================================================
export const tours = mysqlTable("tours", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  category: mysqlEnum("category", [
    "beach", "safari", "cultural", "city", "family",
    "honeymoon", "corporate", "adventure", "group", "custom"
  ]).notNull(),
  shortDescription: text("shortDescription"),
  description: text("description"),
  duration: varchar("duration", { length: 100 }),
  availability: varchar("availability", { length: 255 }),
  price: decimal("price", { precision: 10, scale: 2 }),
  priceUnit: varchar("priceUnit", { length: 50 }).default("per person"),
  maxGroupSize: int("maxGroupSize"),
  difficulty: mysqlEnum("difficulty", ["easy", "moderate", "challenging"]).default("easy"),
  coverImage: text("coverImage"),
  gallery: json("gallery").$type<string[]>(),
  highlights: json("highlights").$type<string[]>(),
  included: json("included").$type<string[]>(),
  excluded: json("excluded").$type<string[]>(),
  itinerary: json("itinerary").$type<{ day: number; title: string; description: string }[]>(),
  featured: boolean("featured").default(false),
  published: boolean("published").default(true),
  metaTitle: varchar("metaTitle", { length: 255 }),
  metaDescription: text("metaDescription"),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Tour = typeof tours.$inferSelect;
export type InsertTour = typeof tours.$inferInsert;

// ============================================================
// DESTINATIONS
// ============================================================
export const destinations = mysqlTable("destinations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  region: varchar("region", { length: 100 }),
  shortDescription: text("shortDescription"),
  description: text("description"),
  coverImage: text("coverImage"),
  gallery: json("gallery").$type<string[]>(),
  highlights: json("highlights").$type<string[]>(),
  bestTimeToVisit: varchar("bestTimeToVisit", { length: 255 }),
  climate: varchar("climate", { length: 255 }),
  featured: boolean("featured").default(false),
  published: boolean("published").default(true),
  metaTitle: varchar("metaTitle", { length: 255 }),
  metaDescription: text("metaDescription"),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = typeof destinations.$inferInsert;

// ============================================================
// TRANSFERS
// ============================================================
export const transfers = mysqlTable("transfers", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  type: mysqlEnum("type", ["airport", "hotel", "corporate", "vip", "group"]).notNull(),
  shortDescription: text("shortDescription"),
  description: text("description"),
  coverImage: text("coverImage"),
  price: decimal("price", { precision: 10, scale: 2 }),
  priceUnit: varchar("priceUnit", { length: 50 }).default("per trip"),
  features: json("features").$type<string[]>(),
  published: boolean("published").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transfer = typeof transfers.$inferSelect;
export type InsertTransfer = typeof transfers.$inferInsert;

// ============================================================
// BOOKINGS
// ============================================================
export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  bookingRef: varchar("bookingRef", { length: 20 }).notNull().unique(),
  tourId: int("tourId"),
  tourTitle: varchar("tourTitle", { length: 255 }),
  transferId: int("transferId"),
  transferTitle: varchar("transferTitle", { length: 255 }),
  bookingType: mysqlEnum("bookingType", ["tour", "transfer", "custom"]).default("tour"),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  travelDate: varchar("travelDate", { length: 50 }),
  travelers: int("travelers").default(1),
  specialRequests: text("specialRequests"),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }),
  status: mysqlEnum("status", ["pending", "confirmed", "rejected", "cancelled", "completed"]).default("pending"),
  adminNotes: text("adminNotes"),
  source: varchar("source", { length: 50 }).default("website"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = typeof bookings.$inferInsert;

// ============================================================
// BLOG POSTS
// ============================================================
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  excerpt: text("excerpt"),
  content: text("content"),
  coverImage: text("coverImage"),
  category: varchar("category", { length: 100 }),
  tags: json("tags").$type<string[]>(),
  author: varchar("author", { length: 100 }).default("ViaTrek Team"),
  authorImage: text("authorImage"),
  published: boolean("published").default(false),
  featured: boolean("featured").default(false),
  views: int("views").default(0),
  metaTitle: varchar("metaTitle", { length: 255 }),
  metaDescription: text("metaDescription"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

// ============================================================
// REVIEWS
// ============================================================
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  tourId: int("tourId"),
  tourTitle: varchar("tourTitle", { length: 255 }),
  reviewerName: varchar("reviewerName", { length: 100 }).notNull(),
  reviewerEmail: varchar("reviewerEmail", { length: 320 }),
  reviewerCountry: varchar("reviewerCountry", { length: 100 }),
  reviewerAvatar: text("reviewerAvatar"),
  rating: int("rating").notNull(),
  title: varchar("title", { length: 255 }),
  content: text("content").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending"),
  featured: boolean("featured").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

// ============================================================
// GALLERY
// ============================================================
export const galleryItems = mysqlTable("gallery_items", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  url: text("url").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  type: mysqlEnum("type", ["photo", "video"]).default("photo"),
  category: varchar("category", { length: 100 }),
  tags: json("tags").$type<string[]>(),
  featured: boolean("featured").default(false),
  published: boolean("published").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GalleryItem = typeof galleryItems.$inferSelect;
export type InsertGalleryItem = typeof galleryItems.$inferInsert;

// ============================================================
// CHATBOT FAQs
// ============================================================
export const chatbotFaqs = mysqlTable("chatbot_faqs", {
  id: int("id").autoincrement().primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  category: varchar("category", { length: 100 }),
  keywords: json("keywords").$type<string[]>(),
  active: boolean("active").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatbotFaq = typeof chatbotFaqs.$inferSelect;
export type InsertChatbotFaq = typeof chatbotFaqs.$inferInsert;

// ============================================================
// NEWSLETTER SUBSCRIBERS
// ============================================================
export const newsletterSubscribers = mysqlTable("newsletter_subscribers", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 100 }),
  status: mysqlEnum("status", ["active", "unsubscribed"]).default("active"),
  source: varchar("source", { length: 50 }).default("website"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertNewsletterSubscriber = typeof newsletterSubscribers.$inferInsert;

// ============================================================
// CONTACT MESSAGES
// ============================================================
export const contactMessages = mysqlTable("contact_messages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  subject: varchar("subject", { length: 255 }),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["new", "read", "replied"]).default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = typeof contactMessages.$inferInsert;

// ============================================================
// TESTIMONIALS
// ============================================================
export const testimonials = mysqlTable("testimonials", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  role: varchar("role", { length: 100 }),
  country: varchar("country", { length: 100 }),
  avatar: text("avatar"),
  content: text("content").notNull(),
  rating: int("rating").default(5),
  featured: boolean("featured").default(false),
  active: boolean("active").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = typeof testimonials.$inferInsert;

// ============================================================
// SPECIAL OFFERS
// ============================================================
export const specialOffers = mysqlTable("special_offers", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  discount: varchar("discount", { length: 50 }),
  coverImage: text("coverImage"),
  tourId: int("tourId"),
  validUntil: varchar("validUntil", { length: 50 }),
  badge: varchar("badge", { length: 50 }),
  active: boolean("active").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SpecialOffer = typeof specialOffers.$inferSelect;
export type InsertSpecialOffer = typeof specialOffers.$inferInsert;

// ============================================================
// TEAM MEMBERS
// ============================================================
export const teamMembers = mysqlTable("team_members", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  role: varchar("role", { length: 100 }),
  bio: text("bio"),
  avatar: text("avatar"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  socialLinks: json("socialLinks").$type<{ platform: string; url: string }[]>(),
  active: boolean("active").default(true),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = typeof teamMembers.$inferInsert;

// ============================================================
// SITE SETTINGS (key-value store)
// ============================================================
export const siteSettings = mysqlTable("site_settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  type: mysqlEnum("type", ["text", "json", "image", "boolean"]).default("text"),
  label: varchar("label", { length: 255 }),
  group: varchar("group", { length: 100 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

// ============================================================
// PAGE SEO
// ============================================================
export const pageSeo = mysqlTable("page_seo", {
  id: int("id").autoincrement().primaryKey(),
  page: varchar("page", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  ogTitle: varchar("ogTitle", { length: 255 }),
  ogDescription: text("ogDescription"),
  ogImage: text("ogImage"),
  keywords: text("keywords"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PageSeo = typeof pageSeo.$inferSelect;
export type InsertPageSeo = typeof pageSeo.$inferInsert;

// ============================================================
// CHATBOT LEADS
// ============================================================
export const chatbotLeads = mysqlTable("chatbot_leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  interest: text("interest"),
  conversation: json("conversation").$type<{ role: string; content: string }[]>(),
  status: mysqlEnum("status", ["new", "contacted", "converted"]).default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatbotLead = typeof chatbotLeads.$inferSelect;
export type InsertChatbotLead = typeof chatbotLeads.$inferInsert;

// ============================================================
// ADMIN ACCOUNTS (email/password authentication)
// ============================================================
export const adminAccounts = mysqlTable("admin_accounts", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["master", "admin"]).notNull().default("admin"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminAccount = typeof adminAccounts.$inferSelect;
export type InsertAdminAccount = typeof adminAccounts.$inferInsert;

// ============================================================
// PASSWORD RESET TOKENS
// ============================================================
export const passwordResetTokens = mysqlTable("password_reset_tokens", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("admin_id").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = typeof passwordResetTokens.$inferInsert;
