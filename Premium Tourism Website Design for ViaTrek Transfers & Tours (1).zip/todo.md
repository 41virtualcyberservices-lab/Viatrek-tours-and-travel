# ViaTrek Tours - Project TODO

## Phase 1: Design System & Database Schema
- [x] Global CSS design tokens (coastal palette: blue, turquoise, white, gold)
- [x] Google Fonts (Playfair Display + Inter)
- [x] Database schema: tours, destinations, transfers, bookings, blog_posts, reviews, gallery_items, chatbot_faqs, newsletter_subscribers, site_settings, team_members, special_offers, testimonials, hero_slides, page_seo, contacts

## Phase 2: Backend API (tRPC Routers)
- [x] Tours router (CRUD, categories, search, featured)
- [x] Destinations router (CRUD, featured)
- [x] Transfers router (CRUD)
- [x] Bookings router (create, list, update status, admin notifications)
- [x] Blog router (CRUD, categories, published/draft)
- [x] Reviews router (CRUD, moderation, ratings)
- [x] Gallery router (CRUD, categories, photos/videos)
- [x] Chatbot router (FAQ CRUD, AI response via LLM)
- [x] Newsletter router (subscribe, list, export)
- [x] Site settings router (hero images, logo, SEO, contact info, about content)
- [x] Team members router (CRUD)
- [x] Special offers router (CRUD)
- [x] Testimonials router (CRUD)
- [x] Analytics router (visitor counts, booking stats)
- [x] Seed data: 10 destinations, 10 tours, 10 FAQs, 4 testimonials, 3 offers, 4 team members, 12 gallery items, 3 blog posts, 14 site settings

## Phase 3: Public Frontend - Navbar & Home
- [x] Responsive Navbar with mobile menu, transparent/solid scroll behavior
- [x] Hero section: full-screen auto-sliding carousel with slogan and CTAs
- [x] Tour search bar in hero
- [x] Featured tours section
- [x] Why Choose Us section
- [x] Testimonials section
- [x] Gallery preview section
- [x] Special offers section
- [x] Newsletter subscription form
- [x] Footer with contact info, social links, quick links

## Phase 4: Tours, Destinations, Transfers, Gallery, Blog, Reviews Pages
- [x] Tours & Safaris page with 10 categories
- [x] Tour detail page with gallery, booking option, social sharing
- [x] Destinations page with all 10 destinations
- [x] Transfers page with 5 transfer types
- [x] Gallery page with filters, categories, lightbox viewer
- [x] Blog listing page
- [x] Blog article detail page with social sharing
- [x] Reviews page with ratings

## Phase 5: About, Contact, Booking, WhatsApp, Chatbot
- [x] About page: company story, mission/vision/values, team profiles
- [x] Contact page: inquiry form, Google Maps, WhatsApp link, social links
- [x] Booking flow: tour select, date, travelers, confirmation
- [x] Floating WhatsApp chat button (all pages, +254701475532)
- [x] AI chatbot widget (FAQ suggestions + LLM, lead collection, admin notification)

## Phase 6: Admin Dashboard
- [x] Admin login with email/password (no Manus OAuth required)
- [x] Admin registration (first account becomes master admin)
- [x] Password reset via email
- [x] Multiple admin accounts with role hierarchy (master/admin)
- [x] Admin account management (create, delete, update roles)
- [x] Dashboard overview: analytics, recent bookings, stats
- [x] Manage tours (add/edit/delete, upload images, all fields optional)
- [x] Manage destinations (add/edit/delete)
- [x] Manage gallery (upload photos/videos, categories)
- [x] Manage blog posts (rich editor, publish/draft)
- [x] Manage reviews/testimonials (approve/reject/delete)
- [x] Manage bookings (view, approve, reject, status)
- [x] Manage special offers (add/edit/delete)
- [x] Manage team members (add/edit/delete)
- [x] Manage newsletter subscribers (view, export CSV)
- [x] Manage chatbot FAQs (add/edit/delete)
- [x] Site settings: logo upload, hero images, contact info, social links, company name
- [x] SEO settings per page (meta title, description, OG tags)
- [x] About page content editor
- [x] Admin account management section (view current admin, create new admins, logout)

## Phase 7: SEO, Email, Social Sharing, Polish
- [x] Meta tags and Open Graph on all pages
- [x] XML sitemap (/sitemap.xml)
- [x] robots.txt
- [x] Schema markup (Organization, TouristAttraction)
- [x] Email notifications (bookings, contact form, chatbot leads) via notifyOwner
- [x] Social sharing buttons on tour detail and blog pages (Facebook, Twitter, WhatsApp, Instagram)
- [x] Smooth animations and transitions
- [x] Mobile responsive design
- [x] 18 Vitest unit tests passing
- [x] Zero TypeScript errors
- [x] Final checkpoint
