import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Map, Plane, Image, BookOpen, Star, Mail, Settings,
  Users, MessageSquare, BarChart2, LogOut, Menu, X, Plus, Edit, Trash2,
  CheckCircle, XCircle, Eye, Upload, Save, Globe, FileText, Bell, ChevronDown, ChevronRight
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

// ============================================================
// SIDEBAR NAV
// ============================================================
const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "tours", label: "Tours & Safaris", icon: Map },
  { id: "destinations", label: "Destinations", icon: Globe },
  { id: "transfers", label: "Transfers", icon: Plane },
  { id: "bookings", label: "Bookings", icon: BookOpen },
  { id: "gallery", label: "Gallery", icon: Image },
  { id: "blog", label: "Blog", icon: FileText },
  { id: "reviews", label: "Reviews", icon: Star },
  { id: "newsletter", label: "Newsletter", icon: Mail },
  { id: "chatbot", label: "AI Chatbot", icon: MessageSquare },
  { id: "team", label: "Team", icon: Users },
  { id: "offers", label: "Special Offers", icon: BarChart2 },
  { id: "settings", label: "Site Settings", icon: Settings },
];

// ============================================================
// ADMIN LAYOUT
// ============================================================
function AdminLayout({ children, activeSection, setActiveSection }: {
  children: React.ReactNode;
  activeSection: string;
  setActiveSection: (s: string) => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-xl transform transition-transform duration-300 flex flex-col
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:shadow-none lg:border-r lg:border-gray-100`}>
        {/* Logo */}
        <div className="p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold text-sm"
              style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
              VT
            </div>
            <div>
              <p className="font-display font-bold text-gray-900 text-sm">ViaTrek Admin</p>
              <p className="text-xs text-gray-400">Content Management</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto p-3">
          {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => { setActiveSection(id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium mb-1 transition-all duration-200 ${
                activeSection === id
                  ? "text-white shadow-sm"
                  : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              }`}
              style={activeSection === id ? { background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" } : {}}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </button>
          ))}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
              style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
              {user?.name?.charAt(0) || "A"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user?.name || "Admin"}</p>
              <p className="text-xs text-gray-400 truncate">{user?.email || ""}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link href="/" className="flex-1">
              <Button variant="outline" size="sm" className="w-full rounded-lg text-xs">
                <Eye className="w-3 h-3 mr-1" /> View Site
              </Button>
            </Link>
            <Button variant="outline" size="sm" className="rounded-lg text-xs" onClick={logout}>
              <LogOut className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-4 sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors">
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
          <h1 className="font-display font-bold text-gray-900 text-lg">
            {NAV_ITEMS.find(n => n.id === activeSection)?.label || "Dashboard"}
          </h1>
        </header>

        {/* Content */}
        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

// ============================================================
// DASHBOARD OVERVIEW
// ============================================================
function DashboardOverview() {
  const { data: stats } = trpc.admin.stats.useQuery();

  const cards = [
    { label: "Total Bookings", value: stats?.totalBookings ?? 0, icon: BookOpen, color: "oklch(0.45 0.14 240)" },
    { label: "Pending Bookings", value: stats?.pendingBookings ?? 0, icon: Bell, color: "oklch(0.62 0.18 75)" },
    { label: "Published Tours", value: stats?.publishedTours ?? 0, icon: Map, color: "oklch(0.72 0.14 195)" },
    { label: "Newsletter Subscribers", value: stats?.newsletterSubscribers ?? 0, icon: Mail, color: "oklch(0.55 0.22 25)" },
    { label: "Pending Reviews", value: stats?.pendingReviews ?? 0, icon: Star, color: "oklch(0.65 0.18 35)" },
    { label: "Blog Posts", value: stats?.blogPosts ?? 0, icon: FileText, color: "oklch(0.45 0.14 240)" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: `${color}20` }}>
                <Icon className="w-5 h-5" style={{ color }} />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            <p className="text-sm text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-gray-900 mb-4">Recent Bookings</h3>
        <RecentBookings />
      </div>
    </div>
  );
}

function RecentBookings() {
  const { data: bookings = [] } = trpc.admin.bookings.useQuery({ limit: 5 });

  if (bookings.length === 0) {
    return <p className="text-gray-400 text-sm text-center py-8">No bookings yet.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-100">
            <th className="text-left pb-3 text-gray-500 font-medium">Ref</th>
            <th className="text-left pb-3 text-gray-500 font-medium">Client</th>
            <th className="text-left pb-3 text-gray-500 font-medium">Tour</th>
            <th className="text-left pb-3 text-gray-500 font-medium">Date</th>
            <th className="text-left pb-3 text-gray-500 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((b: any) => (
            <tr key={b.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
              <td className="py-3 font-mono text-xs text-gray-500">{b.bookingRef}</td>
              <td className="py-3 font-medium text-gray-900">{b.firstName} {b.lastName}</td>
              <td className="py-3 text-gray-600">{b.tourTitle}</td>
              <td className="py-3 text-gray-500">{b.travelDate || "TBD"}</td>
              <td className="py-3">
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                  b.status === "confirmed" ? "bg-green-100 text-green-700" :
                  b.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                  b.status === "cancelled" ? "bg-red-100 text-red-700" :
                  "bg-gray-100 text-gray-700"
                }`}>
                  {b.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================================================
// TOURS MANAGEMENT
// ============================================================
function ToursManager() {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({
    title: "", slug: "", category: "beach", shortDescription: "", description: "",
    price: "", priceUnit: "per person", duration: "", maxGroupSize: "", availability: "",
    difficulty: "easy", featured: false, published: true,
    highlights: "", included: "", excluded: "",
  });

  const { data: tours = [], refetch } = trpc.tours.list.useQuery({});
  const createTour = trpc.admin.createTour.useMutation({ onSuccess: () => { refetch(); setShowForm(false); toast.success("Tour created!"); } });
  const updateTour = trpc.admin.updateTour.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setEditing(null); toast.success("Tour updated!"); } });
  const deleteTour = trpc.admin.deleteTour.useMutation({ onSuccess: () => { refetch(); toast.success("Tour deleted."); } });

  const startEdit = (tour: any) => {
    setEditing(tour);
    setForm({
      title: tour.title, slug: tour.slug, category: tour.category, shortDescription: tour.shortDescription || "",
      description: tour.description || "", price: tour.price || "", priceUnit: tour.priceUnit || "per person",
      duration: tour.duration || "", maxGroupSize: tour.maxGroupSize?.toString() || "", availability: tour.availability || "",
      difficulty: tour.difficulty || "easy", featured: tour.featured || false, published: tour.published !== false,
      highlights: Array.isArray(tour.highlights) ? (tour.highlights as string[]).join("\n") : "",
      included: Array.isArray(tour.included) ? (tour.included as string[]).join("\n") : "",
      excluded: Array.isArray(tour.excluded) ? (tour.excluded as string[]).join("\n") : "",
    });
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      ...form,
      price: form.price || undefined,
      maxGroupSize: form.maxGroupSize ? parseInt(form.maxGroupSize) : undefined,
      highlights: form.highlights.split("\n").filter(Boolean),
      included: form.included.split("\n").filter(Boolean),
      excluded: form.excluded.split("\n").filter(Boolean),
    };
    if (editing) {
      updateTour.mutate({ id: editing.id, ...data });
    } else {
      createTour.mutate(data as any);
    }
  };

  const autoSlug = (title: string) => title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">Tours & Safaris ({tours.length})</h2>
        <Button onClick={() => { setEditing(null); setForm({ title: "", slug: "", category: "beach", shortDescription: "", description: "", price: "", priceUnit: "per person", duration: "", maxGroupSize: "", availability: "", difficulty: "easy", featured: false, published: true, highlights: "", included: "", excluded: "" }); setShowForm(!showForm); }}
          className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Plus className="w-4 h-4 mr-2" /> Add Tour
        </Button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-display font-bold text-gray-900 mb-5">{editing ? "Edit Tour" : "New Tour"}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Title *</label>
                <Input required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value, slug: p.slug || autoSlug(e.target.value) }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Slug *</label>
                <Input required value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="rounded-xl font-mono text-sm" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Category</label>
                <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2">
                  {["beach","safari","cultural","city","family","honeymoon","corporate","adventure","group","custom"].map(c => (
                    <option key={c} value={c} className="capitalize">{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Price</label>
                <Input value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} className="rounded-xl" placeholder="e.g. 299" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Price Unit</label>
                <Input value={form.priceUnit} onChange={e => setForm(p => ({ ...p, priceUnit: e.target.value }))} className="rounded-xl" placeholder="per person" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Duration</label>
                <Input value={form.duration} onChange={e => setForm(p => ({ ...p, duration: e.target.value }))} className="rounded-xl" placeholder="e.g. 3 Days / 2 Nights" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Max Group Size</label>
                <Input type="number" value={form.maxGroupSize} onChange={e => setForm(p => ({ ...p, maxGroupSize: e.target.value }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Availability</label>
                <Input value={form.availability} onChange={e => setForm(p => ({ ...p, availability: e.target.value }))} className="rounded-xl" placeholder="e.g. Year-round" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Short Description</label>
              <Input value={form.shortDescription} onChange={e => setForm(p => ({ ...p, shortDescription: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Full Description</label>
              <Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="rounded-xl" rows={4} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Highlights (one per line)</label>
                <Textarea value={form.highlights} onChange={e => setForm(p => ({ ...p, highlights: e.target.value }))} className="rounded-xl text-sm" rows={4} placeholder="Witness the Great Migration&#10;Expert local guides&#10;Luxury tented camp" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Included (one per line)</label>
                <Textarea value={form.included} onChange={e => setForm(p => ({ ...p, included: e.target.value }))} className="rounded-xl text-sm" rows={4} placeholder="Accommodation&#10;All meals&#10;Game drives" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Not Included (one per line)</label>
                <Textarea value={form.excluded} onChange={e => setForm(p => ({ ...p, excluded: e.target.value }))} className="rounded-xl text-sm" rows={4} placeholder="International flights&#10;Travel insurance&#10;Visa fees" />
              </div>
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.featured} onChange={e => setForm(p => ({ ...p, featured: e.target.checked }))} className="rounded" />
                <span className="text-sm font-medium text-gray-700">Featured on Homepage</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.published} onChange={e => setForm(p => ({ ...p, published: e.target.checked }))} className="rounded" />
                <span className="text-sm font-medium text-gray-700">Published (visible on site)</span>
              </label>
            </div>
            <div className="flex gap-3">
              <Button type="submit" disabled={createTour.isPending || updateTour.isPending} className="rounded-xl font-semibold"
                style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                <Save className="w-4 h-4 mr-2" />{editing ? "Update Tour" : "Create Tour"}
              </Button>
              <Button type="button" variant="outline" onClick={() => { setShowForm(false); setEditing(null); }} className="rounded-xl">Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Title</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Category</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Price</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Status</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {tours.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-8 text-gray-400">No tours yet. Add your first tour above.</td></tr>
              ) : tours.map((tour: any) => (
                <tr key={tour.id} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-gray-900">{tour.title}</p>
                      <p className="text-xs text-gray-400 font-mono">{tour.slug}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 capitalize text-gray-600">{tour.category}</td>
                  <td className="px-4 py-3 text-gray-600">{tour.price ? `$${tour.price}` : "—"}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1.5">
                      {tour.published && <span className="px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700">Published</span>}
                      {tour.featured && <span className="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-700">Featured</span>}
                      {!tour.published && <span className="px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-600">Draft</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => startEdit(tour)} className="rounded-lg h-7 px-2">
                        <Edit className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete this tour?")) deleteTour.mutate(tour.id); }}
                        className="rounded-lg h-7 px-2 text-red-500 hover:text-red-600 hover:border-red-300">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// BOOKINGS MANAGEMENT
// ============================================================
function BookingsManager() {
  const { data: bookings = [], refetch } = trpc.admin.bookings.useQuery({});
  const updateStatus = trpc.admin.updateBookingStatus.useMutation({ onSuccess: () => { refetch(); toast.success("Status updated!"); } });

  return (
    <div className="space-y-6">
      <h2 className="font-display text-xl font-bold text-gray-900">Bookings ({bookings.length})</h2>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Ref</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Client</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Tour</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Travel Date</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Travelers</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Status</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-400">No bookings yet.</td></tr>
              ) : bookings.map((b: any) => (
                <tr key={b.id} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-gray-500">{b.bookingRef}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{b.firstName} {b.lastName}</p>
                    <p className="text-xs text-gray-400">{b.email}</p>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{b.tourTitle}</td>
                  <td className="px-4 py-3 text-gray-600">{b.travelDate || "TBD"}</td>
                  <td className="px-4 py-3 text-gray-600">{b.travelers}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      b.status === "confirmed" ? "bg-green-100 text-green-700" :
                      b.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                      b.status === "cancelled" ? "bg-red-100 text-red-700" :
                      "bg-gray-100 text-gray-700"
                    }`}>{b.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" onClick={() => updateStatus.mutate({ id: b.id, status: "confirmed" })}
                        className="rounded-lg h-7 px-2 text-green-600 hover:border-green-300 text-xs">Confirm</Button>
                      <Button size="sm" variant="outline" onClick={() => updateStatus.mutate({ id: b.id, status: "cancelled" })}
                        className="rounded-lg h-7 px-2 text-red-500 hover:border-red-300 text-xs">Cancel</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// REVIEWS MANAGEMENT
// ============================================================
function ReviewsManager() {
  const { data: reviews = [], refetch } = trpc.admin.reviews.useQuery({});
  const updateReview = trpc.admin.updateReviewStatus.useMutation({ onSuccess: () => { refetch(); toast.success("Review updated!"); } });

  return (
    <div className="space-y-6">
      <h2 className="font-display text-xl font-bold text-gray-900">Reviews ({reviews.length})</h2>
      <div className="space-y-4">
        {reviews.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No reviews yet.</p>
        ) : reviews.map((r: any) => (
          <div key={r.id} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <p className="font-semibold text-gray-900">{r.reviewerName}</p>
                  {r.reviewerCountry && <span className="text-xs text-gray-400">{r.reviewerCountry}</span>}
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map(i => (
                      <span key={i} className={`text-xs ${i <= r.rating ? "text-yellow-400" : "text-gray-200"}`}>★</span>
                    ))}
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                    r.status === "approved" ? "bg-green-100 text-green-700" :
                    r.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  }`}>{r.status}</span>
                </div>
                {r.title && <p className="font-medium text-gray-800 mb-1">{r.title}</p>}
                <p className="text-gray-600 text-sm">{r.content}</p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button size="sm" variant="outline" onClick={() => updateReview.mutate({ id: r.id, status: "approved" })}
                  className="rounded-lg h-7 px-2 text-green-600 hover:border-green-300">
                  <CheckCircle className="w-3.5 h-3.5" />
                </Button>
                <Button size="sm" variant="outline" onClick={() => updateReview.mutate({ id: r.id, status: "rejected" })}
                  className="rounded-lg h-7 px-2 text-red-500 hover:border-red-300">
                  <XCircle className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// NEWSLETTER MANAGEMENT
// ============================================================
function NewsletterManager() {
  const { data: subscribers = [] } = trpc.admin.newsletterSubscribers.useQuery();

  const exportCSV = () => {
    const csv = ["Email,Name,Subscribed At", ...subscribers.map((s: any) => `${s.email},${s.name || ""},${new Date(s.createdAt).toLocaleDateString()}`)].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "viatrek-newsletter-subscribers.csv";
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">Newsletter Subscribers ({subscribers.length})</h2>
        <Button onClick={exportCSV} variant="outline" className="rounded-xl font-semibold">
          Export CSV
        </Button>
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Email</th>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Name</th>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Subscribed</th>
            </tr>
          </thead>
          <tbody>
            {subscribers.length === 0 ? (
              <tr><td colSpan={3} className="text-center py-8 text-gray-400">No subscribers yet.</td></tr>
            ) : subscribers.map((s: any) => (
              <tr key={s.id} className="border-t border-gray-50">
                <td className="px-4 py-3 text-gray-900">{s.email}</td>
                <td className="px-4 py-3 text-gray-600">{s.name || "—"}</td>
                <td className="px-4 py-3 text-gray-500">{new Date(s.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================
// CHATBOT MANAGEMENT
// ============================================================
function ChatbotManager() {
  const { data: faqs = [], refetch } = trpc.admin.chatbotFaqs.useQuery();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ question: "", answer: "", category: "general" });
  const createFaq = trpc.admin.createChatbotFaq.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm({ question: "", answer: "", category: "general" }); toast.success("FAQ added!"); } });
  const deleteFaq = trpc.admin.deleteChatbotFaq.useMutation({ onSuccess: () => { refetch(); toast.success("FAQ deleted."); } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">AI Chatbot FAQs ({faqs.length})</h2>
        <Button onClick={() => setShowForm(!showForm)} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Plus className="w-4 h-4 mr-2" /> Add FAQ
        </Button>
      </div>

      <div className="bg-blue-50 rounded-xl p-4 text-sm text-blue-700 border border-blue-200">
        <strong>How it works:</strong> Add questions and answers below. The AI chatbot will use these to respond to visitor inquiries. You can add unlimited FAQs covering tours, pricing, bookings, and more.
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <form onSubmit={(e) => { e.preventDefault(); createFaq.mutate(form); }} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Question *</label>
              <Input required value={form.question} onChange={e => setForm(p => ({ ...p, question: e.target.value }))} className="rounded-xl" placeholder="e.g. What is the best time to visit Kenya?" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Answer *</label>
              <Textarea required value={form.answer} onChange={e => setForm(p => ({ ...p, answer: e.target.value }))} className="rounded-xl" rows={4} placeholder="Provide a detailed, helpful answer..." />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Category</label>
              <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none">
                {["general","tours","pricing","booking","transfers","destinations","safety"].map(c => (
                  <option key={c} value={c} className="capitalize">{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>
            <div className="flex gap-3">
              <Button type="submit" disabled={createFaq.isPending} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                <Save className="w-4 h-4 mr-2" /> Save FAQ
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-3">
        {faqs.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No FAQs yet. Add your first FAQ to train the chatbot.</p>
        ) : faqs.map((faq: any) => (
          <div key={faq.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <p className="font-semibold text-gray-900 mb-1">Q: {faq.question}</p>
                <p className="text-gray-600 text-sm">A: {faq.answer}</p>
                <span className="inline-block mt-2 px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-500 capitalize">{faq.category}</span>
              </div>
              <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete this FAQ?")) deleteFaq.mutate(faq.id); }}
                className="rounded-lg h-7 px-2 text-red-500 hover:border-red-300 flex-shrink-0">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// SITE SETTINGS
// ============================================================
function SiteSettings() {
  const { data: settings } = trpc.admin.siteSettings.useQuery();
  const [form, setForm] = useState({
    siteName: "ViaTrek Tours",
    tagline: "Discover Kenya. Experience Adventure. Travel With Confidence.",
    contactEmail: "viatrektours@gmail.com",
    contactPhone: "+254701475532",
    address: "Mombasa, Kenya",
    facebookUrl: "",
    instagramUrl: "",
    twitterUrl: "",
    metaDescription: "Premium tours, safaris and transfers across Kenya's most breathtaking destinations.",
    metaKeywords: "Kenya tours, Kenya safari, Mombasa tours, Diani beach, Maasai Mara",
    googleAnalyticsId: "",
  });

  const updateSettings = trpc.admin.updateSiteSettings.useMutation({
    onSuccess: () => toast.success("Settings saved!"),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings.mutate(form);
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-xl font-bold text-gray-900">Site Settings</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">General Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Site Name</label>
              <Input value={form.siteName} onChange={e => setForm(p => ({ ...p, siteName: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Tagline / Slogan</label>
              <Input value={form.tagline} onChange={e => setForm(p => ({ ...p, tagline: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Contact Email</label>
              <Input type="email" value={form.contactEmail} onChange={e => setForm(p => ({ ...p, contactEmail: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Phone / WhatsApp</label>
              <Input value={form.contactPhone} onChange={e => setForm(p => ({ ...p, contactPhone: e.target.value }))} className="rounded-xl" />
            </div>
            <div className="md:col-span-2">
              <label className="text-sm font-medium text-gray-700 mb-1 block">Address</label>
              <Input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} className="rounded-xl" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Social Media Links</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Facebook URL</label>
              <Input value={form.facebookUrl} onChange={e => setForm(p => ({ ...p, facebookUrl: e.target.value }))} className="rounded-xl" placeholder="https://facebook.com/..." />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Instagram URL</label>
              <Input value={form.instagramUrl} onChange={e => setForm(p => ({ ...p, instagramUrl: e.target.value }))} className="rounded-xl" placeholder="https://instagram.com/..." />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Twitter / X URL</label>
              <Input value={form.twitterUrl} onChange={e => setForm(p => ({ ...p, twitterUrl: e.target.value }))} className="rounded-xl" placeholder="https://twitter.com/..." />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">SEO Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Meta Description</label>
              <Textarea value={form.metaDescription} onChange={e => setForm(p => ({ ...p, metaDescription: e.target.value }))} className="rounded-xl" rows={2} />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Meta Keywords</label>
              <Input value={form.metaKeywords} onChange={e => setForm(p => ({ ...p, metaKeywords: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Google Analytics ID</label>
              <Input value={form.googleAnalyticsId} onChange={e => setForm(p => ({ ...p, googleAnalyticsId: e.target.value }))} className="rounded-xl" placeholder="G-XXXXXXXXXX" />
            </div>
          </div>
        </div>

        <Button type="submit" disabled={updateSettings.isPending} size="lg" className="rounded-xl font-semibold"
          style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Save className="w-4 h-4 mr-2" />{updateSettings.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </form>
    </div>
  );
}

// ============================================================
// GALLERY MANAGER
// ============================================================
function GalleryManager() {
  const { data: items = [], refetch } = trpc.gallery.list.useQuery({});
  const [form, setForm] = useState({ url: "", title: "", category: "General", type: "photo" });
  const [showForm, setShowForm] = useState(false);
  const addItem = trpc.admin.addGalleryItem.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm({ url: "", title: "", category: "General", type: "photo" }); toast.success("Item added!"); } });
  const deleteItem = trpc.admin.deleteGalleryItem.useMutation({ onSuccess: () => { refetch(); toast.success("Item deleted."); } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">Gallery ({items.length})</h2>
        <Button onClick={() => setShowForm(!showForm)} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Plus className="w-4 h-4 mr-2" /> Add Media
        </Button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <form onSubmit={(e) => { e.preventDefault(); addItem.mutate(form); }} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Image/Video URL *</label>
              <Input required value={form.url} onChange={e => setForm(p => ({ ...p, url: e.target.value }))} className="rounded-xl" placeholder="https://..." />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Title</label>
                <Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Category</label>
                <Input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="rounded-xl" placeholder="Safari, Beach, etc." />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Type</label>
                <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none">
                  <option value="photo">Photo</option>
                  <option value="video">Video</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3">
              <Button type="submit" disabled={addItem.isPending} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                <Save className="w-4 h-4 mr-2" /> Add to Gallery
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {items.map((item: any) => (
          <div key={item.id} className="group relative rounded-xl overflow-hidden aspect-square bg-gray-100">
            <img src={item.url} alt={item.title || ""} className="w-full h-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-colors duration-200 flex items-center justify-center">
              <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete?")) deleteItem.mutate(item.id); }}
                className="opacity-0 group-hover:opacity-100 transition-opacity rounded-lg text-red-500 border-red-300 bg-white">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
            {item.title && (
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/60 to-transparent">
                <p className="text-white text-xs truncate">{item.title}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// BLOG MANAGER
// ============================================================
function BlogManager() {
  const { data: posts = [], refetch } = trpc.blog.list.useQuery({});
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ title: "", slug: "", excerpt: "", content: "", category: "", author: "ViaTrek Team", coverImage: "", published: true, tags: "" });
  const createPost = trpc.admin.createBlogPost.useMutation({ onSuccess: () => { refetch(); setShowForm(false); toast.success("Post created!"); } });
  const updatePost = trpc.admin.updateBlogPost.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setEditing(null); toast.success("Post updated!"); } });
  const deletePost = trpc.admin.deleteBlogPost.useMutation({ onSuccess: () => { refetch(); toast.success("Post deleted."); } });

  const autoSlug = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

  const startEdit = (post: any) => {
    setEditing(post);
    setForm({ title: post.title, slug: post.slug, excerpt: post.excerpt || "", content: post.content || "", category: post.category || "", author: post.author || "ViaTrek Team", coverImage: post.coverImage || "", published: post.published !== false, tags: Array.isArray(post.tags) ? (post.tags as string[]).join(", ") : "" });
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = { ...form, tags: form.tags.split(",").map(t => t.trim()).filter(Boolean) };
    if (editing) updatePost.mutate({ id: editing.id, ...data });
    else createPost.mutate(data as any);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">Blog Posts ({posts.length})</h2>
        <Button onClick={() => { setEditing(null); setForm({ title: "", slug: "", excerpt: "", content: "", category: "", author: "ViaTrek Team", coverImage: "", published: true, tags: "" }); setShowForm(!showForm); }}
          className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Plus className="w-4 h-4 mr-2" /> New Post
        </Button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-display font-bold text-gray-900 mb-5">{editing ? "Edit Post" : "New Post"}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Title *</label>
                <Input required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value, slug: p.slug || autoSlug(e.target.value) }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Slug *</label>
                <Input required value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="rounded-xl font-mono text-sm" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Category</label>
                <Input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="rounded-xl" placeholder="Travel Guide, Safari Tips..." />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Author</label>
                <Input value={form.author} onChange={e => setForm(p => ({ ...p, author: e.target.value }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Cover Image URL</label>
                <Input value={form.coverImage} onChange={e => setForm(p => ({ ...p, coverImage: e.target.value }))} className="rounded-xl" placeholder="https://..." />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Excerpt</label>
              <Textarea value={form.excerpt} onChange={e => setForm(p => ({ ...p, excerpt: e.target.value }))} className="rounded-xl" rows={2} />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Content</label>
              <Textarea value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} className="rounded-xl" rows={8} />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Tags (comma-separated)</label>
              <Input value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))} className="rounded-xl" placeholder="safari, kenya, wildlife" />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.published} onChange={e => setForm(p => ({ ...p, published: e.target.checked }))} className="rounded" />
              <span className="text-sm font-medium text-gray-700">Published</span>
            </label>
            <div className="flex gap-3">
              <Button type="submit" disabled={createPost.isPending || updatePost.isPending} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                <Save className="w-4 h-4 mr-2" />{editing ? "Update Post" : "Create Post"}
              </Button>
              <Button type="button" variant="outline" onClick={() => { setShowForm(false); setEditing(null); }} className="rounded-xl">Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Title</th>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Category</th>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Status</th>
              <th className="text-left px-4 py-3 text-gray-500 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {posts.length === 0 ? (
              <tr><td colSpan={4} className="text-center py-8 text-gray-400">No posts yet.</td></tr>
            ) : posts.map((post: any) => (
              <tr key={post.id} className="border-t border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3">
                  <p className="font-medium text-gray-900">{post.title}</p>
                  <p className="text-xs text-gray-400 font-mono">{post.slug}</p>
                </td>
                <td className="px-4 py-3 text-gray-600">{post.category || "—"}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${post.published ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                    {post.published ? "Published" : "Draft"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => startEdit(post)} className="rounded-lg h-7 px-2"><Edit className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete?")) deletePost.mutate(post.id); }} className="rounded-lg h-7 px-2 text-red-500 hover:border-red-300"><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================
// DESTINATIONS MANAGER
// ============================================================
function DestinationsManager() {
  const { data: destinations = [], refetch } = trpc.destinations.list.useQuery({});
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", slug: "", region: "", shortDescription: "", description: "", coverImage: "", featured: false });
  const createDest = trpc.admin.createDestination.useMutation({ onSuccess: () => { refetch(); setShowForm(false); toast.success("Destination added!"); } });
  const deleteDest = trpc.admin.deleteDestination.useMutation({ onSuccess: () => { refetch(); toast.success("Destination deleted."); } });
  const autoSlug = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold text-gray-900">Destinations ({destinations.length})</h2>
        <Button onClick={() => setShowForm(!showForm)} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
          <Plus className="w-4 h-4 mr-2" /> Add Destination
        </Button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <form onSubmit={(e) => { e.preventDefault(); createDest.mutate(form as any); }} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Name *</label>
                <Input required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value, slug: p.slug || autoSlug(e.target.value) }))} className="rounded-xl" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Slug *</label>
                <Input required value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="rounded-xl font-mono text-sm" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Region</label>
                <Input value={form.region} onChange={e => setForm(p => ({ ...p, region: e.target.value }))} className="rounded-xl" placeholder="e.g. Coastal Kenya" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Cover Image URL</label>
                <Input value={form.coverImage} onChange={e => setForm(p => ({ ...p, coverImage: e.target.value }))} className="rounded-xl" placeholder="https://..." />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Short Description</label>
              <Input value={form.shortDescription} onChange={e => setForm(p => ({ ...p, shortDescription: e.target.value }))} className="rounded-xl" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Full Description</label>
              <Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="rounded-xl" rows={4} />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.featured} onChange={e => setForm(p => ({ ...p, featured: e.target.checked }))} className="rounded" />
              <span className="text-sm font-medium text-gray-700">Featured on Homepage</span>
            </label>
            <div className="flex gap-3">
              <Button type="submit" disabled={createDest.isPending} className="rounded-xl font-semibold" style={{ background: "oklch(0.45 0.14 240)", color: "white" }}>
                <Save className="w-4 h-4 mr-2" /> Save Destination
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {destinations.map((dest: any) => (
          <div key={dest.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 flex items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-gray-900">{dest.name}</p>
              <p className="text-xs text-gray-400">{dest.region}</p>
            </div>
            <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete?")) deleteDest.mutate(dest.id); }}
              className="rounded-lg h-7 px-2 text-red-500 hover:border-red-300 flex-shrink-0">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// MAIN ADMIN PAGE
// ============================================================
export default function Admin() {
  const { user, loading, isAuthenticated } = useAuth();
  const [activeSection, setActiveSection] = useState("dashboard");

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-t-transparent" style={{ borderColor: "oklch(0.45 0.14 240)", borderTopColor: "transparent" }} />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-lg p-10 text-center max-w-sm w-full mx-4">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white text-2xl font-bold"
            style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
            VT
          </div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-500 text-sm mb-6">Sign in to manage your ViaTrek Tours website.</p>
          <a href={getLoginUrl("/admin")}>
            <Button size="lg" className="w-full rounded-xl font-semibold"
              style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}>
              Sign In to Admin
            </Button>
          </a>
        </div>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-2xl shadow-lg p-10 text-center max-w-sm w-full mx-4">
          <div className="text-5xl mb-4">🔒</div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
          <p className="text-gray-500 text-sm mb-6">You don't have admin access. Please contact the site owner.</p>
          <Link href="/">
            <Button variant="outline" className="rounded-xl">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard": return <DashboardOverview />;
      case "tours": return <ToursManager />;
      case "destinations": return <DestinationsManager />;
      case "bookings": return <BookingsManager />;
      case "gallery": return <GalleryManager />;
      case "blog": return <BlogManager />;
      case "reviews": return <ReviewsManager />;
      case "newsletter": return <NewsletterManager />;
      case "chatbot": return <ChatbotManager />;
      case "settings": return <SiteSettings />;
      default: return <DashboardOverview />;
    }
  };

  return (
    <AdminLayout activeSection={activeSection} setActiveSection={setActiveSection}>
      {renderSection()}
    </AdminLayout>
  );
}
