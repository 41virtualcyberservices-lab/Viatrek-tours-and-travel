import { Link } from "wouter";
import { MapPin, ArrowRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { DESTINATIONS } from "@/lib/constants";
import { Button } from "@/components/ui/button";

const DEST_IMAGES: Record<string, string> = {
  mombasa: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
  diani: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80",
  watamu: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&q=80",
  malindi: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=600&q=80",
  tsavo: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&q=80",
  amboseli: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&q=80",
  "maasai-mara": "https://images.unsplash.com/photo-1589825743636-e1a9b1e2d0a3?w=600&q=80",
  naivasha: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80",
  nakuru: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=600&q=80",
  nairobi: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=80",
};

export default function Destinations() {
  const { data: dbDestinations = [] } = trpc.destinations.list.useQuery({});

  const destinations = dbDestinations.length > 0
    ? dbDestinations.map(d => ({
        name: d.name,
        slug: d.slug,
        region: d.region || "",
        tagline: d.shortDescription || "",
        image: d.coverImage || DEST_IMAGES[d.slug] || DEST_IMAGES.mombasa,
      }))
    : DESTINATIONS.map(d => ({ ...d, image: DEST_IMAGES[d.slug] || DEST_IMAGES.mombasa }));

  return (
    <div className="min-h-screen pt-20">
      <div className="py-16 text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240), oklch(0.45 0.14 240))" }}>
        <div className="container text-center">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
            Where to Go
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">Kenya Destinations</h1>
          <p className="text-white/75 text-lg max-w-2xl mx-auto">
            From the Indian Ocean coast to the Great Rift Valley — explore Kenya's most breathtaking destinations.
          </p>
        </div>
      </div>

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((dest) => (
            <Link key={dest.slug} href={`/destinations/${dest.slug}`} className="group block">
              <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={dest.image}
                    alt={dest.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 text-xs font-semibold rounded-full text-white"
                      style={{ background: "oklch(0.45 0.14 240 / 0.8)" }}>
                      {dest.region}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-display text-2xl font-bold text-white">{dest.name}</h3>
                    <p className="text-white/80 text-sm mt-1">{dest.tagline}</p>
                  </div>
                </div>
                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-sm text-gray-500">
                    <MapPin className="w-4 h-4" style={{ color: "oklch(0.72 0.14 195)" }} />
                    {dest.region}, Kenya
                  </div>
                  <span className="text-sm font-semibold flex items-center gap-1 transition-colors duration-200 group-hover:text-ocean"
                    style={{ color: "oklch(0.45 0.14 240)" }}>
                    Explore <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
