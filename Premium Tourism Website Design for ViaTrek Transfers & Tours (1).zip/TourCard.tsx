import { Link } from "wouter";
import { Clock, Users, Star, MapPin, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
// Tour type inline to avoid cross-boundary imports
interface Tour {
  id: number;
  title: string;
  slug: string;
  category: string;
  shortDescription?: string | null;
  description?: string | null;
  duration?: string | null;
  availability?: string | null;
  price?: string | null;
  priceUnit?: string | null;
  maxGroupSize?: number | null;
  difficulty?: string | null;
  coverImage?: string | null;
  featured?: boolean | null;
  published?: boolean | null;
}

interface TourCardProps {
  tour: Tour;
  compact?: boolean;
}

const CATEGORY_COLORS: Record<string, string> = {
  beach: "bg-cyan-100 text-cyan-700",
  safari: "bg-amber-100 text-amber-700",
  cultural: "bg-purple-100 text-purple-700",
  city: "bg-slate-100 text-slate-700",
  family: "bg-green-100 text-green-700",
  honeymoon: "bg-pink-100 text-pink-700",
  corporate: "bg-blue-100 text-blue-700",
  adventure: "bg-orange-100 text-orange-700",
  group: "bg-teal-100 text-teal-700",
  custom: "bg-violet-100 text-violet-700",
};

const DEFAULT_IMAGES: Record<string, string> = {
  beach: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80",
  safari: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&q=80",
  cultural: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
  city: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=600&q=80",
  family: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=80",
  honeymoon: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&q=80",
  corporate: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80",
  adventure: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80",
  group: "https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=600&q=80",
  custom: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&q=80",
};

export default function TourCard({ tour, compact = false }: TourCardProps) {
  const imageUrl = tour.coverImage || DEFAULT_IMAGES[tour.category] || DEFAULT_IMAGES.safari;
  const categoryColor = CATEGORY_COLORS[tour.category] || "bg-gray-100 text-gray-700";
  const categoryLabel = tour.category.charAt(0).toUpperCase() + tour.category.slice(1);

  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
      {/* Image */}
      <div className="relative overflow-hidden aspect-[4/3]">
        <img
          src={imageUrl}
          alt={tour.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {/* Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        {tour.featured && (
          <div className="absolute top-3 left-3">
            <span className="px-2.5 py-1 text-xs font-semibold rounded-full text-white"
              style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))" }}>
              ⭐ Featured
            </span>
          </div>
        )}
        <div className="absolute top-3 right-3">
          <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${categoryColor}`}>
            {categoryLabel}
          </span>
        </div>
        {tour.price && (
          <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <span className="px-3 py-1.5 text-sm font-bold rounded-xl text-white"
              style={{ background: "oklch(0.32 0.12 240 / 0.9)" }}>
              From ${Number(tour.price).toLocaleString()} {tour.priceUnit}
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="font-display font-bold text-lg text-gray-900 mb-2 line-clamp-1 group-hover:text-ocean transition-colors duration-200"
          style={{ fontFamily: "var(--font-display)" }}>
          {tour.title}
        </h3>

        {!compact && (
          <p className="text-gray-500 text-sm leading-relaxed mb-4 line-clamp-2">
            {tour.shortDescription || "Discover the beauty of Kenya with this amazing tour package."}
          </p>
        )}

        {/* Meta */}
        <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
          {tour.duration && (
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {tour.duration}
            </span>
          )}
          {tour.maxGroupSize && (
            <span className="flex items-center gap-1">
              <Users className="w-3.5 h-3.5" />
              Max {tour.maxGroupSize}
            </span>
          )}
          {tour.availability && (
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {tour.availability}
            </span>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          {tour.price ? (
            <div>
              <span className="text-xs text-gray-400">From</span>
              <p className="font-bold text-lg" style={{ color: "oklch(0.32 0.12 240)" }}>
                ${Number(tour.price).toLocaleString()}
                <span className="text-xs font-normal text-gray-400 ml-1">{tour.priceUnit}</span>
              </p>
            </div>
          ) : (
            <span className="text-sm font-medium text-gray-500">Contact for price</span>
          )}
          <Link href={`/tours/${tour.slug}`}>
            <Button
              size="sm"
              className="rounded-xl font-semibold group/btn"
              style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}
            >
              View Tour
              <ArrowRight className="w-3.5 h-3.5 ml-1 transition-transform duration-200 group-hover/btn:translate-x-0.5" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
