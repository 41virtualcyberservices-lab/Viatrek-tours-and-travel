import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  adminAccounts,
  blogPosts,
  bookings,
  chatbotFaqs,
  chatbotLeads,
  contactMessages,
  destinations,
  galleryItems,
  newsletterSubscribers,
  pageSeo,
  passwordResetTokens,
  reviews,
  siteSettings,
  specialOffers,
  teamMembers,
  testimonials,
  tours,
  transfers,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { scryptSync, randomBytes } from "crypto";

let _db: ReturnType<typeof drizzle> | null = null;

// ============================================================
// PASSWORD HASHING
// ============================================================
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, hash: string): boolean {
  const [salt, storedHash] = hash.split(":");
  if (!salt || !storedHash) return false;
  const computedHash = scryptSync(password, salt, 64).toString("hex");
  return computedHash === storedHash;
}

export function generateResetToken(): string {
  return randomBytes(32).toString("hex");
}

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================
// USERS
// ============================================================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ============================================================
// TOURS
// ============================================================
export async function getTours(opts?: { featured?: boolean; category?: string; search?: string; published?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(tours).$dynamic();
  const conditions = [];
  if (opts?.published !== undefined) conditions.push(eq(tours.published, opts.published));
  if (opts?.featured) conditions.push(eq(tours.featured, true));
  if (opts?.category) conditions.push(eq(tours.category, opts.category as any));
  if (opts?.search) {
    conditions.push(or(
      like(tours.title, `%${opts.search}%`),
      like(tours.shortDescription, `%${opts.search}%`)
    ));
  }
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(tours.sortOrder, desc(tours.createdAt));
}

export async function getTourBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(tours).where(eq(tours.slug, slug)).limit(1);
  return result[0];
}

export async function getTourById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(tours).where(eq(tours.id, id)).limit(1);
  return result[0];
}

export async function createTour(data: typeof tours.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(tours).values(data);
  return result;
}

export async function updateTour(id: number, data: Partial<typeof tours.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(tours).set(data).where(eq(tours.id, id));
}

export async function deleteTour(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(tours).where(eq(tours.id, id));
}

// ============================================================
// DESTINATIONS
// ============================================================
export async function getDestinations(opts?: { featured?: boolean; published?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(destinations).$dynamic();
  const conditions = [];
  if (opts?.published !== undefined) conditions.push(eq(destinations.published, opts.published));
  if (opts?.featured) conditions.push(eq(destinations.featured, true));
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(destinations.sortOrder, destinations.name);
}

export async function getDestinationBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(destinations).where(eq(destinations.slug, slug)).limit(1);
  return result[0];
}

export async function createDestination(data: typeof destinations.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(destinations).values(data);
}

export async function updateDestination(id: number, data: Partial<typeof destinations.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(destinations).set(data).where(eq(destinations.id, id));
}

export async function deleteDestination(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(destinations).where(eq(destinations.id, id));
}

// ============================================================
// TRANSFERS
// ============================================================
export async function getTransfers(published?: boolean) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(transfers).$dynamic();
  if (published !== undefined) query = query.where(eq(transfers.published, published));
  return query.orderBy(transfers.sortOrder);
}

export async function getTransferBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(transfers).where(eq(transfers.slug, slug)).limit(1);
  return result[0];
}

export async function createTransfer(data: typeof transfers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(transfers).values(data);
}

export async function updateTransfer(id: number, data: Partial<typeof transfers.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(transfers).set(data).where(eq(transfers.id, id));
}

export async function deleteTransfer(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(transfers).where(eq(transfers.id, id));
}

// ============================================================
// BOOKINGS
// ============================================================
export async function getBookings(status?: string) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(bookings).$dynamic();
  if (status) query = query.where(eq(bookings.status, status as any));
  return query.orderBy(desc(bookings.createdAt));
}

export async function getBookingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
  return result[0];
}

export async function createBooking(data: typeof bookings.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(bookings).values(data);
}

export async function updateBookingStatus(id: number, status: string, adminNotes?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(bookings).set({ status: status as any, adminNotes }).where(eq(bookings.id, id));
}

export async function getBookingStats() {
  const db = await getDb();
  if (!db) return { total: 0, pending: 0, confirmed: 0, completed: 0 };
  const result = await db.select({
    status: bookings.status,
    count: sql<number>`count(*)`,
  }).from(bookings).groupBy(bookings.status);
  const stats = { total: 0, pending: 0, confirmed: 0, completed: 0, rejected: 0, cancelled: 0 };
  for (const row of result) {
    stats.total += Number(row.count);
    if (row.status) stats[row.status as keyof typeof stats] = Number(row.count);
  }
  return stats;
}

// ============================================================
// BLOG POSTS
// ============================================================
export async function getBlogPosts(opts?: { published?: boolean; featured?: boolean; category?: string }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(blogPosts).$dynamic();
  const conditions = [];
  if (opts?.published !== undefined) conditions.push(eq(blogPosts.published, opts.published));
  if (opts?.featured) conditions.push(eq(blogPosts.featured, true));
  if (opts?.category) conditions.push(eq(blogPosts.category, opts.category));
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(desc(blogPosts.createdAt));
}

export async function getBlogPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  return result[0];
}

export async function createBlogPost(data: typeof blogPosts.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(blogPosts).values(data);
}

export async function updateBlogPost(id: number, data: Partial<typeof blogPosts.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(blogPosts).set(data).where(eq(blogPosts.id, id));
}

export async function deleteBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

export async function incrementBlogViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(blogPosts).set({ views: sql`views + 1` }).where(eq(blogPosts.id, id));
}

// ============================================================
// REVIEWS
// ============================================================
export async function getReviews(opts?: { status?: string; featured?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(reviews).$dynamic();
  const conditions = [];
  if (opts?.status) conditions.push(eq(reviews.status, opts.status as any));
  if (opts?.featured) conditions.push(eq(reviews.featured, true));
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(desc(reviews.createdAt));
}

export async function createReview(data: typeof reviews.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(reviews).values(data);
}

export async function updateReviewStatus(id: number, status: string, featured?: boolean) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const updateData: Record<string, unknown> = { status };
  if (featured !== undefined) updateData.featured = featured;
  await db.update(reviews).set(updateData as any).where(eq(reviews.id, id));
}

export async function deleteReview(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(reviews).where(eq(reviews.id, id));
}

// ============================================================
// GALLERY
// ============================================================
export async function getGalleryItems(opts?: { category?: string; type?: string; published?: boolean; featured?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(galleryItems).$dynamic();
  const conditions = [];
  if (opts?.published !== undefined) conditions.push(eq(galleryItems.published, opts.published));
  if (opts?.featured) conditions.push(eq(galleryItems.featured, true));
  if (opts?.category) conditions.push(eq(galleryItems.category, opts.category));
  if (opts?.type) conditions.push(eq(galleryItems.type, opts.type as any));
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(galleryItems.sortOrder, desc(galleryItems.createdAt));
}

export async function createGalleryItem(data: typeof galleryItems.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(galleryItems).values(data);
}

export async function updateGalleryItem(id: number, data: Partial<typeof galleryItems.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(galleryItems).set(data).where(eq(galleryItems.id, id));
}

export async function deleteGalleryItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(galleryItems).where(eq(galleryItems.id, id));
}

// ============================================================
// CHATBOT FAQs
// ============================================================
export async function getChatbotFaqs(active?: boolean) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(chatbotFaqs).$dynamic();
  if (active !== undefined) query = query.where(eq(chatbotFaqs.active, active));
  return query.orderBy(chatbotFaqs.sortOrder);
}

export async function createChatbotFaq(data: typeof chatbotFaqs.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(chatbotFaqs).values(data);
}

export async function updateChatbotFaq(id: number, data: Partial<typeof chatbotFaqs.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(chatbotFaqs).set(data).where(eq(chatbotFaqs.id, id));
}

export async function deleteChatbotFaq(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(chatbotFaqs).where(eq(chatbotFaqs.id, id));
}

export async function createChatbotLead(data: typeof chatbotLeads.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(chatbotLeads).values(data);
}

export async function getChatbotLeads() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatbotLeads).orderBy(desc(chatbotLeads.createdAt));
}

// ============================================================
// NEWSLETTER
// ============================================================
export async function subscribeNewsletter(email: string, name?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(newsletterSubscribers)
    .values({ email, name, status: "active" })
    .onDuplicateKeyUpdate({ set: { status: "active", name: name ?? undefined } });
}

export async function getNewsletterSubscribers(status?: string) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(newsletterSubscribers).$dynamic();
  if (status) query = query.where(eq(newsletterSubscribers.status, status as any));
  return query.orderBy(desc(newsletterSubscribers.createdAt));
}

// ============================================================
// CONTACT MESSAGES
// ============================================================
export async function createContactMessage(data: typeof contactMessages.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(contactMessages).values(data);
}

export async function getContactMessages(status?: string) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(contactMessages).$dynamic();
  if (status) query = query.where(eq(contactMessages.status, status as any));
  return query.orderBy(desc(contactMessages.createdAt));
}

export async function updateContactMessageStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(contactMessages).set({ status: status as any }).where(eq(contactMessages.id, id));
}

// ============================================================
// TESTIMONIALS
// ============================================================
export async function getTestimonials(opts?: { active?: boolean; featured?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(testimonials).$dynamic();
  const conditions = [];
  if (opts?.active !== undefined) conditions.push(eq(testimonials.active, opts.active));
  if (opts?.featured) conditions.push(eq(testimonials.featured, true));
  if (conditions.length) query = query.where(and(...conditions));
  return query.orderBy(testimonials.sortOrder);
}

export async function createTestimonial(data: typeof testimonials.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(testimonials).values(data);
}

export async function updateTestimonial(id: number, data: Partial<typeof testimonials.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(testimonials).set(data).where(eq(testimonials.id, id));
}

export async function deleteTestimonial(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(testimonials).where(eq(testimonials.id, id));
}

// ============================================================
// SPECIAL OFFERS
// ============================================================
export async function getSpecialOffers(active?: boolean) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(specialOffers).$dynamic();
  if (active !== undefined) query = query.where(eq(specialOffers.active, active));
  return query.orderBy(specialOffers.sortOrder);
}

export async function createSpecialOffer(data: typeof specialOffers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(specialOffers).values(data);
}

export async function updateSpecialOffer(id: number, data: Partial<typeof specialOffers.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(specialOffers).set(data).where(eq(specialOffers.id, id));
}

export async function deleteSpecialOffer(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(specialOffers).where(eq(specialOffers.id, id));
}

// ============================================================
// TEAM MEMBERS
// ============================================================
export async function getTeamMembers(active?: boolean) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(teamMembers).$dynamic();
  if (active !== undefined) query = query.where(eq(teamMembers.active, active));
  return query.orderBy(teamMembers.sortOrder);
}

export async function createTeamMember(data: typeof teamMembers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(teamMembers).values(data);
}

export async function updateTeamMember(id: number, data: Partial<typeof teamMembers.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(teamMembers).set(data).where(eq(teamMembers.id, id));
}

export async function deleteTeamMember(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(teamMembers).where(eq(teamMembers.id, id));
}

// ============================================================
// SITE SETTINGS
// ============================================================
export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(siteSettings).where(eq(siteSettings.key, key)).limit(1);
  return result[0]?.value ?? null;
}

export async function getSettingsByGroup(group: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteSettings).where(eq(siteSettings.group, group));
}

export async function getAllSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteSettings);
}

export async function upsertSetting(key: string, value: string, label?: string, group?: string, type?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(siteSettings)
    .values({ key, value, label, group, type: (type as any) ?? "text" })
    .onDuplicateKeyUpdate({ set: { value, label: label ?? undefined, group: group ?? undefined } });
}

// ============================================================
// PAGE SEO
// ============================================================
export async function getPageSeo(page: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(pageSeo).where(eq(pageSeo.page, page)).limit(1);
  return result[0] ?? null;
}

export async function getAllPageSeo() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pageSeo);
}

export async function upsertPageSeo(page: string, data: Partial<typeof pageSeo.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(pageSeo)
    .values({ page, ...data })
    .onDuplicateKeyUpdate({ set: data as any });
}

// ============================================================
// ADMIN ACCOUNTS
// ============================================================
export async function createAdminAccount(email: string, password: string, role: "master" | "admin" = "admin") {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const passwordHash = hashPassword(password);
  const result = await db.insert(adminAccounts).values({
    email,
    passwordHash,
    role,
    isActive: true,
  });
  return result;
}

export async function getAdminByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(adminAccounts).where(eq(adminAccounts.email, email)).limit(1);
  return result[0] ?? null;
}

export async function getAdminById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(adminAccounts).where(eq(adminAccounts.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getAllAdmins() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(adminAccounts);
}

export async function updateAdminPassword(adminId: number, newPassword: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const passwordHash = hashPassword(newPassword);
  await db.update(adminAccounts).set({ passwordHash }).where(eq(adminAccounts.id, adminId));
}

export async function deleteAdmin(adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(adminAccounts).where(eq(adminAccounts.id, adminId));
}

export async function updateAdminRole(adminId: number, role: "master" | "admin") {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(adminAccounts).set({ role }).where(eq(adminAccounts.id, adminId));
}

// ============================================================
// PASSWORD RESET TOKENS
// ============================================================
export async function createPasswordResetToken(adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const token = generateResetToken();
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
  await db.insert(passwordResetTokens).values({ adminId, token, expiresAt });
  return token;
}

export async function getPasswordResetToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.token, token)).limit(1);
  const resetToken = result[0];
  if (!resetToken) return null;
  if (new Date() > resetToken.expiresAt) {
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.token, token));
    return null;
  }
  return resetToken;
}

export async function deletePasswordResetToken(token: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(passwordResetTokens).where(eq(passwordResetTokens.token, token));
}
