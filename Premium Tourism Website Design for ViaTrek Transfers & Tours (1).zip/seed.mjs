import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Seed destinations
const destinations = [
  { name: 'Mombasa', slug: 'mombasa', region: 'Coastal Kenya', shortDescription: "The White & Blue City — Kenya's vibrant coastal capital", description: "Mombasa is Kenya's second-largest city and the country's oldest, with a rich history spanning over 2,000 years. The city blends African, Arab, and European influences, creating a unique cultural tapestry. Explore the iconic Fort Jesus, wander through the narrow streets of the Old Town, and relax on the pristine beaches.", featured: 1, published: 1 },
  { name: 'Diani', slug: 'diani', region: 'Coastal Kenya', shortDescription: "Kenya's Paradise Beach — pristine white sands and turquoise waters", description: "Diani Beach is consistently rated among Africa's best beaches. With its powder-white sands, crystal-clear turquoise waters, and lush coastal forest, it's the perfect tropical paradise. Enjoy water sports, snorkeling, diving, and world-class resorts.", featured: 1, published: 1 },
  { name: 'Watamu', slug: 'watamu', region: 'Coastal Kenya', shortDescription: 'Marine Park Wonder — coral reefs and sea turtles', description: "Watamu is home to one of Kenya's three marine national parks. The area is famous for its stunning coral reefs, sea turtles, and diverse marine life. It's a paradise for snorkelers, divers, and nature lovers.", featured: 1, published: 1 },
  { name: 'Malindi', slug: 'malindi', region: 'Coastal Kenya', shortDescription: 'Historic Coastal Town — where history meets the Indian Ocean', description: "Malindi is one of Kenya's oldest towns, with a history dating back to the 14th century. The town offers a fascinating mix of Swahili culture, Portuguese heritage, and modern beach tourism.", featured: 0, published: 1 },
  { name: 'Tsavo', slug: 'tsavo', region: 'South Kenya', shortDescription: "Land of Red Elephants — Kenya's largest national park", description: "Tsavo is Kenya's largest national park, divided into Tsavo East and Tsavo West. Famous for its red-dust-covered elephants, diverse wildlife, and dramatic landscapes including the Mzima Springs and Lugard Falls.", featured: 1, published: 1 },
  { name: 'Amboseli', slug: 'amboseli', region: 'South Kenya', shortDescription: "Kilimanjaro's Shadow — elephants against Africa's highest peak", description: "Amboseli National Park offers one of Africa's most iconic views — large elephant herds roaming against the backdrop of Mount Kilimanjaro. The park is also home to lions, cheetahs, zebras, and over 400 bird species.", featured: 1, published: 1 },
  { name: 'Maasai Mara', slug: 'maasai-mara', region: 'Rift Valley', shortDescription: 'Great Migration — the greatest wildlife spectacle on Earth', description: "The Maasai Mara is Kenya's most famous wildlife reserve and home to the Great Migration — the annual movement of over 1.5 million wildebeest, zebras, and gazelles. The reserve offers exceptional year-round game viewing.", featured: 1, published: 1 },
  { name: 'Naivasha', slug: 'naivasha', region: 'Rift Valley', shortDescription: 'Lake & Flamingos — freshwater lake in the Great Rift Valley', description: "Lake Naivasha is a freshwater lake in the Great Rift Valley, surrounded by lush vegetation and home to hippos, diverse bird species, and beautiful flora. Nearby Hells Gate National Park offers unique cycling safaris.", featured: 0, published: 1 },
  { name: 'Nakuru', slug: 'nakuru', region: 'Rift Valley', shortDescription: 'Flamingo Lake — rhinos and flamingos in the Rift Valley', description: "Lake Nakuru National Park is famous for its flamingo population and is one of Kenya's best parks for rhino sightings. The park also hosts lions, leopards, buffaloes, and over 450 bird species.", featured: 0, published: 1 },
  { name: 'Nairobi', slug: 'nairobi', region: 'Central Kenya', shortDescription: "The Safari Capital — Africa's most exciting city", description: "Nairobi is Africa's most cosmopolitan city and the gateway to Kenya's safari circuit. Visit the Nairobi National Park, Karen Blixen Museum, Giraffe Centre, and David Sheldrick Wildlife Trust.", featured: 1, published: 1 },
];

for (const dest of destinations) {
  await conn.execute(
    'INSERT IGNORE INTO destinations (name, slug, region, shortDescription, description, featured, published, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [dest.name, dest.slug, dest.region, dest.shortDescription, dest.description, dest.featured, dest.published]
  );
}
console.log('Destinations seeded:', destinations.length);

// Seed tours
const tours = [
  { title: 'Diani Beach Paradise', slug: 'diani-beach-paradise', category: 'beach', shortDescription: "Relax on Kenya's most beautiful white sand beach with crystal-clear turquoise waters.", description: 'Experience the ultimate beach holiday at Diani, consistently rated Africa\'s best beach. Enjoy snorkeling, dhow cruises, water sports, and sunset cocktails by the Indian Ocean.', price: '299', priceUnit: 'per person', duration: '3 Days / 2 Nights', maxGroupSize: 12, availability: 'Year-round', difficulty: 'easy', featured: 1, published: 1, highlights: JSON.stringify(['Pristine white sand beaches', 'Snorkeling in coral reefs', 'Traditional dhow sunset cruise', 'Water sports activities', 'Fresh seafood dining']), included: JSON.stringify(['Accommodation', 'Daily breakfast', 'Airport transfers', 'Snorkeling equipment', 'Dhow cruise']), excluded: JSON.stringify(['International flights', 'Travel insurance', 'Personal expenses', 'Alcoholic beverages']) },
  { title: 'Maasai Mara Safari Adventure', slug: 'maasai-mara-safari', category: 'safari', shortDescription: "Witness the Great Migration and Big Five in Kenya's most iconic wildlife reserve.", description: 'Experience the magic of the Maasai Mara on this unforgettable safari. Witness the Great Migration, track the Big Five, and immerse yourself in Maasai culture with expert guides.', price: '899', priceUnit: 'per person', duration: '4 Days / 3 Nights', maxGroupSize: 8, availability: 'Year-round (Best: July-October)', difficulty: 'easy', featured: 1, published: 1, highlights: JSON.stringify(['Big Five game drives', 'Great Migration (seasonal)', 'Maasai village visit', 'Hot air balloon safari option', 'Sundowner in the bush']), included: JSON.stringify(['Tented camp accommodation', 'All meals', 'Game drives', 'Park fees', 'Expert guide']), excluded: JSON.stringify(['International flights', 'Travel insurance', 'Hot air balloon', 'Visa fees']) },
  { title: 'Amboseli Elephant Safari', slug: 'amboseli-elephant-safari', category: 'safari', shortDescription: 'Photograph massive elephant herds against the stunning backdrop of Mount Kilimanjaro.', description: "Amboseli offers Africa's most iconic safari experience — large elephant herds roaming freely against the majestic backdrop of Mount Kilimanjaro. A photographer's dream destination.", price: '749', priceUnit: 'per person', duration: '3 Days / 2 Nights', maxGroupSize: 8, availability: 'Year-round', difficulty: 'easy', featured: 1, published: 1, highlights: JSON.stringify(['Elephant herds up close', 'Kilimanjaro views', 'Big Five game drives', 'Maasai cultural experience', 'Bird watching']), included: JSON.stringify(['Lodge accommodation', 'Full board meals', 'Game drives', 'Park fees', 'Professional guide']), excluded: JSON.stringify(['Flights to Nairobi', 'Travel insurance', 'Personal expenses']) },
  { title: 'Mombasa Cultural City Tour', slug: 'mombasa-cultural-tour', category: 'cultural', shortDescription: "Explore the rich history and vibrant culture of Kenya's oldest city.", description: "Discover the fascinating history of Mombasa — from the ancient Fort Jesus to the spice-scented Old Town. Experience the unique blend of Swahili, Arab, and Portuguese cultures that make this city extraordinary.", price: '149', priceUnit: 'per person', duration: '1 Day', maxGroupSize: 15, availability: 'Daily', difficulty: 'easy', featured: 0, published: 1, highlights: JSON.stringify(['Fort Jesus UNESCO site', 'Old Town walking tour', 'Spice market visit', 'Traditional Swahili lunch', 'Haller Park wildlife']), included: JSON.stringify(['Professional guide', 'Transport', 'Fort Jesus entry', 'Traditional lunch']), excluded: JSON.stringify(['Personal shopping', 'Alcoholic beverages', 'Tips']) },
  { title: 'Honeymoon Kenya Package', slug: 'honeymoon-kenya', category: 'honeymoon', shortDescription: "A romantic journey through Kenya's most beautiful destinations for couples.", description: 'Create unforgettable memories on your honeymoon with this specially curated Kenya package. From romantic beach sunsets in Diani to magical safari evenings in the Mara, every moment is crafted for love.', price: '2499', priceUnit: 'per couple', duration: '7 Days / 6 Nights', maxGroupSize: 2, availability: 'Year-round', difficulty: 'easy', featured: 1, published: 1, highlights: JSON.stringify(['Private beach villa', 'Romantic safari camp', 'Couples spa treatment', 'Private dhow sunset cruise', 'Champagne breakfast']), included: JSON.stringify(['Luxury accommodation', 'All meals', 'Private transfers', 'Safari game drives', 'Spa treatment', 'Champagne on arrival']), excluded: JSON.stringify(['International flights', 'Travel insurance', 'Personal expenses']) },
  { title: 'Family Kenya Adventure', slug: 'family-kenya-adventure', category: 'family', shortDescription: 'A fun-filled Kenya adventure designed for families with children of all ages.', description: 'Create lasting family memories in Kenya! This specially designed family package combines wildlife adventures, beach fun, and cultural experiences suitable for children and adults alike.', price: '599', priceUnit: 'per person', duration: '5 Days / 4 Nights', maxGroupSize: 20, availability: 'School holidays', difficulty: 'easy', featured: 0, published: 1, highlights: JSON.stringify(['Kid-friendly game drives', 'Beach activities', 'Giraffe Centre Nairobi', 'Elephant orphanage visit', 'Cultural village experience']), included: JSON.stringify(['Family-friendly accommodation', 'All meals', 'Transport', 'Activity fees', 'Child-friendly guides']), excluded: JSON.stringify(['International flights', 'Travel insurance', 'Personal expenses']) },
  { title: 'Tsavo Red Elephant Safari', slug: 'tsavo-safari', category: 'safari', shortDescription: "Explore Kenya's largest national park and encounter the famous red elephants.", description: "Tsavo National Park is Kenya's largest and most diverse wildlife area. Famous for its red-dust-covered elephants, the park offers incredible wildlife viewing, dramatic landscapes, and the crystal-clear Mzima Springs.", price: '649', priceUnit: 'per person', duration: '3 Days / 2 Nights', maxGroupSize: 8, availability: 'Year-round', difficulty: 'easy', featured: 0, published: 1, highlights: JSON.stringify(['Red elephant herds', 'Mzima Springs', 'Lugard Falls', 'Diverse wildlife', 'Scenic landscapes']), included: JSON.stringify(['Lodge accommodation', 'Full board', 'Game drives', 'Park fees', 'Guide']), excluded: JSON.stringify(['Flights', 'Travel insurance', 'Personal expenses']) },
  { title: 'Watamu Marine Adventure', slug: 'watamu-marine', category: 'beach', shortDescription: "Snorkel and dive in Watamu's spectacular coral reefs and marine national park.", description: "Watamu Marine National Park is one of Kenya's most pristine marine environments. Explore vibrant coral reefs, swim with sea turtles, and discover the incredible biodiversity of the Indian Ocean.", price: '349', priceUnit: 'per person', duration: '2 Days / 1 Night', maxGroupSize: 10, availability: 'October-March (best visibility)', difficulty: 'moderate', featured: 0, published: 1, highlights: JSON.stringify(['Coral reef snorkeling', 'Sea turtle encounters', 'Deep sea fishing option', 'Marine park guided tour', 'Sunset dhow cruise']), included: JSON.stringify(['Accommodation', 'Breakfast', 'Snorkeling equipment', 'Marine park fees', 'Guide']), excluded: JSON.stringify(['Flights', 'Lunch & dinner', 'Deep sea fishing']) },
  { title: 'Corporate Team Building Safari', slug: 'corporate-team-building', category: 'corporate', shortDescription: 'Strengthen your team with a unique corporate safari experience in the African bush.', description: 'Transform your team dynamics with our specially designed corporate safari package. Combine wildlife experiences with team-building activities, leadership workshops, and networking in the stunning African wilderness.', price: '799', priceUnit: 'per person', duration: '3 Days / 2 Nights', maxGroupSize: 50, availability: 'Year-round', difficulty: 'easy', featured: 0, published: 1, highlights: JSON.stringify(['Team building activities', 'Safari game drives', 'Leadership workshops', 'Networking sundowners', 'Cultural experiences']), included: JSON.stringify(['Conference facilities', 'Accommodation', 'All meals', 'Game drives', 'Team activities']), excluded: JSON.stringify(['Flights', 'Personal expenses']) },
  { title: 'Custom Kenya Tour', slug: 'custom-kenya-tour', category: 'custom', shortDescription: "Design your perfect Kenya adventure — we'll make your dream trip a reality.", description: "Can't find exactly what you're looking for? Let us create a completely customized Kenya experience tailored to your interests, budget, and schedule. Our expert team will design your perfect adventure.", price: null, priceUnit: 'custom pricing', duration: 'Flexible', maxGroupSize: null, availability: 'Year-round', difficulty: 'easy', featured: 1, published: 1, highlights: JSON.stringify(['Fully customizable itinerary', 'Any destination in Kenya', 'Private or group options', 'All budgets welcome', 'Expert local knowledge']), included: JSON.stringify(['Personalized planning', 'Dedicated travel consultant', 'Flexible scheduling']), excluded: JSON.stringify(['Varies by package']) },
];

for (const tour of tours) {
  await conn.execute(
    'INSERT IGNORE INTO tours (title, slug, category, shortDescription, description, price, priceUnit, duration, maxGroupSize, availability, difficulty, featured, published, highlights, included, excluded, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [tour.title, tour.slug, tour.category, tour.shortDescription, tour.description, tour.price, tour.priceUnit, tour.duration, tour.maxGroupSize, tour.availability, tour.difficulty, tour.featured, tour.published, tour.highlights, tour.included, tour.excluded]
  );
}
console.log('Tours seeded:', tours.length);

// Seed chatbot FAQs
const faqs = [
  { question: 'What is the best time to visit Kenya?', answer: "Kenya is a year-round destination! The best time for wildlife viewing is during the dry seasons: January-February and June-October. The Great Migration in the Maasai Mara peaks from July to October. Beach destinations like Diani and Watamu are best from October to March.", category: 'general', active: 1 },
  { question: 'How do I book a tour with ViaTrek?', answer: "Booking is easy! You can book directly on our website by clicking 'Book Now' on any tour, fill out our contact form, or WhatsApp us at +254701475532. We'll confirm your booking within 24 hours and send you a detailed itinerary.", category: 'booking', active: 1 },
  { question: 'What payment methods do you accept?', answer: "We accept M-Pesa, bank transfers, credit/debit cards, and PayPal. A 30% deposit is required to confirm your booking, with the balance due 14 days before your tour date. For last-minute bookings, full payment is required.", category: 'pricing', active: 1 },
  { question: 'Do you offer airport transfers?', answer: "Yes! We offer reliable airport transfers to/from Mombasa (MBA), Nairobi (NBO), and all major airports in Kenya. We also provide hotel-to-hotel transfers, VIP transfers in luxury vehicles, and group transfers in comfortable coaches. Contact us for rates.", category: 'transfers', active: 1 },
  { question: 'Is Kenya safe for tourists?', answer: "Kenya is generally safe for tourists, especially in the main tourist areas. We recommend staying in established tourist zones, using reputable transport, and following local advice. Our guides are experienced and prioritize your safety throughout every tour.", category: 'safety', active: 1 },
  { question: 'What should I pack for a Kenya safari?', answer: "For a safari, pack: neutral-colored clothing (khaki, beige, olive), light layers for morning/evening, sunscreen and insect repellent, a hat, binoculars, camera with extra batteries, and comfortable walking shoes. Avoid bright colors and white clothing.", category: 'general', active: 1 },
  { question: 'Do I need a visa to visit Kenya?', answer: "Most nationalities can obtain a Kenya e-Visa online at evisa.go.ke before travel. The fee is typically $51 USD for a single entry. East African Community citizens don't need a visa. We recommend applying at least 2 weeks before travel.", category: 'general', active: 1 },
  { question: 'What is included in your tour packages?', answer: "Our packages typically include accommodation, meals as specified, transport, park/entry fees, and professional guides. Specific inclusions vary by package — each tour page lists exactly what's included and excluded. Contact us for a detailed quote.", category: 'tours', active: 1 },
  { question: 'Can you arrange custom or private tours?', answer: "Absolutely! We specialize in custom tours tailored to your interests, budget, and schedule. Whether you want a private romantic getaway, a family adventure, or a corporate retreat, we'll design the perfect itinerary. Contact us to start planning!", category: 'tours', active: 1 },
  { question: 'What is the minimum group size for tours?', answer: "Most of our tours can be done as private tours for 1-2 people, or as group tours with 2-15 people. We also offer large group packages for 15+ travelers. Solo travelers are welcome on our scheduled group departures at reduced rates.", category: 'tours', active: 1 },
];

for (const faq of faqs) {
  await conn.execute(
    'INSERT IGNORE INTO chatbot_faqs (question, answer, category, active, sortOrder, createdAt, updatedAt) VALUES (?, ?, ?, ?, 0, NOW(), NOW())',
    [faq.question, faq.answer, faq.category, faq.active]
  );
}
console.log('FAQs seeded:', faqs.length);

// Seed testimonials
const testimonials = [
  { reviewerName: 'Sarah Mitchell', reviewerCountry: 'United Kingdom', reviewerAvatar: '', title: 'Absolutely magical safari experience!', content: "ViaTrek organized the most incredible Maasai Mara safari for our family. The guides were knowledgeable, the accommodation was stunning, and we witnessed the Great Migration! Highly recommend to anyone visiting Kenya.", rating: 5, tourName: 'Maasai Mara Safari Adventure', featured: 1, published: 1 },
  { reviewerName: 'James Omondi', reviewerCountry: 'Kenya', reviewerAvatar: '', title: 'Best honeymoon we could have asked for', content: "My wife and I had the most romantic honeymoon thanks to ViaTrek. From the private beach villa in Diani to the magical safari camp, every detail was perfect. The team went above and beyond to make our trip special.", rating: 5, tourName: 'Honeymoon Kenya Package', featured: 1, published: 1 },
  { reviewerName: 'Emma van der Berg', reviewerCountry: 'Netherlands', reviewerAvatar: '', title: 'Professional, reliable, and fun!', content: "I've traveled with many tour operators across Africa, but ViaTrek stands out for their professionalism and genuine passion for Kenya. The Amboseli elephant safari exceeded all expectations. Will definitely book again!", rating: 5, tourName: 'Amboseli Elephant Safari', featured: 1, published: 1 },
  { reviewerName: 'Michael Chen', reviewerCountry: 'Singapore', reviewerAvatar: '', title: 'Seamless airport transfer service', content: "Used ViaTrek for airport transfers throughout our Kenya trip. Always on time, clean vehicles, and friendly drivers who knew the best local spots. Made our travel stress-free. Excellent value for money!", rating: 5, tourName: 'Airport Transfer', featured: 1, published: 1 },
];

for (const t of testimonials) {
  await conn.execute(
    'INSERT IGNORE INTO testimonials (reviewerName, reviewerCountry, reviewerAvatar, title, content, rating, tourName, featured, published, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [t.reviewerName, t.reviewerCountry, t.reviewerAvatar, t.title, t.content, t.rating, t.tourName, t.featured, t.published]
  );
}
console.log('Testimonials seeded:', testimonials.length);

// Seed special offers
const offers = [
  { title: 'Early Bird Safari Discount', description: 'Book your Maasai Mara safari 60+ days in advance and save 20% on the total package price.', discountPercent: 20, validUntil: '2026-12-31', code: 'EARLYBIRD20', active: 1, featured: 1 },
  { title: 'Honeymoon Special', description: 'Celebrate your love with our exclusive honeymoon package — complimentary champagne, rose petals, and a private sunset cruise included.', discountPercent: 15, validUntil: '2026-12-31', code: 'HONEYMOON15', active: 1, featured: 1 },
  { title: 'Group Discount', description: 'Traveling with 6 or more people? Enjoy 10% off all tour packages. Perfect for families, friends, and corporate groups.', discountPercent: 10, validUntil: '2026-12-31', code: 'GROUP10', active: 1, featured: 1 },
];

for (const offer of offers) {
  await conn.execute(
    'INSERT IGNORE INTO special_offers (title, description, discountPercent, validUntil, code, active, featured, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [offer.title, offer.description, offer.discountPercent, offer.validUntil, offer.code, offer.active, offer.featured]
  );
}
console.log('Special offers seeded:', offers.length);

// Seed team members
const team = [
  { name: 'David Mwangi', role: 'Founder & CEO', bio: "With over 15 years of experience in Kenya's tourism industry, David founded ViaTrek with a vision to share the beauty of Kenya with the world. Born and raised in Mombasa, he has an intimate knowledge of every destination.", featured: 1, published: 1, sortOrder: 1 },
  { name: 'Grace Achieng', role: 'Head of Operations', bio: "Grace ensures every ViaTrek tour runs smoothly from start to finish. Her meticulous attention to detail and passion for exceptional customer service have made her an invaluable part of the team.", featured: 1, published: 1, sortOrder: 2 },
  { name: 'Samuel Kipchoge', role: 'Lead Safari Guide', bio: "Samuel is a certified wildlife guide with 12 years of experience across Kenya's national parks. His encyclopedic knowledge of African wildlife and storytelling ability make every safari unforgettable.", featured: 1, published: 1, sortOrder: 3 },
  { name: 'Fatuma Hassan', role: 'Cultural Tour Specialist', bio: "Fatuma is passionate about sharing Kenya's rich cultural heritage. She specializes in authentic cultural experiences, from Swahili cooking classes to Maasai village visits.", featured: 1, published: 1, sortOrder: 4 },
];

for (const member of team) {
  await conn.execute(
    'INSERT IGNORE INTO team_members (name, role, bio, featured, published, sortOrder, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [member.name, member.role, member.bio, member.featured, member.published, member.sortOrder]
  );
}
console.log('Team members seeded:', team.length);

// Seed gallery items
const galleryItems = [
  { url: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800', title: 'Maasai Mara Sunrise', category: 'Safari', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=800', title: 'Diani Beach Paradise', category: 'Beach', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=800', title: 'Elephant at Amboseli', category: 'Safari', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=800', title: 'Mombasa Old Town', category: 'Cultural', type: 'photo', featured: 0, published: 1 },
  { url: 'https://images.unsplash.com/photo-1504432842672-1a79f78e4084?w=800', title: 'Watamu Coral Reef', category: 'Beach', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1535941339077-2dd1c7963098?w=800', title: 'Nairobi Giraffe Centre', category: 'Wildlife', type: 'photo', featured: 0, published: 1 },
  { url: 'https://images.unsplash.com/photo-1518709766631-a6a7f45921c3?w=800', title: 'Tsavo Red Elephants', category: 'Safari', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1580060839134-75a5edca2e99?w=800', title: 'Lake Nakuru Flamingos', category: 'Wildlife', type: 'photo', featured: 0, published: 1 },
  { url: 'https://images.unsplash.com/photo-1612686635542-2244ed9f8ddc?w=800', title: 'Sunset Dhow Cruise', category: 'Beach', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1510797215324-95aa89f43c33?w=800', title: 'Maasai Warriors', category: 'Cultural', type: 'photo', featured: 0, published: 1 },
  { url: 'https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=800', title: 'Kilimanjaro View', category: 'Safari', type: 'photo', featured: 1, published: 1 },
  { url: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800', title: 'Kenya Coastline', category: 'Beach', type: 'photo', featured: 0, published: 1 },
];

for (const item of galleryItems) {
  await conn.execute(
    'INSERT IGNORE INTO gallery_items (url, title, category, type, featured, published, sortOrder, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 0, NOW(), NOW())',
    [item.url, item.title, item.category, item.type, item.featured, item.published]
  );
}
console.log('Gallery items seeded:', galleryItems.length);

// Seed blog posts
const blogPosts = [
  { title: 'The Ultimate Guide to Kenya Safari', slug: 'ultimate-guide-kenya-safari', excerpt: "Everything you need to know before embarking on your first Kenya safari — from the best parks to visit to what to pack.", content: "Kenya is home to some of the world's most spectacular wildlife and landscapes. Whether you're dreaming of witnessing the Great Migration in the Maasai Mara, tracking elephants in Amboseli with Kilimanjaro as your backdrop, or exploring the vast wilderness of Tsavo, Kenya has something extraordinary for every traveler.\n\n## Best Time to Visit\n\nKenya offers year-round safari experiences, but the timing of your visit can significantly impact what you see. The dry seasons (January-February and June-October) are generally the best for wildlife viewing as animals congregate around water sources and vegetation is sparse, making spotting easier.\n\nThe Great Migration typically occurs from July to October when over 1.5 million wildebeest, zebras, and gazelles cross from Tanzania's Serengeti into Kenya's Maasai Mara.\n\n## Top Safari Destinations\n\n**Maasai Mara** — Kenya's most famous reserve, offering exceptional year-round game viewing and the spectacular Great Migration.\n\n**Amboseli** — Famous for large elephant herds and stunning views of Mount Kilimanjaro.\n\n**Tsavo** — Kenya's largest national park, known for its red-dust elephants and diverse landscapes.", category: 'Safari Tips', author: 'Samuel Kipchoge', featured: 1, published: 1, tags: JSON.stringify(['safari', 'kenya', 'wildlife', 'travel guide']) },
  { title: 'Top 10 Beaches in Kenya', slug: 'top-10-beaches-kenya', excerpt: "From the pristine sands of Diani to the historic shores of Malindi, discover Kenya's most beautiful beaches.", content: "Kenya's coastline stretches for over 500 kilometers along the Indian Ocean, offering some of Africa's most beautiful beaches. From the world-famous Diani Beach to the hidden gems of Watamu, here are the top 10 beaches you must visit.\n\n## 1. Diani Beach\nConsistently rated Africa's best beach, Diani features powder-white sand, crystal-clear turquoise waters, and a vibrant tourism scene with excellent resorts, restaurants, and water sports.\n\n## 2. Watamu Beach\nNestled within a marine national park, Watamu offers pristine coral reefs, sea turtles, and some of Kenya's best snorkeling and diving.\n\n## 3. Nyali Beach\nLocated just north of Mombasa, Nyali is a popular beach with a lively atmosphere, good restaurants, and easy access to the city.\n\n## 4. Bamburi Beach\nAnother Mombasa area beach, Bamburi is known for its water sports, beach bars, and the famous Haller Park wildlife sanctuary nearby.\n\n## 5. Malindi Beach\nA historic beach town with beautiful beaches, excellent deep-sea fishing, and a fascinating blend of Swahili and Italian cultures.", category: 'Beach Guide', author: 'Grace Achieng', featured: 1, published: 1, tags: JSON.stringify(['beaches', 'kenya', 'diani', 'watamu', 'coast']) },
  { title: 'Mombasa Old Town: A Walking Guide', slug: 'mombasa-old-town-walking-guide', excerpt: "Explore the narrow streets and rich history of Mombasa's UNESCO-listed Old Town on this self-guided walking tour.", content: "Mombasa's Old Town is one of East Africa's most fascinating historic districts, with a history spanning over 2,000 years. The narrow, winding streets are lined with ornately carved wooden doors, ancient mosques, and crumbling Portuguese-era buildings.\n\n## Starting Point: Fort Jesus\nBegin your walk at Fort Jesus, a UNESCO World Heritage Site built by the Portuguese in 1593. The fort offers excellent views of the harbor and houses a fascinating museum with artifacts from the many cultures that have influenced Mombasa.\n\n## The Old Town Streets\nFrom Fort Jesus, wander into the maze of narrow streets. Look for the intricately carved Zanzibari doors — each one tells a story about the family that once lived there. The doors feature symbols of wealth, religion, and status.\n\n## Mandhry Mosque\nOne of the oldest mosques in Mombasa, dating back to 1570. Non-Muslims can admire the exterior architecture.", category: 'Travel Guide', author: 'Fatuma Hassan', featured: 0, published: 1, tags: JSON.stringify(['mombasa', 'cultural', 'history', 'walking tour']) },
];

for (const post of blogPosts) {
  await conn.execute(
    'INSERT IGNORE INTO blog_posts (title, slug, excerpt, content, category, author, featured, published, tags, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
    [post.title, post.slug, post.excerpt, post.content, post.category, post.author, post.featured, post.published, post.tags]
  );
}
console.log('Blog posts seeded:', blogPosts.length);

await conn.end();
console.log('Seeding complete!');
