import { Link } from "wouter";
import { Shield, Clock, Star, Users, Globe, Award, ChevronRight, Phone, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import HeroSection from "@/components/HeroSection";
import TourCard from "@/components/TourCard";
import { trpc } from "@/lib/trpc";
import { TOUR_CATEGORIES, DESTINATIONS, WHATSAPP_URL, CONTACT_PHONE } from "@/lib/constants";

// ============================================================
// WHY CHOOSE US DATA
// ============================================================
const WHY_CHOOSE_US = [
  { icon: Shield, title: "Trusted & Reliable", desc: "Over 10 years of excellence in Kenya travel with thousands of happy clients worldwide." },
  { icon: Star, title: "Premium Experience", desc: "Handpicked luxury accommodations, expert guides, and personalized service at every step." },
  { icon: Globe, title: "Local Expertise", desc: "Deep knowledge of Kenya's hidden gems, culture, and wildlife that only locals know." },
  { icon: Clock, title: "24/7 Support", desc: "Round-the-clock assistance before, during, and after your journey for complete peace of mind." },
  { icon: Users, title: "Tailored Packages", desc: "Custom itineraries designed around your interests, budget, and travel style." },
  { icon: Award, title: "Award Winning", desc: "Recognized by leading travel associations for outstanding service and sustainability." },
];

// ============================================================
// STAR RATING COMPONENT
// ============================================================
function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${i <= rating ? "fill-current" : "fill-none"}`}
          style={{ color: "oklch(0.78 0.16 75)" }}
        />
      ))}
    </div>
  );
}

// ============================================================
// SECTION HEADER COMPONENT
// ============================================================
function SectionHeader({ badge, title, subtitle, center = true }: {
  badge?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <div className={`mb-12 ${center ? "text-center" : ""}`}>
      {badge && (
        <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
          style={{ background: "oklch(0.72 0.14 195 / 0.12)", color: "oklch(0.45 0.14 240)" }}>
          {badge}
        </span>
      )}
      <h2 className="font-display text-3xl md:text-4xl font-bold text-gray-900 mb-4">{title}</h2>
      {subtitle && <p className="text-gray-500 text-lg max-w-2xl mx-auto">{subtitle}</p>}
    </div>
  );
}

// ============================================================
// HOME PAGE
// ============================================================
export default function Home() {
  const { data: featuredTours = [] } = trpc.tours.list.useQuery({ featured: true });
  const { data: allTours = [] } = trpc.tours.list.useQuery({ published: true });
  const { data: testimonials = [] } = trpc.testimonials.list.useQuery({ featured: true });
  const { data: galleryItems = [] } = trpc.gallery.list.useQuery({ type: "photo" });
  const { data: specialOffers = [] } = trpc.specialOffers.list.useQuery();
  const { data: featuredDestinations = [] } = trpc.destinations.list.useQuery({ featured: true });

  const displayTours = featuredTours.length > 0 ? featuredTours : allTours;

  return (
    <div className="min-h-screen">
      {/* HERO */}
      <HeroSection />

      {/* TOUR CATEGORIES */}
      <section className="py-16 bg-sand" style={{ background: "oklch(0.96 0.03 85)" }}>
        <div className="container">
          <SectionHeader
            badge="What We Offer"
            title="Explore Tour Categories"
            subtitle="From pristine beaches to wild safaris — find the perfect Kenya adventure for you."
          />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {TOUR_CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={`/tours?category=${cat.id}`}
                className="group flex flex-col items-center gap-3 p-4 bg-white rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-1 text-center cursor-pointer"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform duration-200`}>
                  {cat.icon}
                </div>
                <span className="text-sm font-semibold text-gray-700 group-hover:text-ocean transition-colors duration-200"
                  style={{ fontFamily: "var(--font-sans)" }}>
                  {cat.label}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED TOURS */}
      <section className="py-20">
        <div className="container">
          <div className="flex items-end justify-between mb-12">
            <SectionHeader
              badge="Top Picks"
              title="Featured Tours & Safaris"
              subtitle="Our most popular and highly-rated Kenya experiences"
              center={false}
            />
            <Link href="/tours">
              <Button variant="outline" className="hidden md:flex items-center gap-2 rounded-xl"
                style={{ borderColor: "oklch(0.72 0.14 195)", color: "oklch(0.45 0.14 240)" }}>
                View All Tours <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          {displayTours.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {displayTours.slice(0, 8).map((tour) => (
                <TourCard key={tour.id} tour={tour} />
              ))}
            </div>
          ) : (
            /* Placeholder cards when no tours in DB */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[
                { title: "Diani Beach Getaway", category: "beach", price: "299", duration: "3 Days", image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80" },
                { title: "Maasai Mara Safari", category: "safari", price: "599", duration: "5 Days", image: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&q=80" },
                { title: "Mombasa Cultural Tour", category: "cultural", price: "199", duration: "2 Days", image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80" },
                { title: "Amboseli Elephant Safari", category: "safari", price: "499", duration: "4 Days", image: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&q=80" },
              ].map((t, i) => (
                <div key={i} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
                  <div className="relative overflow-hidden aspect-[4/3]">
                    <img src={t.image} alt={t.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                    <div className="absolute top-3 right-3">
                      <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-amber-100 text-amber-700 capitalize">{t.category}</span>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-display font-bold text-lg text-gray-900 mb-2">{t.title}</h3>
                    <p className="text-gray-500 text-sm mb-4">Experience the best of Kenya with our expertly curated tour package.</p>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs text-gray-400">From</span>
                        <p className="font-bold text-lg" style={{ color: "oklch(0.32 0.12 240)" }}>${t.price} <span className="text-xs font-normal text-gray-400">per person</span></p>
                      </div>
                      <Link href="/tours">
                        <Button size="sm" className="rounded-xl font-semibold" style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}>
                          View Tour
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="text-center mt-10">
            <Link href="/tours">
              <Button size="lg" className="rounded-xl font-semibold px-8"
                style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))", color: "white" }}>
                Explore All Tours <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-20 bg-ocean-gradient text-white" style={{ background: "linear-gradient(135deg, oklch(0.22 0.10 240) 0%, oklch(0.32 0.12 240) 50%, oklch(0.45 0.14 240) 100%)" }}>
        <div className="container">
          <div className="text-center mb-12">
            <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
              style={{ background: "oklch(0.72 0.14 195 / 0.2)", color: "oklch(0.85 0.10 195)", border: "1px solid oklch(0.72 0.14 195 / 0.3)" }}>
              Why ViaTrek
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-4">Why Choose Us?</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">We're not just a tour operator — we're your gateway to authentic, unforgettable Kenya experiences.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {WHY_CHOOSE_US.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-6 rounded-2xl transition-all duration-200 hover:-translate-y-1"
                style={{ background: "oklch(1 0 0 / 0.06)", border: "1px solid oklch(1 0 0 / 0.1)" }}>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: "oklch(0.72 0.14 195 / 0.2)" }}>
                  <Icon className="w-6 h-6" style={{ color: "oklch(0.72 0.14 195)" }} />
                </div>
                <h3 className="font-display font-bold text-lg text-white mb-2">{title}</h3>
                <p className="text-white/65 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-14 pt-14" style={{ borderTop: "1px solid oklch(1 0 0 / 0.1)" }}>
            {[
              { value: "5,000+", label: "Happy Travelers" },
              { value: "10+", label: "Years Experience" },
              { value: "50+", label: "Tour Packages" },
              { value: "4.9★", label: "Average Rating" },
            ].map(({ value, label }) => (
              <div key={label} className="text-center">
                <p className="font-display text-3xl md:text-4xl font-bold mb-1"
                  style={{ color: "oklch(0.78 0.16 75)" }}>{value}</p>
                <p className="text-white/60 text-sm">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DESTINATIONS PREVIEW */}
      <section className="py-20">
        <div className="container">
          <SectionHeader
            badge="Top Destinations"
            title="Explore Kenya's Best Destinations"
            subtitle="From the Indian Ocean coast to the Great Rift Valley — Kenya has it all."
          />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {DESTINATIONS.slice(0, 10).map((dest) => (
              <Link
                key={dest.slug}
                href={`/destinations/${dest.slug}`}
                className="group relative overflow-hidden rounded-2xl aspect-[3/4] cursor-pointer"
              >
                <img
                  src={`https://images.unsplash.com/search/photos/${dest.name.toLowerCase()}+kenya?w=400&q=80`}
                  alt={dest.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=400&q=80`;
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="font-display font-bold text-white text-lg leading-tight">{dest.name}</p>
                  <p className="text-white/70 text-xs mt-0.5">{dest.tagline}</p>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold text-white"
                    style={{ background: "oklch(0.72 0.14 195 / 0.8)" }}>
                    Explore →
                  </span>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/destinations">
              <Button variant="outline" size="lg" className="rounded-xl font-semibold px-8"
                style={{ borderColor: "oklch(0.72 0.14 195)", color: "oklch(0.45 0.14 240)" }}>
                View All Destinations <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* SPECIAL OFFERS */}
      {(specialOffers.length > 0) && (
        <section className="py-20" style={{ background: "oklch(0.96 0.03 85)" }}>
          <div className="container">
            <SectionHeader
              badge="Limited Time"
              title="Special Offers & Deals"
              subtitle="Grab these exclusive deals before they're gone!"
            />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {specialOffers.slice(0, 3).map((offer) => (
                <div key={offer.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                  {offer.coverImage && (
                    <div className="aspect-[16/9] overflow-hidden">
                      <img src={offer.coverImage} alt={offer.title} className="w-full h-full object-cover" loading="lazy" />
                    </div>
                  )}
                  <div className="p-5">
                    {offer.badge && (
                      <span className="inline-block px-2.5 py-1 text-xs font-bold rounded-full mb-3"
                        style={{ background: "oklch(0.62 0.18 75 / 0.15)", color: "oklch(0.62 0.18 75)" }}>
                        {offer.badge}
                      </span>
                    )}
                    <h3 className="font-display font-bold text-lg text-gray-900 mb-2">{offer.title}</h3>
                    <p className="text-gray-500 text-sm mb-4">{offer.description}</p>
                    <div className="flex items-center justify-between">
                      {offer.discount && (
                        <span className="text-2xl font-bold" style={{ color: "oklch(0.62 0.18 75)" }}>
                          {offer.discount} OFF
                        </span>
                      )}
                      {offer.validUntil && (
                        <span className="text-xs text-gray-400">Valid until {offer.validUntil}</span>
                      )}
                    </div>
                    <Link href="/tours">
                      <Button className="w-full mt-4 rounded-xl font-semibold"
                        style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}>
                        Claim Offer
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* GALLERY PREVIEW */}
      {galleryItems.length > 0 && (
        <section className="py-20">
          <div className="container">
            <SectionHeader
              badge="Our Gallery"
              title="Moments That Last Forever"
              subtitle="A glimpse into the incredible experiences we create for our travelers."
            />
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {galleryItems.slice(0, 8).map((item, i) => (
                <div
                  key={item.id}
                  className={`group relative overflow-hidden rounded-xl cursor-pointer ${
                    i === 0 ? "col-span-2 row-span-2" : ""
                  }`}
                  style={{ aspectRatio: i === 0 ? "1/1" : "1/1" }}
                >
                  <img
                    src={item.thumbnailUrl || item.url}
                    alt={item.title || "Gallery"}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                    <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-sm font-medium">
                      View
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-8">
              <Link href="/gallery">
                <Button variant="outline" size="lg" className="rounded-xl font-semibold px-8"
                  style={{ borderColor: "oklch(0.72 0.14 195)", color: "oklch(0.45 0.14 240)" }}>
                  View Full Gallery <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* TESTIMONIALS */}
      <section className="py-20" style={{ background: "oklch(0.96 0.03 85)" }}>
        <div className="container">
          <SectionHeader
            badge="Traveler Reviews"
            title="What Our Clients Say"
            subtitle="Real stories from real travelers who explored Kenya with us."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.length > 0 ? testimonials.slice(0, 6).map((t) => (
              <div key={t.id} className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-200">
                <StarRating rating={t.rating || 5} />
                <p className="text-gray-600 text-sm leading-relaxed my-4 italic">"{t.content}"</p>
                <div className="flex items-center gap-3">
                  {t.avatar ? (
                    <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full object-cover" />
                  ) : (
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
                      {t.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{t.name}</p>
                    <p className="text-gray-400 text-xs">{t.role}{t.country ? ` · ${t.country}` : ""}</p>
                  </div>
                </div>
              </div>
            )) : (
              /* Placeholder testimonials */
              [
                { name: "Sarah Johnson", country: "United Kingdom", rating: 5, content: "Absolutely incredible experience! ViaTrek organized our Maasai Mara safari perfectly. The guides were knowledgeable and the whole trip was seamless.", role: "Safari Traveler" },
                { name: "Michael Chen", country: "Singapore", rating: 5, content: "The Diani beach package was beyond expectations. Crystal clear water, pristine beaches, and top-notch service. Will definitely book again!", role: "Beach Traveler" },
                { name: "Emma Williams", country: "Australia", rating: 5, content: "Our honeymoon in Kenya was magical thanks to ViaTrek. Every detail was perfectly arranged. Highly recommend for couples!", role: "Honeymoon Traveler" },
              ].map((t, i) => (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-sm">
                  <StarRating rating={t.rating} />
                  <p className="text-gray-600 text-sm leading-relaxed my-4 italic">"{t.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: "linear-gradient(135deg, oklch(0.55 0.16 195), oklch(0.45 0.14 240))" }}>
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 text-sm">{t.name}</p>
                      <p className="text-gray-400 text-xs">{t.role} · {t.country}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="text-center mt-8">
            <Link href="/reviews">
              <Button variant="outline" size="lg" className="rounded-xl font-semibold px-8"
                style={{ borderColor: "oklch(0.72 0.14 195)", color: "oklch(0.45 0.14 240)" }}>
                Read All Reviews <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=1920&q=80"
            alt="Kenya Safari"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-hero-gradient" />
        </div>
        <div className="container relative text-center text-white">
          <h2 className="font-display text-3xl md:text-5xl font-bold mb-4">
            Ready for Your Kenya Adventure?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Contact us today and let our experts craft your perfect Kenya itinerary. Free consultation, no obligation.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/tours">
              <Button size="lg" className="px-8 font-semibold rounded-xl btn-scale"
                style={{ background: "linear-gradient(135deg, oklch(0.62 0.18 75), oklch(0.78 0.16 75))", color: "white" }}>
                Browse Tours
              </Button>
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="px-8 font-semibold rounded-xl btn-scale border-2 border-white/60 text-white hover:bg-white/15 bg-transparent">
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp Us
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
